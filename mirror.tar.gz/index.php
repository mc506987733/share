<?php 
require('function.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>西顾镜子 - 照亮生活！</title>
    <meta name="keywords" content="镜子网站"/>
    <meta name="description" content="我有一个小只小毛驴,从来也不骑！"/>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE;chrome=1">
          <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, minimal-ui">
    <link rel="shortcut icon" href="//bkcdn-1256073550.cos.ap-chengdu.myqcloud.com/ico.png" type="image/x-icon" >
	<link rel="stylesheet" href="mirror.css"/>
    <link rel='dns-prefetch' href='//cdn.bootcss.com' />
	<link href="//cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  	<link href="ttt.css" rel="stylesheet">
	<link href="//cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<body>
<?php if (isMobile() ){
    echo '<div  style="position:absolute; width:100%; height:100%; z-index:-1">
<img style="background-position:center center" src="//24bp.cn/mine/PE.php" height="100%" width="100%" />
</div>';
}else{
    echo '<div  style="position:absolute; width:100%; height:100%; z-index:-1">
<img style="background-position:center center" src="//24bp.cn/mine/PC.php" height="100%" width="100%" />
</div>';
} ?>
		<header>	
<div class="c_nvbd"><div class="c_nv"><div class="wp cl"><div id="c_nv" class="z cl">
<ul><a href="/" class="logo z"><img src="//ww2.sinaimg.cn/mw690/0060lm7Tly1fr8pxwihafj306q022744.jpg" alt="Mirror" border="0"></a><li class="a" id="mn_forum"><a href="/" hidefocus="true" title="首页" style="font-weight: bold;color: red">首页</a></li><li id="mn_Ned10"><a href="https://24bp.cn" hidefocus="true" title="西顾博客" style="font-weight: bold;color: blue">博客</a></li><li id="mn_N7918"><a href="#" hidefocus="true" title="主题" style="font-weight: bold;color: purple">主题</a></li><li id="mn_N863f"><a href="https://24bp.cn/photo" hidefocus="true" title="相册" style="font-weight: bold;color: gray">相册</a></li><li id="mn_Necc4"><a href="#" hidefocus="true" title="角色扮演" style="font-weight: bold;color: green">动漫扮演<span>角色扮演</span></a></li></ul>
</div>
<div class="c_cp y"><div class="csearch c_cp_icon y">
<a href="javascript:0;" class="cshow_btn">
<i class="fa fa-search"></i>
</a>
</div><div class="c_cp_icon y cl">
<a href="http://wpa.qq.com/msgrd?v=3&uin=506987733&site=qq&menu=yes" target="_blank" class="cbtn_qq" title="QQ登录"><i class="fa fa-qq"></i></a>
<a href="fa fa-unlock-alt" target="_blank" class="cbtn_wx" title="微信"><i class="fa fa-unlock-alt"></i></a>
</div>
</div>
</div>
</div>
</div>
		</header>
		<div class="container">
			<h1>Cegoo mirror,find different！</h1>
			<form action="mirror.html">
				<div class="input-group col-xs-12">
					<input type="text" class="form-control" value="http://" style="border-radius:0px;border:none;" name="url" maxlength="100" autocomplete="off">
					<span class="input-group-btn">
						<input type="submit" class="btn btn-default" value="我日！"  style="border-radius:0px;border:none;padding:.5em;background:#3388FF;color:#fff;"/>
					</span>
				</div>			
			</form>
		</div>
		<footer class="footer">Copyright &copy; <a href="https://24bp.cn">西顾酱</a> 2018 </footer>
	<script src="//cdn.bootcss.com/jquery/1.8.3/jquery.min.js"></script>
</body>
</html>