<?php
require( dirname(__FILE__) . '/wp-load.php' );
$id=$_GET['id'];
$title = get_post($id)->post_title;
$xydown_name=get_post_meta($id, 'xydown_name', true);
$xydown_size=get_post_meta($id, 'xydown_size', true);
$xydown_date=get_post_meta($id, 'xydown_date', true);
$xydown_version=get_post_meta($id, 'xydown_version', true);
$xydown_author=get_post_meta($id, 'xydown_author', true);
$xydown_downurl1=get_post_meta($id, 'xydown_downurl1', true);
$xydown_downurl2=get_post_meta($id, 'xydown_downurl2', true);
$xydown_downurl3=get_post_meta($id, 'xydown_downurl3', true);
$xydown_downurl4=get_post_meta($id, 'xydown_downurl4', true);
$xydown_downurl5=get_post_meta($id, 'xydown_downurl5', true);
$xydown_downurl6=get_post_meta($id, 'xydown_downurl6', true);
$xydown_downurl7=get_post_meta($id, 'xydown_downurl7', true);
$xydown_baidumima=get_post_meta($id, 'xydown_baidumima', true);
$xydown_360mima=get_post_meta($id, 'xydown_360mima', true);
 ?>
<html>
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Cache-Control" content="no-transform " />
<link rel="Shortcut Icon" href="//p.24bp.cn/FLY/ico.png" type="image/x-icon" />
<link rel="dns-prefetch" href="//p.24bp.cn">
<meta name="keywords" content="<?php echo $title;?>" />
<meta name="description" content="<?php echo $title;?>下载" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
<title>V站丨<?php echo $title;?></title>
<link rel="stylesheet" href="
//p.24bp.cn/FLY/show.css" type="text/css" />
<link href="//apps.bdimg.com/libs/fontawesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" />
<script src="//apps.bdimg.com/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script src="//p.24bp.cn/FLY/show.js" ></script>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
</head>
<body>
<div class="topbar">
  <div class="top">
    <div class="top_left">您好，欢迎进入文件分享中心！</div>
    <div class="top_right"><a href="<?php echo get_permalink( $id ); ?>" title="返回文章页面"><i class="fa fa-th-large"></i>返回文章页面</a><span>|</span><a href="<?php site_url(); ?>"><i class="fa fa-home"></i>网站首页</a></div>
  </div>
</div>
<div class="wrap">
<div class="content">
<h2>《<?php echo $title;?>》</h2>
<div class="plus_box">
<div class="plus_l">
  <ul>
    <li>演示地址 ：<a href="https://24bp.cn/go.php?url=<?php echo $xydown_yanshi;?>">点击查看</a></li>
    <li>文件名称 ：<?php echo $xydown_name;?></li>
    <li>文件大小 ：<?php echo $xydown_size;?></li>
    <li>提取码：<font color="red"><?php if($xydown_baidumima){?><?php echo $xydown_baidumima; }?>&nbsp;&nbsp;（空则无密码）</font></li>
    <li>作者信息 ：<?php echo $xydown_author;?></li>
    <li>推荐级别 ：<span class="xing_e"></span></li>
  </ul>
</div>
<div class="plus_r"><a href="https://24bp.cn"></a><img src="https://ae01.alicdn.com/kf/HTB1nzxwaOnrK1RjSszi760ptpXag.png" width="230" height="230" alt="广告出售-V站"></a></div>
</div>
<div class="panel">
 <div class="panel-heading">
   <h3>下载地址</h3>
 </div>
 <div class="panel-body">
 		<?php if($xydown_downurl1){?><a href="<?php echo $xydown_downurl1;?>" target="_blank">百度网盘&nbsp;<font color="red"></font></a><?php } if($xydown_downurl4){?><a href="<?php echo $xydown_downurl4;?>" target="_blank">迅雷快传</a><?php }if($xydown_downurl5){?><a href="<?php echo $xydown_downurl5;?>" target="_blank">360网盘&nbsp;<font color="red">(<?php if($xydown_360mima){?>提取码:<?php echo $xydown_360mima;?>)</font><?php }?></a><?php }if($xydown_downurl6){?><a href="<?php echo $xydown_downurl6;?>" target="_blank">其他网盘</a><?php }if($xydown_downurl7){?><a href="<?php echo $xydown_downurl7;?>" target="_blank">官方下载</a><?php }if($xydown_downurl2){?><a href="<?php echo $xydown_downurl2;?>" target="_blank">城通网盘</a><?php } if($xydown_downurl3){?><a href="<?php echo $xydown_downurl3;?>" target="_blank"><font color="red">普通下载</font></a><?php }?><br> 
  </div>
</div>
<div class="panel">
 <div class="panel-heading">
   <h3>下载说明</h3>
 </div>
 <div class="panel-body">
  <ul class="help">
    <li>1、本站提供的压缩包若无特别说明，解压密码均为24bp.cn！<em></em></li>
    <li>2、下载后文件若为压缩包格式，请安装7Z软件或者其它压缩软件进行解压！</li>
	<li>3、文件比较大的时候，建议使用下载工具进行下载，浏览器下载有时候会自动中断，导致下载错误！</li>
	<li>4、资源可能会由于内容问题被和谐，导致下载链接不可用，遇到此问题，请到文章页面进行反馈，我们会及时进行更新的！</li>
	<li>5、其他下载问题请自行搜索教程，这里不一一讲解！</li>
  </ul>
 </div>
</div>
<div class="panel">
 <div class="panel-heading">
   <h3>站长声明</h3>
 </div>
 <div class="panel-body">
  <span class="shengming">本站大部分下载资源收集于网络，只做学习和交流使用，版权归原作者所有，若为付费资源，请在下载后24小时之内自觉删除，若作商业用途，请到原网站购买，由于未及时购买和付费发生的侵权行为，与本站无关。本站发布的内容若侵犯到您的权益，请联系本站站长，我们将及时处理！</span>
 </div>
</div>
</div>
<div class="footer">
<p>Copyright © 2017~2019 <a href="https://24bp.cn/sitemap.php" title="sitemap">西顾博客</a>  <a href="https://24bp.cn" title="西顾博客">Theme by 西顾</a></p>
</div>

</div>
</body>
</html>