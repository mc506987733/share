<?php
    if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
        die ('Please do not load this page directly. Thanks!');
?>
    <!– Comment Form –>
<?php
if ( !comments_open() ) :
// If registration required and not logged in.
elseif ( get_option('comment_registration') && !is_user_logged_in() ) :
?>
<p>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</p>
<?php else  : ?>
<!-- Comment Form -->
		<article class="span12" id="comments" data-aos="fade-up">
	<div id="comments2" class="panel-comments panel-sort">
			<div id="respond" class="comment-respond">
				<div id="comment-place">
	<div class="comment-post" id="comment-post">
<form id="commentform" name="commentform" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
	<div class="comment-post" id="comment-post">
		<h3 id="reply-title" class="comment-reply-title"><span class="fa fa-comments-o"></span> 发表评论 <div class="cancel-reply" id="cancel-reply" style="display:none"><a href="javascript:void(0);" onclick="cancelReply()"><span class="fa fa-share"></span> 取消回复</a></div></h3></div>
  			<p class="comment-notes"><span id="email-notes">电子邮件地址不会被公开。</span> 必填项已用<span class="required">*</span>标注</p>
    <div class="hr dotted clearfix"> </div>
    <ul>
        <?php if ( !is_user_logged_in() ) : ?>
            <label for="message"></label>
           <textarea id="comment" class="form-control comment-form-comment textarea" placeholder="来都来了,不随便说两句吗?" name="comment" tabindex="4" rows="3" cols="40"></textarea>
            <label for="name"></label>
            <input class="form-control comment-form-author" placeholder="昵称" type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="23" tabindex="1" />
            <label for="email"></label>
            <input class="form-control comment-form-email" placeholder="邮箱" type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="23" tabindex="2" />
            <label for="email"></label>
            <input class="form-control comment-form-url" placeholder="网站" type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="23" tabindex="3" />
        <?php else : ?>
        <li class="clearfix">您已登录:<a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出登录">退出 »</a></li>
                  <label for="message"></label>
           <textarea id="comment" class="form-control comment-form-comment textarea" placeholder="来都来了,不随便说两句吗?" name="comment" tabindex="4" rows="3" cols="40"></textarea>
        <?php endif; ?>
						<p class="form-submit">        <a href="javascript:void(0);" onClick="Javascript:document.forms['commentform'].submit()" class="btn btn-default">发表评论</a> 

            <!-- Add Comment Button -->
			</p>
                  <!--表情插入 -->
      			<div class="comment-form-smiley no-js-hide" onclick="embedSmiley()"><div class="opensmile" title="插入表情">
			<span class="fa fa-smile-o" style="top:2px"></span></div><div class="smiley-box" style="display:none"><a href="javascript:grin('[F1]')" title="囧"><img src="<?php echo get_template_directory_uri(); ?>/images/1.gif" alt="囧"></a>
<a href="javascript:grin('[F2]')" title="亲"><img src="<?php echo get_template_directory_uri(); ?>/images/2.gif" alt="亲"></a>
<a href="javascript:grin('[F3]')" title="晕"><img src="<?php echo get_template_directory_uri(); ?>/images/3.gif" alt="晕"></a>
<a href="javascript:grin('[F4]')" title="酷"><img src="<?php echo get_template_directory_uri(); ?>/images/4.gif" alt="酷"></a>
<a href="javascript:grin('[F5]')" title="哭"><img src="<?php echo get_template_directory_uri(); ?>/images/5.gif" alt="哭"></a>
<a href="javascript:grin('[F6]')" title="馋"><img src="<?php echo get_template_directory_uri(); ?>/images/6.gif" alt="馋"></a>
<a href="javascript:grin('[F7]')" title="闭嘴"><img src="<?php echo get_template_directory_uri(); ?>/images/7.gif" alt="闭嘴"></a>
<a href="javascript:grin('[F8]')" title="调皮"><img src="<?php echo get_template_directory_uri(); ?>/images/8.gif" alt="调皮"></a>
<a href="javascript:grin('[F9]')" title="馋"><img src="<?php echo get_template_directory_uri(); ?>/images/9.gif" alt="馋"></a>
<a href="javascript:grin('[F10]')" title="奸"><img src="<?php echo get_template_directory_uri(); ?>/images/10.gif" alt="奸"></a>
<a href="javascript:grin('[F11]')" title="怒"><img src="<?php echo get_template_directory_uri(); ?>/images/11.gif" alt="怒"></a>
<a href="javascript:grin('[F12]')" title="笑"><img src="<?php echo get_template_directory_uri(); ?>/images/12.gif" alt="笑"></a>
<a href="javascript:grin('[F13]')" title="羞"><img src="<?php echo get_template_directory_uri(); ?>/images/13.gif" alt="羞"></a>
<a href="javascript:grin('[F14]')" title="汗"><img src="<?php echo get_template_directory_uri(); ?>/images/14.gif" alt="汗"></a>
<a href="javascript:grin('[F15]')" title="色"><img src="<?php echo get_template_directory_uri(); ?>/images/15.gif" alt="色"></a>
<a href="javascript:grin('[F16]')" title="萌"><img src="<?php echo get_template_directory_uri(); ?>/images/16.gif" alt="萌"></a>
<a href="javascript:grin('[F17]')" title="可怜"><img src="<?php echo get_template_directory_uri(); ?>/images/17.gif" alt="可怜"></a>
<a href="javascript:grin('[F18]')" title="快哭了"><img src="<?php echo get_template_directory_uri(); ?>/images/18.gif" alt="快哭了"></a>
<a href="javascript:grin('[F19]')" title="呆"><img src="<?php echo get_template_directory_uri(); ?>/images/19.gif" alt="呆"></a>
<a href="javascript:grin('[F20]')" title="吓"><img src="<?php echo get_template_directory_uri(); ?>/images/20.gif" alt="吓"></a>
<a href="javascript:grin('[F21]')" title="大笑"><img src="<?php echo get_template_directory_uri(); ?>/images/21.gif" alt="大笑"></a>
</div></div>
			<div title="打卡" onclick="javascript:SIMPALED.Editor.daka();this.style.display='none'" class="daka"><i class="fa fa-pencil"></i></div>
			<div title="赞" onclick="javascript:SIMPALED.Editor.zan();this.style.display='none'" class="zan"><i class="fa fa-thumbs-o-up"></i></div>
			<div title="踩" onclick="javascript:SIMPALED.Editor.cai();this.style.display='none'" class="cai"><i class="fa fa-thumbs-o-down"></i></div>
			<div id="error"></div><div id="ajaxloading"></div>
			<div id="error1"></div><div id="ajaxloading1"></div>
                  <!-- Add 结束 -->
    </ul>
    <?php comment_id_fields(); ?>
    <?php do_action('comment_form', $post->ID); ?>
</form>
      </div>
                  </div>
              </div>
      </div>
 
          </article>
		<?php the_comments_navigation(); ?>
<a name="comments"></a>
	<header class="panel-header">
	</header>
		<ol class="comments-list show-avatars">
				<?php
				wp_list_comments( array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 42,
				) );
			?>
		</ol><!-- .comment-list -->

		<?php the_comments_navigation(); ?>

	<?php endif; // Check for have_comments(). ?>