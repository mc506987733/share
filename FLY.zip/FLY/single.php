<?php get_header(other);?>
			<!-- 内容开始 -->
			<article id="post-box">
					<div class="panel panel-sort">
						<header class="panel-header">
								<div class="post-meta-box">
									<!--面包屑导航开始-->
										<ol class="breadcrumb">
	<li><a href="<?php bloginfo('url'); ?>">首页</a></li> 
	<li>
         <?php the_category(', ') ?>
	</li>
		<li class="active"><?php customTitle(22) ?></li></ol>
									<!--面包屑导航结束-->
									<div class="meta-top">
						<span class="date-top"><i class="fa fa-clock-o"></i> <time class="pubdate"><?php the_time('y年m月d日') ?></time></span>
						<span class="comments-top"><i class="fa fa-comments-o"></i> <?php record_visitors(); ?><?php post_views('',''); ?></span>
						<span class="close-sidebar" title="关闭侧边栏"><a href="javascript:;"><i class="fa fa-toggle-off"></i></a></span>
                        <span class="show-sidebar" title="显示侧边栏" style="display:none;"><a href="javascript:;"><i class="fa fa-toggle-on"></i></a></span>
					                </div>
								</div>
								<h2 class="post-title"><span class="fa fa-code"></span><a href="<?php the_permalink(); ?>" title="<?php the_title(‭); ?>"><?php the_title(‭); ?></a></h2>
								<ul id="mobile-tab-menu" class="no-js-hide">
								<li class="current" data-tab="context">内容</li>
								<li class="" data-tab="related">相关</li>
								</ul>
						</header>
					<section class="context">
	<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<div class="entry">
				<?php the_content(); ?>
				<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
				<p class="postmetadata">

<?php _e('来自&#58;'); ?> <?php the_category(', ') ?> <?php _e('By'); ?> <?php  the_author(); ?> <?php edit_post_link('编写', ' &#124; ', ''); ?>

				</p>
          </div>
		</div>	
  <?php endwhile; ?>
		<div class="navigation">
			<?php previous_post_link('&laquo; %link') ?> <?php next_post_link(' %link &raquo;') ?>
		</div>
	<?php else : ?>
		<div class="post">
			<h2><?php _e('Not Found'); ?></h2>
          		</div>
	<?php endif; ?>
                      </section>
					<div class="share_list shareBox">
						<p>
                                                                      <script type="text/javascript">
$(document).ready(function() { 
	$.fn.postLike = function() {
		if ($(this).hasClass('done')) {
			alert('您已赞过本博客');
			return false;
		} else {
			$(this).addClass('done');
			var id = $(this).data("id"),
			action = $(this).data('action'),
			rateHolder = $(this).children('.count');
			var ajax_data = {
				action: "bigfa_like",
				um_id: id,
				um_action: action
			};
			$.post("<?php bloginfo('url');?>/wp-admin/admin-ajax.php", ajax_data, function(data) {
				$(rateHolder).html(data);
			});
			return false;
		}
	};
	$(document).on("click", ".favorite", function() {
		$(this).postLike();
	});
}); 
</script>
							<a href="javascript:;" data-action="ding" data-id="<?php the_ID(); ?>" class="ja_praise action action-like sharebtn abouts"><i class="fa fa-heart-o"></i> 赞 (<span><?php 
		if( get_post_meta($post->ID,'bigfa_ding',true) ){            
			echo get_post_meta($post->ID,'bigfa_ding',true);
		} else {
			echo '0';
		}
	?></span>)</a>							<a href="javascript:;" class="sharebtn pay-author"><i class="fa fa-credit-card"></i> 打赏</a>
							<a href="javascript:;" class="sharebtn J_showAllShareBtn"><i class="fa fa-paper-plane-o"></i> 分享</a>
						</p>
						<div class="socialBox">
							<div class="bdsharebuttonbox u-share-container f-usn">
								<ul class="dsye">
                                              <li class="s-weixin js-share-wx" onclick="shareToWeiXin('https:\/\/api.pjax.cn\/api\/qrcode\/api.php?data=<?php the_permalink(); ?>')" title="分享到朋友圈"></li>
									          <li class="s-weibo js-share-wb" onclick="shareToWeibo('<?php the_permalink(); ?>','<?php the_title(‭); ?>','<?php the_permalink(); ?>')" title="分享到微博"></li>
									          <li class="s-qzone js-share-qz" onclick="shareToQzone('<?php the_permalink(); ?>','<?php the_title(‭); ?>','<?php the_permalink(); ?>','')" title="分享到QQ空间"></li>
									          <li class="s-note js-share-note" onclick="shareToQQ('<?php the_permalink(); ?>','<?php the_title(‭); ?>','<?php the_permalink(); ?>')" title="分享给QQ好友"></li>
								</ul>
							</div>
							<div class="panel-reward">
								<ul class="dsye">
									<li class="alipay"><a href="https://24bp.cn/vx.png" target="_blank" class="highslide"><img alt="打赏" src="https://24bp.cn/vx.png"></a><b>支付宝扫一扫</b></li>
									<li class="weixinpay"><a href="https://24bp.cn/vx.png" target="_blank" class="highslide"><img alt="打赏" src="https://24bp.cn/vx.png"></a><b>微信扫一扫</b></li>
									<li class="txpay"><a href="https://24bp.cn/vx.png" target="_blank" class="highslide"><img alt="打赏" src="https://24bp.cn/vx.png"></a><b>企鹅扫一扫</b></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
<!-- 内容结束 -->
<!-- 版权开始 -->
<?php the_tags('<div class="post-entry-categories">','','</div>'); ?>
<div class="post-copyright panel panel-sort sbclass" data-aos="fade-up">
	<p><i class="fa fa-bullhorn"></i> 版权声明：若无特殊注明，本文皆为《<a href="<?php bloginfo('url'); ?>/author/<?php  the_author(); ?>" title="管理员"><?php  the_author(); ?></a>》原创，转载请保留文章出处。</p>
	<p><i class="fa fa-share-alt-square"></i> 本文链接：<?php wp_title(); ?> - <?php the_permalink(); ?></p>
          </div>
<!-- 版权结束 -->
<!-- 相关开始 -->
<div class="span12 related-posts-box mobile-hide" data-aos="fade-up">
			<div class="panel log_list panel-sort">
				<header class="panel-header">
					<h3 class="log_h3">
						<span class="fa fa-clipboard"></span> 相关文章
					</h3>
				</header>
				<ul class="related-posts row">
                  <?php  
if ( is_single() ) :  
global $post;  
$categories = get_the_category();  
foreach ($categories as $category) :  
    ?>  
     
        <?php  
        $posts = get_posts('numberposts=3&category='. $category->term_id.'&exclude='.get_the_ID());  
        foreach($posts as $post) :  
        ?>
									<li class="col-sm-4">
						<div class="panel transparent related-posts-panel">
							<a href="<?php the_permalink(); ?>" class="thumbnail-link" rel="bookmark" title="<?php the_title(); ?>">
								<img src="<?php echo post_thumbnail_src(); ?>" class="thumbnailimg" width="175" height="80" title="<?php the_title(); ?>" alt="<?php the_title(); ?>">
								<div class="excerpt">
	<?php the_title(); ?>
</div>
							</a>
						<div class="bottom-box">
							<h4 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
							<ul class="post-meta">
							<li class="author">
							<span class="fa fa-github"></span>
							<a href="<?php bloginfo('url'); ?>/author/<?php  the_author(); ?>" title="管理员"><?php  the_author(); ?></a>							</li>
							<li class="date date-abb">
							<span class="fa fa-clock-o"></span>
							<a href="<?php the_permalink(); ?>" title="发布于<?php the_time('Y-m-d') ?>">
								<time><?php the_time('Y-m-d') ?></time>
							</a>
							</li>
							</ul>
						</div>
						</div>
					</li>
        <?php endforeach; ?>  
      
<?php  
endforeach; endif ; ?>  
									</ul>
			</div>
		</div>

<!-- 相关结束 -->
<!-- 评论开始 -->
<?php comments_template(); ?>
	<!-- 评论结束 -->
		</div>
	</div>
<?php get_sidebar();?>

</section>
<?php get_footer();?>