<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta name="generator" content="WordPress">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="ThemeKing">
    <link rel="dns-prefetch" href="//coding.net">
  <?php echo xg_wp_seo(); ?>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  	<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/board.css" type="text/css" media="all">
	<script src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/jquery.min.js" type="text/javascript"></script>
    <script src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/jquery.pjax.js" type="text/javascript"></script>	
    <script src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/bootstrap.min.js" type="text/javascript"></script>
	<script src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/jquery.lazyload.js" type="text/javascript"></script>
	<script src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/tinymce.min.js" type="text/javascript"></script>
    <script type="text/javascript">
var pjaxtheme = '<?php bloginfo('url'); ?>/wp-content/themes/FLY/';
var blog_url = '<?php bloginfo('url'); ?>';
var pjax_id = '#WP-FLY';
var ThemeVersion = 1.2;
</script>
<?php if ( wp_is_mobile() ){
    echo '<div  style="position:absolute; width:100%; height:100%; z-index:-1">
<img style="position:fixed;" src="//cdn.24bp.cn/bk/api/PE.php" height="100%" width="100%" />
</div>';
}else{
    echo '<div  style="position:absolute; width:100%; height:100%; z-index:-1">
<img style="position:fixed;" src="//cdn.24bp.cn/bk/api/PC.php" height="100%" width="100%" />
</div>';
} ?>
</head>
<body class="nav-fixed">
<nav id="header" class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="navbar-header"<?php global $ashu_option ?>>
			<a href="<?php bloginfo('url'); ?>" class="navbar-brand logo"><img src="<?php echo $ashu_option['ashu']['_ashu_logo']; ?>" alt="ThemeKing"></a>

		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
	    </button>
		</div>
	 <?php wp_nav_menu(
								array(	
                                    	'container'       => 'div',
	                                    'container_class' => 'collapse navbar-collapse navbar-right',
                                  	    'container_id'    => 'bs-example-navbar-collapse-1',
										'menu_class' =>'nav navbar-nav nav-top', 
                                        'category_before' => '<li>',    
                                        'category_after' => '</li>',
									) 
							); 
				?>

          <!--爸爸的导航完成-->
  			<div class="fly-nav-right">
				<div class="login-nav"><a href="/wp-login.php" class="expand" data-target="#myLogin" data-toggle="modal" data-backdrop="static" target="_blank"><i class="fa fa-user-circle"></i></a></div>
				<div class="fly-search fly-search-s"><i class="fa fa-search"></i></div>
			</div>
  </div>
</nav>
<div id="FLY"><section class="container">
	<div class="content-wrap">
		<div class="content">