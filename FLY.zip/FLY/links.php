<?php 
/*
Template Name: 友链页面
*/
?>
<?php get_header(other);?>
<section class="container">
  <div class="content-wrap">
    <div class="content container-tw" data-aos="fade-up">
        <header class="article-header">
            <h1 class="title-tw"><i class="fa fa-link"></i><?php the_title(); ?></h1>
        </header>
		<section class="context">
			<div class="blue" style="list-style-type: none; box-sizing: border-box; font-size: 12px; font-family: 'Lucida Console'; color: #1bb3f0; margin: 0 0 20px; border-radius: 2px; border: #8accff 1px solid; padding: 10px 30px 10px 30px;"><span style="box-sizing: border-box; font-family: 'Microsoft YaHei', 微软雅黑, 'Trebuchet MS', Arial, Verdana, Tahoma, sans-serif; font-size: 14px;">&nbsp;拒绝推广类广告网站，抵制一切非法网站淫秽网站等；</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 本站所加的友情链接，如发现其失效持续超过一周，将直接取消贵链接，如果恢复，请留言</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 申请之前请先提前对本站博客做好友情链接</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 本博客只提供文字友链不提供LOGO友链</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 未受到搜索引擎惩罚，即在百度、Google中能搜索到贵站</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 我们只交换首页友情链接,非首页链接申请不通过(个别除外)</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 要求贵站页面设计整洁，友情链接清晰不乱，并且链接保持在页面首页，内容健康，不接受广告联盟、营销网站之类站点的链接，网站内容符合中华人民共和国法律，具有顶级域名，建站时间大于半年，制作不能太粗糙，无恶意代码。(个别除外)</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 网站至少有一个搜索引擎要收录200+(个别除外)</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 博客搭建至少半年以上</span><br style="box-sizing: border-box;" /><span style="font-size: 14px;"> ❤ 没有满足以上条件的请勿打扰！</span></div>
			<div class="row blogroll">
              <blockquote>我的邻居</blockquote>
<?php $bookmarks=get_bookmarks();
  if ( !empty($bookmarks) ){
    echo '<ul class="ikmoe-link">';
    foreach ($bookmarks as $bookmark) {
      echo '<li><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" >'.'<div class="ikmoe-tx">'.get_avatar($bookmark->link_notes,128) . '<span class="ikmoe-text">'. $bookmark->link_name .'</span></a></li>';
    }
    echo '</ul>';
  }
?>

			</div>
		</section>
    </div>
  </div>
<?php get_sidebar(2);?>
</section>
<?php get_footer();?>

