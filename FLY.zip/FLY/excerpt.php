<?php 
if( has_post_format( 'gallery' ) ){ //推广文章?>
<div id="content">
  <div class="post">
<article class="content-list aos-init aos-animate" data-aos="fade-up">
<div class="content-box posts-gallery-box">
				<div class="posts-gallery-img">
<img class="lazy" src="<?php echo get_template_directory_uri();?>/images/lazyload.gif" data-original="<?php echo post_thumbnail_src(); ?>" width="640" height="480">
		</div>
		<div class="posts-gallery-content">
 <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<div class="posts-gallery-text"><?php echo wp_trim_words(get_the_excerpt(), 60 ); ?></div>
  			<div class="posts-default-info"<?php global $ashu_option ?>>
              		<?php 
			$author_id=get_the_author_meta('ID');
			$author_url=get_author_posts_url($author_id);	
			$user_email = get_the_author_meta( 'user_email' );
		?>	
				<ul>
					<li class="post-author"><div class="avatar"><img class="lazy" src="<?php echo get_template_directory_uri();?>/images/lazyload.gif" data-original="<?php echo $ashu_option['ashu']['_baba_xigu']; ?>" class="avatar avatar-96 photo" height="96" width="96"></div><a href="<?php echo $author_url;?>" title="查看关于<?php  the_author(); ?>的文章"><?php  the_author(); ?></a></li>
					<li class="ico-cat"><i class="fa fa-list"></i><?php the_category(', ') ?></li>
                    <li class="ico-time"><i class="fa fa-clock-o"></i><?php the_time('Y-m-d') ?></li>
					<li class="ico-eye"><i class="fa fa-eye"></i> <?php post_views('',''); ?></li>
					<li class="ico-like"><i class="fa fa-comments-o"></i><?php  echo get_comments_number();?></li>
				</ul>
			</div>
</div>
   </div>
          </article>
    </div>
  </div>
<?php } else if ( has_post_format( 'aside' )) { //多图 ?>
<article class="content-list aos-init aos-animate" data-aos="fade-up">
<div class="content-box posts-image-box">
		<div class="posts-default-title">
<?php the_tags('<div class="post-entry-categories">','','</div>'); ?>
			<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" se_prerender_url="complete"><?php the_title(); ?></a> <small class="text-muted" title="本文3张图片"><span class="fa fa-picture-o"></span></small></h2>
		</div>
				<div class="post-images-item">
			<ul>
<?php all_img($post->post_content);?>
			            </ul>

		</div>
		<div class="posts-default-content">
			
			<div class="posts-text"><?php echo wp_trim_words(get_the_excerpt(), 60 ); ?></div>
			<div class="posts-default-info"<?php global $ashu_option ?>>
				<ul>
					<li class="post-author"><div class="avatar"><img class="lazy" src="<?php echo get_template_directory_uri();?>/images/lazyload.gif" data-original="<?php echo $ashu_option['ashu']['_baba_xigu']; ?>" class="avatar avatar-96 photo" height="96" width="96"></div><a href="<?php bloginfo('url'); ?>/author/<?php  the_author(); ?>" title="查看关于 <?php  the_author(); ?> 的文章"><?php  the_author(); ?></a></li>
					<li class="ico-cat"><i class="fa fa-list"></i><?php the_category(', ') ?>
	</li>
                    <li class="ico-time"><i class="fa fa-clock-o"></i><?php the_time('Y-m-d') ?></li>
					<li class="ico-eye"><i class="fa fa-eye"></i> <?php post_views('',''); ?></li>
					<li class="ico-like"><i class="fa fa-comments-o"></i><?php  echo get_comments_number();?></li>
				</ul>
			</div>
		</div>
	</div>
		</article>
<?php } else{ //标准 ?>
<div id="content">
  <div class="post">
<article class="content-list aos-init aos-animate" data-aos="fade-up">
<div class="content-box posts-gallery-box">
				<div class="posts-gallery-img">

<img class="lazy" src="<?php echo get_template_directory_uri();?>/images/lazyload.gif" data-original="<?php echo post_thumbnail_src(); ?>" width="640" height="480">
		</div>
		<div class="posts-gallery-content">
 <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<div class="posts-gallery-text"><?php echo wp_trim_words(get_the_excerpt(), 60 ); ?></div>
  			<div class="posts-default-info">
              <?php global $ashu_option ?>
				<ul>
					<li class="post-author"><div class="avatar"><img class="lazy" src="<?php echo get_template_directory_uri();?>/images/lazyload.gif" data-original="<?php echo $ashu_option['ashu']['_baba_xigu']; ?>" class="avatar avatar-96 photo" height="96" width="96"></div><a href="<?php bloginfo('url'); ?>/author/<?php  the_author(); ?>" title="查看关于 <?php  the_author(); ?> 的文章"><?php  the_author(); ?></a></li>
					<li class="ico-cat"><i class="fa fa-list"></i>  	    <?php the_category(', ') ?> </li>
                    <li class="ico-time"><i class="fa fa-clock-o"></i><?php the_time('Y-m-d') ?></li>
					<li class="ico-eye"><i class="fa fa-eye"></i> <?php post_views('',''); ?></li>
					<li class="ico-like"><i class="fa fa-comments-o"></i><?php  echo get_comments_number();?></li>
				</ul>
			</div>
</div>
   </div>
          </article>
    </div>
  </div>
<?php } ?>
