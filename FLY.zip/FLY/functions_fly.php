<?php      

class ashu_option_class{   
  
    var $options;   
    var $pageinfo;   
    var $database_options;   
    var $saved_optionname;   
       
    //类的构建函数   
    function ashu_option_class($options, $pageinfo) {   
        $this->options = $options;   
        $this->pageinfo = $pageinfo;   
        $this->make_data_available(); //准备设置选项数据   
  
        add_action( 'admin_menu', array(&$this, 'add_admin_menu') );   
           
        if( isset($_GET['page']) && ($_GET['page'] == $this->pageinfo['filename']) ) {   
            //加载css js   
            add_action('admin_init', array(&$this, 'enqueue_head'));       
        }   
    }   
       
    function enqueue_head() {   
        //加载的js路径   
        wp_enqueue_script('ashu_options_js',get_template_directory_uri() .  '/js/ashu_options.js');    
        wp_enqueue_style('ashu_options_css',get_template_directory_uri() .  '/css/ashu_options.css');    
        wp_enqueue_script('thickbox');   
        wp_enqueue_style('thickbox');   
    }   
       
    //创建菜单项函数   
    function add_admin_menu() {   
        //添加顶级菜单项   
        $top_level = "主题设置";   
        if(!$this->pageinfo['child']) {   
            add_menu_page($top_level, $top_level, 'edit_themes', $this->pageinfo['filename'], array(&$this, 'initialize'));   
            define('TOP_LEVEL_BASEAME', $this->pageinfo['filename']);   
        }else{   
            add_submenu_page(TOP_LEVEL_BASEAME, $this->pageinfo['full_name'], $this->pageinfo['full_name'], 'edit_themes', $this->pageinfo['filename'], array(&$this, 'initialize'));   
        }   
    }   
       
    function make_data_available() {   
        global $ashu_option; //申明全局变量   
           
        foreach ($this->options as $option) {   
            if( isset($option['std']) ) {   
                $ashu_option_std[$this->pageinfo['optionname']][$option['id']] = $option['std'];   
            }   
        }   
        //选项组名称   
        $this->saved_optionname = 'ashu_'.$this->pageinfo['optionname'];   
        $ashu_option[$this->pageinfo['optionname']] = get_option($this->saved_optionname);   
           
        //合并数组   
        $ashu_option[$this->pageinfo['optionname']] = array_merge((array)$ashu_option_std[$this->pageinfo['optionname']], (array)$ashu_option[$this->pageinfo['optionname']]);   
           
        //html实体转换   
        $ashu_option[$this->pageinfo['optionname']] = $this->htmlspecialchars_deep($ashu_option[$this->pageinfo['optionname']]);   
       
    }   
       
    //使用递归将预定义html实体转换为字符   
    function htmlspecialchars_deep($mixed, $quote_style = ENT_QUOTES, $charset = 'UTF-8') {   
        if (is_array($mixed) || is_object($mixed)) {   
            foreach($mixed as $key => $value) {   
                $mixed[$key] = $this->htmlspecialchars_deep($value, $quote_style, $charset);   
            }   
        }   
        elseif (is_string($mixed)) {   
            $mixed = htmlspecialchars_decode($mixed, $quote_style);   
        }   
        return $mixed;   
    }    
       
    function initialize() {   
        $this->get_save_options();   
        $this->display();   
    }   
       
    //显示表单项函数   
    function display() {       
        $saveoption = false;   
        echo '<div class="wrap">';   
        echo '<div class="icon32" id="icon-options-general"><br/></div>';   
        echo '<h2>'.$this->pageinfo['full_name'].'</h2>';   
        echo '<form method="post" action="">';   
           
        //根据选项类型执行对应函数   
        foreach ($this->options as $option) {   
            if (method_exists($this, $option['type'])) {   
                $this->$option['type']($option);   
                $saveoption = true;   
            }   
        }   
        if($saveoption) {   
            echo '<p class="submit">';   
            echo '<input type="hidden" value="1" name="save_my_options"/>';   
            echo '<input type="submit" name="Submit" class="button-primary autowidth" value="Save Changes" /></p>';   
        }   
        echo '</form></div>';   
    }   
       
    //更新数据   
    function get_save_options() {   
        $options = $newoptions  = get_option($this->saved_optionname);   
        if ( isset( $_POST['save_my_options'] ) ) {   
            echo '<div class="updated fade" id="message" style=""><p><strong>Settings saved.</strong></p></div>';   
            $opion_count = 0;   
            foreach ($_POST as $key => $value) {   
                if( preg_match("/^(numbers_)/", $key, $result) ){   
                    $numbers = explode( ',', $value );   
                    $newoptions[$key] = $numbers;   
                }elseif( preg_match("/^(tinymce_)/", $key, $result) ){   
                    $value = stripslashes($value);   
                    $newoptions[$key] = $value;   
                }elseif( preg_match("/^(checkbox_)/", $key, $result) ){   
                    $newoptions[$key] = $value;   
                }else{   
                    $value = stripslashes($value);   
                    $newoptions[$key] = htmlspecialchars($value, ENT_QUOTES,"UTF-8");   
                }   
            }   
        }   
               
        if ( $options != $newoptions ) {   
            $options = $newoptions;   
            update_option($this->saved_optionname, $options);   
        }   
           
        if($options) {   
            foreach ($options as $key => $value) {   
                $options[$key] = empty($options[$key]) ? false : $options[$key];   
            }   
        }   
           
        $this->database_options = $options;   
    }   
       
    /************开头***************/  
    function open($values) {   
        if(!isset($values['desc'])) $values['desc'] = "";   
           
        echo '<table class="widefat">';   
        echo '<thead><tr><th colspan="2">'.$values['desc'].'&nbsp;</th></tr></thead>';   
    }   
       
    /***************结尾**************/  
    function close($values) {   
        echo '<tfoot><tr><th>&nbsp;</th><th>&nbsp;</th></tr></tfoot></table>';   
    }   
  
    /**********标题***********************/  
    function title($values) {   
        echo '<h3>'.$values['name'].'</h3>';   
        if (isset($values['desc'])) echo '<p>'.$values['desc'].'</p>';   
    }   
  
    /*****************************文本域**********************************/  
    function textarea($values) {   
        if(isset($this->database_options[$values['id']]))   
            $values['std'] = $this->database_options[$values['id']];   
  
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
        echo '<textarea name="'.$values['id'].'" cols="60" rows="7" id="'.$values['id'].'" style="width: 80%; font-size: 12px;" class="code">';   
        echo $values['std'].'</textarea><br/>';   
        echo '<br/></td>';   
        echo '</tr>';   
    }   
       
    /*********************文本框**************************/  
    function text($values) {       
        if(isset($this->database_options[$values['id']])) $values['std'] = $this->database_options[$values['id']];   
           
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
        echo '<input type="text" size="'.$values['size'].'" value="'.$values['std'].'" id="'.$values['id'].'" name="'.$values['id'].'"/>';   
        echo '<br/><br/></td>';   
        echo '</tr>';   
    }   
       
  
    /**************复选框*******************/  
    function checkbox($values) {   
        if(isset($this->database_options[$values['id']])) $values['std'] = $this->database_options[$values['id']];   
           
        echo '<tr valign="top">';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
           
        foreach( $values['buttons'] as $key=>$value ) {   
            $checked ="";   
            if( is_array($values['std']) && in_array($key,$values['std'])) {   
                $checked = 'checked = "checked"';   
            }   
            echo '<input '.$checked.' type="checkbox" class="kcheck" value="'.$key.'" name="'.$values['id'].'[]"/>'.$value;   
        }   
  
           
        echo '<label for="'.$values['id'].'">'.$values['desc'].'</label><br/>';   
        echo '<br/></td>';   
        echo '</tr>';   
    }   
  
    /**********************单选框******************************/  
    function radio($values) {   
        if(isset($this->database_options[$values['id']])) $values['std'] = $this->database_options[$values['id']];   
           
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
           
        foreach($values['buttons'] as $key=>$value) {      
            $checked ="";   
            if(isset($values['std']) && ($values['std'] == $key)) {   
                $checked = 'checked = "checked"';   
            }   
           
            echo '<p><input '.$checked.' type="radio" class="kcheck" value="'.$key.'" name="'.$values['id'].'"/>';   
            echo '<label for="'.$values['id'].'">'.$value.'</label></p>';   
        }   
           
        echo '<br/></td>';   
        echo '</tr>';   
    }   
    /*****************数组***********************/  
    function numbers_array($values){   
        if(isset($this->database_options[$values['id']]))   
            $values['std'] = $this->database_options[$values['id']];   
        else  
            $values['std']=array();   
  
        $nums = implode( ',', $values['std'] );   
           
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
        echo '<input type="text" size="'.$values['size'].'" value="'.$nums.'" id="'.$values['id'].'" name="'.$values['id'].'"/>';   
        echo '<br/><br/></td>';   
        echo '</tr>';   
    }   
  
    /********************下拉框*********************/  
    function dropdown($values) {       
        if(!isset($this->database_options[$values['id']]) && isset($values['std'])) $this->database_options[$values['id']] = $values['std'];   
                   
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
           
            if($values['subtype'] == 'page') {   
                $select = 'Select page';   
                $entries = get_pages('title_li=&orderby=name');   
            }else if($values['subtype'] == 'sidebar'){   
                global $wp_registered_sidebars;   
                $select = 'Select a special sidebar';   
                $entries = $wp_registered_sidebars;   
            }else if($values['subtype'] == 'cat'){   
                $select = 'Select category';   
                $entries = get_categories('title_li=&orderby=name&hide_empty=0');   
            }   
            else  
            {      
                $select = 'Select...';   
                $entries = $values['subtype'];   
            }   
           
            echo '<select class="postform" id="'. $values['id'] .'" name="'. $values['id'] .'"> ';   
            echo '<option value="">'.$select .'</option>  ';   
  
            foreach ($entries as $key => $entry) {   
                if($values['subtype'] == 'page')   
                {   
                    $id = $entry->ID;   
                    $title = $entry->post_title;   
                }else if($values['subtype'] == 'cat'){   
                    $id = $entry->term_id;   
                    $title = $entry->name;   
                }else if($values['subtype'] == 'sidebar'){   
                    $id = $entry['id'];   
                    $title = $entry['name'];   
                }   
                else  
                {   
                    $id = $key;    
                    $title = $entry;           
                }   
  
                if ($this->database_options[$values['id']] == $id )   
                {   
                    $selected = "selected='selected'";     
                }   
                else  
                {   
                    $selected = "";        
                }   
                   
                echo"<option $selected value='". $id."'>". $title."</option>";   
            }   
           
        echo '</select>';   
            
        echo '<br/><br/></td>';   
        echo '</tr>';   
    }   
       
    /*******************上传*****************************/  
    function upload($values) {     
        $prevImg = '';   
        if(isset($this->database_options[$values['id']])) $values['std'] = $this->database_options[$values['id']];   
        if($values['std'] != ''){$prevImg = '<img src='.$values['std'].' alt="" />';}   
           
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>';   
        echo '<div class="preview_pic_optionspage" id="'.$values['id'].'_div">'.$prevImg.'</div>';   
        echo $values['desc'].'<br/>';   
        echo '<input type="text" size="50" value="'.$values['std'].'" name="'.$values['id'].'" class="upload_pic_input" />';   
        echo '&nbsp;<a onclick="return false;" title="" class="k_hijack button thickbox" id="'.$values['id'].'" href="media-upload.php?type=image&amp;hijack_target='.$values['id'].'&amp;TB_iframe=true">Insert Image</a>';   
           
        echo '<br/><br/></td>';   
        echo '</tr>';   
    }   
    //编辑器   
    function tinymce($values){   
        if(isset($this->database_options[$values['id']]))   
            $values['std'] = $this->database_options[$values['id']];   
               
        echo '<tr valign="top" >';   
        echo '<th scope="row" width="200px">'.$values['name'].'</th>';   
        echo '<td>'.$values['desc'].'<br/>';   
        wp_editor( $values['std'], $values['id'],$settings=array('tinymce'=>1,'media_buttons'=>0,) );   
        echo '<br/></td>';   
        echo '</tr>';   
    }   
  
}      
       

 $pageinfo = array('full_name' => '主题设置', 'optionname'=>'ashu', 'child'=>false, 'filename' => basename(__FILE__));      
     
$options = array();      
                  
$options[] = array( "type" => "open");   
  // 西顾API更新
 $options[] = array(
        'name' => __( 'V站', 'tt' ),
        'desc' => sprintf(__( '<br><h2><a href="%s" target="_blank">官方群:743416776</a></h2>', 'tt'), 'https://24bp.cn'),
        'type' => 'text'
    );
     
$options[] = array(
                "name"=>"ThemeKing-Fly",      
                "desc"=>"优雅气质高大上,高端优质上档次~",      
                "type" => "title");                          
$options[] = array(      
                "name"=>"相册图库",      
                "id"=>"_ashu_text",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客相册URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      

$options[] = array(      
                "name"=>"音乐收藏",      
                "id"=>"_ashu_text1",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客音乐收藏URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      
     
$options[] = array(      
                "name"=>"文章归档",      
                "id"=>"_ashu_text2",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客归档URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      
     $options[] = array(      
                "name"=>"站长工具",      
                "id"=>"_ashu_text3",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客工具URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      
     $options[] = array(      
                "name"=>"留言互动",      
                "id"=>"_ashu_text4",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客留言URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      
     $options[] = array(      
                "name"=>"我的邻居",      
                "id"=>"_ashu_text5",      
                "std"=>"https://24bp.cn/photo",      
                "desc"=>"请输入该博客友链URL.",      
                "size"=>"60",      
                "type"=>"text"     
            );      
     
$options[] = array(      
                "name"=>"文本域",      
                "id"=>"_ashu_textarea",      
                "std"=>"阿树工作室文本域",      
                "desc"=>"阿树工作室版权所有",      
                "size"=>"60",      
                "type"=>"textarea"     
            );      
     
$options[] = array(      
            "name" => "LOGO",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_ashu_logo",      
            "type" => "upload");              
 
$options[] = array(      
            "name" => "轮播首图",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_ashu_fuck1",      
            "type" => "upload");  
$options[] = array(      
            "name" => "轮播次图",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_ashu_fuck2",      
            "type" => "upload"); 
$options[] = array(      
            "name" => "轮播尾图",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_ashu_fuck3",      
            "type" => "upload"); 
$options[] = array(      
            "name" => "加入我们",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_ashu_join",      
            "type" => "upload"); 
$options[] = array(      
            "name" => "作者头像",      
            "desc" => "请上传一个图片或填写一个图片地址",      
            "std"=>"",      
            "id" => "_baba_xigu",      
            "type" => "upload");
  
$options[] = array( "type" => "close");      
     
$options_page = new ashu_option_class($options, $pageinfo);     