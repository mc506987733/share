<!-- 第一栏开始 -->
   <div class="col-sm-6 index_cms_6 4">
    <div class="panel panel-default index_cms_panel" data-aos="fade-up">
     <span class="icon"><i class="fa fa-globe"></i></span> 
     <div class="panel-heading">
      <h3 class="panel-title"><?php echo get_cat_name(1)?><span class="more pull-right"><a title="更多" href="<?php echo get_category_link(1)?>"><i class="fa fa-ellipsis-h"></i></a></span></h3>
     </div>
     <div class="panel-body  panel_cms">
      <ul>
 <?php query_posts('showposts=5&cat=1&orderby=rand'); while(have_posts()) : the_post();?>
                <li><a href="<?php the_permalink(); ?>"><time><?php the_time('Y年m月d日') ?></time><i class="fa fa-chevron-right"></i><?php the_title(); ?></a></li>
            <?php endwhile;?>
    <?php wp_reset_query(); ?>
      </ul>
     </div>
    </div>
   </div>
<!-- 第二栏开始 -->
   <div class="col-sm-6 index_cms_6 4">
    <div class="panel panel-default index_cms_panel" data-aos="fade-up">
     <span class="icon"><i class="fa fa-globe"></i></span> 
     <div class="panel-heading">
      <h3 class="panel-title"><?php echo get_cat_name(6)?><span class="more pull-right"><a title="更多" href="<?php echo get_category_link(6)?>"><i class="fa fa-ellipsis-h"></i></a></span></h3>
     </div>
     <div class="panel-body  panel_cms">
      <ul>
 <?php query_posts('showposts=5&cat=6&orderby=rand'); while(have_posts()) : the_post();?>
                <li><a href="<?php the_permalink(); ?>"><time><?php the_time('Y年m月d日') ?></time><i class="fa fa-chevron-right"></i><?php the_title(); ?></a></li>
            <?php endwhile;?>
    <?php wp_reset_query(); ?>
      </ul>
     </div>
    </div>
   </div>
<!-- 第三栏开始 -->
   <div class="col-sm-6 index_cms_6 4">
    <div class="panel panel-default index_cms_panel" data-aos="fade-up">
     <span class="icon"><i class="fa fa-globe"></i></span> 
     <div class="panel-heading">
      <h3 class="panel-title"><?php echo get_cat_name(18)?><span class="more pull-right"><a title="更多" href="<?php echo get_category_link(18)?>"><i class="fa fa-ellipsis-h"></i></a></span></h3>
     </div>
     <div class="panel-body  panel_cms">
      <ul>
 <?php query_posts('showposts=5&cat=18&orderby=rand'); while(have_posts()) : the_post();?>
                <li><a href="<?php the_permalink(); ?>"><time><?php the_time('Y年m月d日') ?></time><i class="fa fa-chevron-right"></i><?php the_title(); ?></a></li>
            <?php endwhile;?>
    <?php wp_reset_query(); ?>
      </ul>
     </div>
    </div>
   </div>
<!-- 第四栏开始 -->
   <div class="col-sm-6 index_cms_6 4">
    <div class="panel panel-default index_cms_panel" data-aos="fade-up">
     <span class="icon"><i class="fa fa-globe"></i></span> 
     <div class="panel-heading">
      <h3 class="panel-title"><?php echo get_cat_name(29)?><span class="more pull-right"><a title="更多" href="<?php echo get_category_link(29)?>"><i class="fa fa-ellipsis-h"></i></a></span></h3>
     </div>
     <div class="panel-body  panel_cms">
      <ul>
 <?php query_posts('showposts=5&cat=29&orderby=rand'); while(have_posts()) : the_post();?>
                <li><a href="<?php the_permalink(); ?>"><time><?php the_time('Y年m月d日') ?></time><i class="fa fa-chevron-right"></i><?php the_title(); ?></a></li>
            <?php endwhile;?>
    <?php wp_reset_query(); ?>
      </ul>
     </div>
    </div>
   </div>