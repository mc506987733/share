<?php get_header();?>
<?php $posts = query_posts($query_string . '&orderby=date&showposts=10'); ?>
								<?php while ( have_posts() ) : the_post(); 
									include( get_template_directory().'/excerpt.php' );endwhile; ?>

<!-- 分页start -->
<div id="ajax-load-posts">
<?php next_posts_link(__(' <button id="fa-loadmore" class="button button-more wow fadeInUp" data-wow-delay="0.3s" data-home="true" data-paged="2" data-action="fa_load_postlist" data-total="12" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;">加载更多</button>')); ?></div>
<?php wp_reset_query(); ?>
<?php get_footer(cms);?>
					</div>
	</div>

<?php get_sidebar(); ?>
</section>
<?php get_footer();?>