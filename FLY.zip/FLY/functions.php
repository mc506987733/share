<?php

@include(TEMPLATEPATH.'/page/photo/functions.php');
date_default_timezone_set('PRC');
define('THEME_URI', get_stylesheet_directory_uri());
require get_template_directory() . '/functions_fly.php';
require get_template_directory() . '/other/plugin-update-checker.php';
require get_template_directory() . '/other/functions/dianzan.php';
require get_template_directory() . '/other/functions/fbp.php';
require get_template_directory() . '/other/functions/htseo.php';
require get_template_directory() . '/other/functions/tag.php';
require get_template_directory() . '/other/functions/zzwaf.php';
require get_template_directory() . '/other/functions/fenleiseo.php';
require get_template_directory() . '/other/functions/shortcode.php';
require get_template_directory() . '/other/functions/title.php';
require('ajax/main.php');
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://cdn.24bp.cn/FLY.json',
	__FILE__,
	'ThemeKing-FLY'
);
//写作优化
remove_filter (  'the_content' ,  'wpautop'  );
//搜索匹配度优化
if(is_search()){
add_filter('posts_orderby_request', 'search_orderby_filter');
}
function search_orderby_filter($orderby = ''){
    global $wpdb;
    $keyword = $wpdb->prepare($_REQUEST['s']);
    return "((CASE WHEN {$wpdb->posts}.post_title LIKE '%{$keyword}%' THEN 2 ELSE 0 END) + (CASE WHEN {$wpdb->posts}.post_content LIKE '%{$keyword}%' THEN 1 ELSE 0 END)) DESC,
{$wpdb->posts}.post_modified DESC, {$wpdb->posts}.ID ASC";
}
/* 评论作者链接新窗口打开 */
function specs_comment_author_link() {
    $url    = get_comment_author_url();
    $author = get_comment_author();
    if ( empty( $url ) || 'http://' == $url )
        return $author;
    else
        return "<a target='_blank' href='$url' rel='external nofollow' class='url'>$author</a>";
}
add_filter('get_comment_author_link', 'specs_comment_author_link');

function suxingme_add_page($_var_21, $_var_22, $_var_23 = '')
{
	$_var_24 = get_pages();
	$_var_25 = !1;
	foreach ($_var_24 as $_var_26) {
		if (strtolower($_var_26->post_name) == strtolower($_var_22)) {
			$_var_25 = !0;
		}
	}
	if ($_var_25 == !1) {
		$_var_27 = wp_insert_post(array('post_title' => $_var_21, 'post_type' => 'page', 'post_name' => $_var_22, 'comment_status' => 'closed', 'ping_status' => 'closed', 'post_content' => '', 'post_status' => 'publish', 'post_author' => 1, 'menu_order' => 0));
		if ($_var_27 && $_var_23 != '') {
			update_post_meta($_var_27, '_wp_page_template', $_var_23);
		}
	}
}
function suxingme_add_pages()
{
	global $pagenow;
	if ('themes.php' == $pagenow && isset($_GET['activated'])) {
		suxingme_add_page('我的邻居', 'tags-page', 'page/link/py.php');
		suxingme_add_page('相册', 'photo-page', 'page/photo/functions.php');
	}
}
add_action('load-themes.php', 'suxingme_add_pages');
add_theme_support('post-formats', array('gallery', 'aside'));
function rename_post_formats($_var_28)
{
	if ($_var_28 == '相册') {
		return '左图模板';
	}
	if ($_var_28 == '图像') {
		return '介绍模板';
	}
	return $_var_28;
}


add_action( 'widgets_init', 'my_unregister_widgets' );   
function my_unregister_widgets() {   
 
    unregister_widget( 'WP_Widget_Archives' );   
    unregister_widget( 'WP_Widget_Calendar' );   
    unregister_widget( 'WP_Widget_Categories' );   
    unregister_widget( 'WP_Widget_Links' );   
    unregister_widget( 'WP_Widget_Meta' );   
    unregister_widget( 'WP_Widget_Pages' );   
    unregister_widget( 'WP_Widget_Recent_Comments' );   
    unregister_widget( 'WP_Widget_Recent_Posts' );   
    unregister_widget( 'WP_Widget_RSS' );   
    unregister_widget( 'WP_Widget_Search' );   
    unregister_widget( 'WP_Widget_Tag_Cloud' );   
    unregister_widget( 'WP_Nav_Menu_Widget' );   
    
}

function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );
 
/**
 * Filter function used to remove the tinymce emoji plugin.
 * 
 * @param    array  $plugins  
 * @return   array             Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}


//修复 WordPress 找回密码提示“抱歉，该key似乎无效”

function reset_password_message( $message, $key ) {
 if ( strpos($_POST['user_login'], '@') ) {
 $user_data = get_user_by('email', trim($_POST['user_login']));
 } else {
 $login = trim($_POST['user_login']);
 $user_data = get_user_by('login', $login);
 }
 $user_login = $user_data->user_login;
 $msg = __('有人要求重设如下帐号的密码：'). "\r\n\r\n";
 $msg .= network_site_url() . "\r\n\r\n";
 $msg .= sprintf(__('用户名：%s'), $user_login) . "\r\n\r\n";
 $msg .= __('若这不是您本人要求的，请忽略本邮件，一切如常。') . "\r\n\r\n";
 $msg .= __('要重置您的密码，请打开下面的链接：'). "\r\n\r\n";
 $msg .= network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') ;
 return $msg;
}
add_filter('retrieve_password_message', 'reset_password_message', null, 2);

function get_the_link_items($id = null){
    $bookmarks = get_bookmarks('orderby=date&category=' .$id );
    $output = '';
    if ( !empty($bookmarks) ) {
        $output .= '<ul class="link-items fontSmooth">';
        foreach ($bookmarks as $bookmark) 
        {
            $output .=  '<li class="link-item"><a class="link-item-inner effect-apollo" href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" rel="' . $bookmark->link_rel . '" >';
            
            if(($bookmark->link_notes)){
                $output .= get_avatar($bookmark->link_notes,64);
            }else if($bookmark->link_image){
                
                $output .= '<img alt="' . $bookmark->link_description . '" src="'. $bookmark->link_image .'" title="' . $bookmark->link_description . '">';
                
            }
            else{
                
                $output .= '<img alt="' . $bookmark->link_description . '" src="'.get_template_directory_uri().'/img/avatar.png" title="' . $bookmark->link_description . '">';
                
            }
            
            $output .= '<span class="sitename">'. $bookmark->link_name .'</span></a></li>';
        }
        $output .= '</ul><div class="clearfix"></div>';
    }
    return $output;
}

function get_link_items(){
    $linkcats = get_terms( 'link_category' );
    if ( !empty($linkcats) ) {
        foreach( $linkcats as $linkcat){ 
                if( $linkcat->description ) $linkdes .= '- <span class="link-description">' . $linkcat->description . '</span>';           
            $result .=  '<div class="link-title"><span>'.$linkcat->name.'</span>'.$linkdes.'</div>';
           
            $result .=  get_the_link_items($linkcat->term_id);
        }
    } else {
        $result = get_the_link_items();
    }
    return $result;
}



//自动修改Wordpress文章、评论、缩略图片的IMG属性
function add_image_placeholders( $content ) {
    // Don't lazyload for feeds, previews, mobile
    if( is_feed() || is_preview() || ( function_exists( 'is_mobile' ) && is_mobile() ) )
        return $content;
    // Don't lazy-load if the content has already been run through previously
    if ( false !== strpos( $content, 'data-original' ) )
        return $content;
    // In case you want to change the placeholder image
    $placeholder_image = apply_filters( 'lazyload_images_placeholder_image', get_template_directory_uri() . '/img/lazy.png' );
    // This is a pretty simple regex, but it works
    $content = preg_replace( '#<img([^>]+?)src=[\'"]?([^\'"\s>]+)[\'"]?([^>]*)>#', sprintf( '<img${1}src="%s" data-original="${2}"${3}><noscript><img${1}src="${2}"${3}></noscript>', $placeholder_image ), $content );
    return $content;
}

add_filter( 'gettext_with_context', 'wpdx_disable_open_sans', 888, 4 );
function wpdx_disable_open_sans( $translations, $text, $context, $domain ) {
  if ( 'Open Sans font: on or off' == $context && 'on' == $text ) {
    $translations = 'off';
  }
  return $translations;
}
add_action( 'wp_footer', 'bdPushData', 999);
 if(!function_exists('baidu_check_record')){
  function baidu_check_record($url,$post_id){
    $baidu_record  = get_post_meta($post_id,'baidu_record',true);
    if( $baidu_record != 1){
        $url='http://www.baidu.com/s?wd='.$url;
        $curl=curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        $rs=curl_exec($curl);
        curl_close($curl);
        if( BD_PUSH == 'yes' && !preg_match_all('/提交网址/u',$rs) && preg_match_all('/百度为您找到相关结果/u',$rs)){
            update_post_meta($post_id, 'baidu_record', 1) || add_post_meta($post_id, 'baidu_record', 1, true);
            return 1;
        } else {
            return 0;
        }
    } else {
       return 1;
    }
  }
}
 
if(!function_exists('XGpush')){
  function XGpush() {
    global $wpdb;
    $post_id = ( null === $post_id ) ? get_the_ID() : $post_id;
    $currentUrl = home_url(add_query_arg(array()));
    //这里修改了下：给get_permalink指定了文章ID
    if(baidu_check_record(get_permalink($post_id), $post_id) == 0 && $currentUrl == get_permalink($post_id)) {
        echo "<script>(function(){
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
            } else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(bp, s);
            })();
            (function(){
                var src = (document.location.protocol == 'http:') ? 'http://js.passport.qihucdn.com/11.0.1.js?af9e600e6a4ba6d33cd7f1b088210cf7':'https://jspassport.ssl.qhimg.com/11.0.1.js?af9e600e6a4ba6d33cd7f1b088210cf7';
                document.write('<script src=\"' + src + '\" id=\"sozz\"><\/script>');
            })();</script>";
   }
 }
}

add_action('comment_text', 'comments_embed_img', 2);
function comments_embed_img($comment) {
        $size = auto;
        $comment = preg_replace(array('#(http://([^\s]*)\.(jpg|gif|png|JPG|GIF|PNG))#','#(https://([^\s]*)\.(jpg|gif|png|JPG|GIF|PNG))#'),'<img src="$1" alt="" width="'.$size.'" height="" />', $comment);
        return $comment;
}

function record_visitors(){
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if($post_ID) 
        {
          $post_views = (int)get_post_meta($post_ID, 'views', true);
          if(!update_post_meta($post_ID, 'views', ($post_views+1))) 
          {
            add_post_meta($post_ID, 'views', 1, true);
          }
        }
    }
}
add_action('wp_head', 'record_visitors');  

function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
    global $post;
    $post_ID = $post->ID;
    $views = (int)get_post_meta($post_ID, 'views', true);
    if ($echo) echo $before, number_format($views), $after;
    else return $views;
};


add_filter('pre_option_link_manager_enabled','__return_true');

function excerpt_length($length) {
    return 120;
}
add_filter('excerpt_length', 'excerpt_length');

function nice_exp($more){
    return '...';
}
add_filter('excerpt_more', 'nice_exp');

function customTitle($limit) {
    $title = get_the_title($post->ID);
    if(strlen($title) > $limit) {
        $title = substr($title, 0, $limit) . '..';
    }
    echo $title;
}

function ClearHtml($content) {  
   $preg = "/<\/?[^>]+>/i";
   return preg_replace($preg,'',$content);
}

function par_pagenavi($range = 9){   
if ( is_singular() ) return;  
global $wp_query, $paged;  
$max_page = $wp_query->max_num_pages;  
if ( $max_page == 1 ) return;  
    if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}    
    if($max_page > 1){if(!$paged){$paged = 1;}    
    if($paged != 1){echo "<li><a href='" . get_pagenum_link(1) . "' ' title='跳转到首页'> 首页 </a></li>";}    
    previous_posts_link(' « ');    
    if($max_page > $range){    
        if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<li><a href='" . get_pagenum_link($i) ."'";    
        if($i==$paged)echo " ";echo ">$i</a></li>";}}    
    elseif($paged >= ($max_page - ceil(($range/2)))){    
        for($i = $max_page - $range; $i <= $max_page; $i++){echo "<li><a href='" . get_pagenum_link($i) ."'";    
        if($i==$paged)echo " '";echo ">$i</a></li>";}}    
    elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){    
        for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<li><a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " ";echo ">$i</a></li>";}}}    
    else{for($i = 1; $i <= $max_page; $i++){echo "<li><a href='" . get_pagenum_link($i) ."'";    
    if($i==$paged)echo " ";echo ">$i</a></li>";}}    
    next_posts_link(' » ');    
    if($paged != $max_page){echo "<li><a href='" . get_pagenum_link($max_page) . "'  title='跳转到最后一页'> 尾页 </a></li>";}}    
}
register_nav_menus( array(
'primary' => __( 'Primary Navigation', 'twentyten' ),
) );
 
if ( function_exists('register_sidebar') ) {   
  register_sidebar(array(   
    'name'=>'侧边栏',   
    'before_widget' => '<li id="%1$s" class="sidebar_li %2$s">',   
    'after_widget' => '</li>',   
    'before_title' => '<h3>',   
    'after_title' => '</h3>',   
  ));   
 }  

function my_custom_taxonomy_columns_content( $content, $column_name, $term_id )
{
    if ( 'my_term_id' == $column_name ) {
        $content = $term_id;
    }
    return $content;
}
add_filter( 'manage_category_custom_column', 'my_custom_taxonomy_columns_content', 10, 3 );
add_filter( 'manage_special_custom_column', 'my_custom_taxonomy_columns_content', 10, 3 );
add_filter( 'get_avatar' , 'local_random_avatar' , 1 , 5 );
function local_random_avatar( $avatar, $id_or_email, $size, $default, $alt) {
    if ( ! empty( $id_or_email->user_id ) ) {
        $avatar = '//ww2.sinaimg.cn/large/a15b4afegy1fof65jkrhgj20dc0dc0tu.jpg';
    }else{
        $random = mt_rand(1, 12);
        $avatar = '//coding.net/u/mc666666/p/plphoto/git/raw/master/'. $random .'.jpg';
    }
    $avatar = "<img alt='{$alt}' src='{$avatar}' class='avatar avatar-{$size} photo' height='{$size}' width='{$size}' />";
    return $avatar;
}

function wp_compress_html()
{
function wp_compress_html_main ($buffer)
{
    $initial=strlen($buffer);
    $buffer=explode("<!--wp-compress-html-->", $buffer);
    $count=count ($buffer);
    for ($i = 0; $i <= $count; $i++)
    {
        if (stristr($buffer[$i], '<!--wp-compress-html no compression-->'))
        {
            $buffer[$i]=(str_replace("<!--wp-compress-html no compression-->", " ", $buffer[$i]));
        }
        else
        {
            $buffer[$i]=(str_replace("\t", " ", $buffer[$i]));
            $buffer[$i]=(str_replace("\n\n", "\n", $buffer[$i]));
            $buffer[$i]=(str_replace("\n", "", $buffer[$i]));
            $buffer[$i]=(str_replace("\r", "", $buffer[$i]));
            while (stristr($buffer[$i], '  '))
            {
            $buffer[$i]=(str_replace("  ", " ", $buffer[$i]));
            }
        }
        $buffer_out.=$buffer[$i];
    }
    //$final=strlen($buffer_out);
    //$savings=($initial-$final)/$initial*100;
    //$savings=round($savings, 2);
    //$buffer_out.="\n<!--压缩前的大小: $initial bytes; 压缩后的大小: $final bytes; 节约：$savings% -->";
    return $buffer_out;
}
ob_start("wp_compress_html_main");
}
add_action('get_header', 'wp_compress_html');


function get_thumbnail() {  
    global $post;
    $html = '';
    for ($i=0; $i < 3; $i++) { 

            $image ='<img class="thumbnails lazy" data-original="'.constant("THUMB_SMALL_DEFAULT").'" alt="'. get_the_title().'" />';   


        $html .= '<li>
                    <div class="image-item">
                        <a class="simg" href="'.get_permalink(get_the_ID()).'">
                            '.$image.'
                        </a>
                    </div>
                </li>';
    }

    return $html;
}

if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');

function post_thumbnail_src(){
    global $post;
    if( $values = get_post_custom_values("thumb") ) {   //输出自定义域图片地址
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = $values [0];
    } elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];   //获取该图片 src
        }elseif( ('post_thumbnail') ){
            $post_thumbnail_src = ('post_thumbnail');
        }else{  
            //如果日志中没有图片，则显示随机图片
            //$random = mt_rand(1, 5);
            //$post_thumbnail_src = get_template_directory_uri().'/img/random/'.$random.'.jpg';
            //如果日志中没有图片，则显示默认图片
            $post_thumbnail_src = get_template_directory_uri().'/img/xgflybg.jpg';
        }
    }
    return $post_thumbnail_src;
} 

function get_post_thumbnail_url($post_id){
    $post_id = ( null === $post_id ) ? get_the_ID() : $post_id;
    $post=get_post($post_id);
    if( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post_id),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];   //获取该图片 src
        }else{  
            $post_thumbnail_src = '';
        }
    }
    return $post_thumbnail_src;
}

function getImages($content, $num = 4){
    $pattern = '/<img[^>]*src=\"([^\"]+)\"[^>]*\/?>/si';
    $matches = array();
    $images = array();
    if (preg_match_all($pattern, $content, $matches)) {
        foreach ($matches[1] as $index => $imgUrl) {
            $images[] = $imgUrl;
            if ($index >= ($num - 1)) {
                break;
            }
        }
    }
    return $images;
}
function all_img($content){
    $images = getImages($content, 4);
    if (empty($images)) {
        echo "没有图片";
        return;
    }
    if (count($images) == 1) {
        echo '<img src="',$images[0],'" />';
    } else {
        // 自己把下面的XXX替换成你的URL地址
        if (count($images) == 1) {
            echo '<img src="'. get_template_directory_uri() .'/timthumb.php?src='.urlencode($imgUrl).'&h=173.98&w=231.98&zc=1" alt="' . get_the_title() . '"/>'; 
        } else {
            echo '<div class="image-item"><a class="simg" href="'.get_permalink(get_the_ID()).'" >';
            foreach ($images as $imgUrl) {
                echo '<img src="'. get_template_directory_uri() .'/timthumb.php?src='.urlencode($imgUrl).'&h=173.98&w=231.98&zc=1" alt="' . get_the_title() . '"/>';
            }
            echo '</a></div>';
        }
    }
}

function gzippy() {
	ob_start('ob_gzhandler');
}

if(!stristr($_SERVER['REQUEST_URI'], 'tinymce') && !ini_get('zlib.output_compression')) {
	add_action('init', 'gzippy');
}

add_filter('the_content','web589_the_content_nofollow',999);
function web589_the_content_nofollow($content){
 preg_match_all('/href="(http.*?)"/',$content,$matches);
 if($matches){
 foreach($matches[1] as $val){
 if( strpos($val,home_url())===false ) 
 $content=str_replace("href=\"$val\"", "rel=\"nofollow\" href=\"" . get_bloginfo('wpurl'). "/go.php?url=" .base64_encode($val). "\"",$content);
 }
 }
 return $content;
}


function search_filter_page($query) {
    if ($query->is_search) {
        $query->set('post_type', 'post');
    }
    return $query;
}
add_filter('pre_get_posts','search_filter_page');


function wpse_11826_search_by_title( $search, $wp_query ) {
    if ( ! empty( $search ) && ! empty( $wp_query->query_vars['search_terms'] ) ) {
        global $wpdb;
        $q = $wp_query->query_vars;
        $n = ! empty( $q['exact'] ) ? '' : '%';
        $search = array();
        foreach ( ( array ) $q['search_terms'] as $term )
            $search[] = $wpdb->prepare( "$wpdb->posts.post_title LIKE %s", $n . $wpdb->esc_like( $term ) . $n );
        if ( ! is_user_logged_in() )
            $search[] = "$wpdb->posts.post_password = ''";
        $search = ' AND ' . implode( ' AND ', $search );
    }
    return $search;
}
add_filter( 'posts_search', 'wpse_11826_search_by_title', 10, 2 );