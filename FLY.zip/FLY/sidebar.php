<aside class="sidebar"<?php global $ashu_option ?>>   
	<ul class="row">
	<li class="widget widget_ui_blogger" data-aos="fade-up">
	    <article class="panel-side">
	        <div class="fly_weibo">
        	<ul class="blogger_side">
        	    <div id="weiboShow">
        	        <div class="grid-weibo-show shadow-hover">
        		        <header id="shead">&nbsp;</header>
        		        <div id="user-login" class="contentt">
        			        <div class="avatar">
        	                	  <img src="<?php echo $ashu_option['ashu']['_baba_xigu']; ?>">
								  <i title="<?php  the_author(); ?>" class="author-ident"></i>
        	                	<div class="overlay">
                                    <a href="/wp-login.php" class="expand" data-target="#myLogin" data-toggle="modal" data-backdrop="static" target="_blank">登录</a>
                                </div>
        				        <span class="rank"></span>
        			        </div>
							<h4><?php  the_author(); ?></h4>
        			        <p class="seta"><script src="//coding.net/u/mc666666/p/plphoto/git/raw/master/api.js"></script></p>
							<div class="author-social"> <span class="author-blog"> <a href="http://wpa.qq.com/msgrd?v=3&amp;uin=53964220&amp;site=qq&amp;menu=yes" rel="nofollow" target="_blank"><i class="fa fa-qq"></i>客服</a> </span> <span class="author-weibo"> <a href="https://24bp.cn" rel="nofollow" target="_blank"><i class="fa fa-thumbs-up"></i>店铺</a> </span> </div>
        		        </div>
        		        <div id="user-div" class="contentt" style="display:none;">
        			        <div class="avatar">
        	                	  <span class="dlimg"></span>
								  <i class="dlname"></i>
        				        <span class="rank"></span>
        			        </div>
                            <div class="sidebar-user row">
								<div class="dlcd"></div>
            					<div class="col-sm-6 sideli"><a href="https://pjax.cn/?user&posts"><i class="fa fa-user-circle-o"></i> 用户中心</a></div>
            					<div class="col-sm-6 sideli"><a href="https://pjax.cn/?user&comments"><i class="fa fa-comments-o"></i> 评论管理</a></div>
            					<div class="col-sm-6 sideli dlset"></div>
            					<div class="col-sm-6 sideli login_logout"><a href="javascript:void(0);" target="_blank"><i class="fa fa-sign-out"></i> 退出登陆</a></div>
                            </div>
        		        </div>
        		        <footer>
        					<ul class="blogger_footer">
        						<li><strong><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?></strong><span>文章</span></li>
        						<li><strong><?php echo $count_tags = wp_count_terms('post_tag'); ?></strong><span>标签</span></li>
        						<li><strong>运行</strong><span><?php echo floor((time()-strtotime('2018-3-14'))/86400); ?>天</span></li>
        					</ul>
        		        </footer>
        	        </div>
                </div>
            </ul>
            </div>
	    </article>
	</li>
      <li class="widget widget_ui_statistics" data-aos="fade-up">
  <div class="widget-title"><span class="icon"><i class="fa fa-signal"></i></span>
    <h3>网站统计</h3>
  </div>
	<ul>
		<li>已被视淫：<?php
$counterFile = "counter.txt";
$fp = fopen($counterFile,"a+");
$num = fgets($fp,5);
$num += 1;
print ""."$num"."次";
fclose($fp);
$fpp=fopen($counterFile,"w");
fwrite($fpp, $num);
fclose($fpp);
?>
</li>
		<li>日志总数：<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>
篇</li>
		<li>标签总数：<?php echo $count_tags = wp_count_terms('post_tag'); ?>
条</li>
		<li>页面总数：<?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?>
页</li>
		<li>分类总数：<?php echo $count_categories = wp_count_terms('category'); ?>
个</li>
		<li>运行天数：<?php echo floor((time()-strtotime('2018-3-14'))/86400); ?>
天</li>
		<li>链接总数：<?php $link = $wpdb->get_var("select count(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?>
		<li>最后更新：<?php $last = $wpdb->get_results("select max(post_modified) AS max_m from $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->max_m));echo $last; ?>

	</ul>
</li>
	<li class="widget widget_text" data-aos="fade-up">
	<div class="widget-title"><span class="icon"><i class="fa fa-th-large"></i></span>
        <h3>加入我们</h3>
    </div>
		<div class="widget-zdy"><a rel="external nofollow" target="_blank" class="simg" href="https://24bp.cn" style="padding:0;"><img style="padding: 2px;max-width: 354px;"  src="<?php echo $ashu_option['ashu']['_ashu_join']; ?>" alt="FLY" title="FLY"></a></div>
	</li>
    <li class="widget widget_posts_list" data-aos="fade-up">
      	<article class="panel-side">
	<header class="panel-header"><span class="icon"><i class="fa fa-random"></i></span>
	<h3 class="widget-title">随机文章</h3></header>
<ul class="sidebar-randlog-list">
  <?php $rand_posts = get_posts('numberposts=6&orderby=rand');
foreach( $rand_posts as $post ) : ?>
        	<li><a href="<?php the_permalink(); ?>" title="发布于<?php the_time('Y-m-d') ?>">
	<span class="thumbnails"><span><img src="<?php echo post_thumbnail_src(); ?>" alt="<?php the_title(); ?>" class="thumbs" alt="<?php the_title(); ?>"></span></span>
    <span class="text"><?php the_title(); ?></span></a>
	</li>
                <?php endforeach; wp_reset_query(); ?>
	    </ul>
	</article>
    </li>
     <li class="widget widget_posts_list" data-aos="fade-up">
	<article class="panel-side">
	<header class="panel-header"><span class="icon"><i class="fa fa-line-chart"></i></span>
	<h3 class="widget-title">最新文章</h3></header>
<?php query_posts('showposts=5'); ?>
	<ul class="sidebar-posts-list">
<?php while (have_posts()) : the_post(); ?>
        	<li>
	<a href="<?php the_permalink(); ?>" class="thumbnail-link" rel="bookmark"><img src="<?php echo post_thumbnail_src(); ?>" class="thumbnailside" width="50" height="50" title="<?php the_title(); ?>" alt="<?php the_title(); ?>"></a>
	<div class="right-box"><h4 class="side-title"><a href="<?php the_permalink(); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
	<ul class="side-meta">
	<li class="date date-abb">
	<span class="fa fa-clock-o"></span>
	<a href="<?php the_permalink(); ?>" title="发布于<?php the_time('Y-m-d') ?>">
	<time pubdate="pubdate"><?php the_time('Y-m-d') ?></time>
	</a>
	</li>
	<li class="views">
	<span class="fa fa-eye"></span>
	<a href="javascript:;" title="浏览了<?php post_views('',''); ?>次"><?php post_views('',''); ?></a>
	</li>
	</ul>
	</div>
	</li>
<?php endwhile;?>
	    </ul>
	</article>
    </li>
    <li class="widget span12 widget_recent_comments" data-aos="fade-up">
	<article class="panel-side">
	<header class="panel-header"><span class="icon"><i class="fa fa-comments-o"></i></span>
	<h3 class="widget-title">最新评论</h3></header>
         	<ul class="sidebar-comments-list show-avatars side-ul">
                              <li>
            <a href="https://pjax.cn/emadmin.html#5408" title="来自《西顾很帅》的评论">
                <img alt="33562064" src="<?php echo get_template_directory_uri(); ?>/other/headimg_dl_1" class="avatar avatar-36 photo" height="36" width="36">
				<div class="right-box"><p class="comment-text">暂待开发！</p></div>
            </a>
        </li>
</ul>
      </article>
    </li>
<li class="widget widget_ui_ad" data-aos="fade-up">
	<ul>
	    <li><div class="aditem">
			<a class="list-group-item list-group-item-success adli" href="https://24bp.cn" target="_blank">西顾博客</a><div class="adtooltip"><p>
			我吼吼吼吼~</p><div class="adarrow"></div></div></div>
		</li>
	    <li><div class="aditem">
	        <a class="list-group-item list-group-item-info adli" rel="nofollow" href="https://24bp.cn">V站</a><div class="adtooltip"><p>
			今天还像看我装逼吗？</p><div class="adarrow"></div></div></div>
		</li>
	    <li><div class="aditem">
	        <a class="list-group-item list-group-item-warning adli" rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&amp;uin=53964220&amp;site=qq&amp;menu=yes">广告位招租 - 10软妹币/月</a><div class="adtooltip"><p>广告招租联系qq1501700017</p><div class="adarrow"></div></div></div>
		</li>
	    <li><div class="aditem">
	        <a class="list-group-item list-group-item-danger adli" rel="nofollow" href="http://wpa.qq.com/msgrd?v=3&amp;uin=53964220&amp;site=qq&amp;menu=yes">广告位招租 - 10软妹币/月</a><div class="adtooltip"><p>广告招租联系qq1501700017</p><div class="adarrow"></div></div></div>
		</li>
	</ul>
</li>
</ul>
</aside>
