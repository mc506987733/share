function getCookie(name) {   
    var start = document.cookie.indexOf( name + "=" );   
    var len = start + name.length + 1;   
  
    if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) )   
        return null;   
  
    if ( start == -1 )   
        return null;   
  
    var end = document.cookie.indexOf( ';', len );   
  
    if ( end == -1 )   
        end = document.cookie.length;   
    return unescape( document.cookie.substring( len, end ) );   
}   
function ashu_isCookieEnable() {   
    var today = new Date();   
    today.setTime( today.getTime() );   
    var expires_date = new Date( today.getTime() + (1000 * 60) );   
  
    document.cookie = 'ashu_cookie_test=test;expires=' + expires_date.toGMTString() + ';path=/';   
    var cookieEnable = (getCookie('ashu_cookie_test') == 'test') ?  true : false;   
    //document.cookie = 'ludou_cookie_test=;expires=Fri, 3 Aug 2001 20:47:11 UTC;path=/';   
    return cookieEnable;   
}   
    
jQuery(document).ready(function($) {   
    var ashu_token = 1;   
    $('.vote_up a').click(function(){   
        //检查浏览器是否启用cookie功能   
        if( !ashu_isCookieEnable() ) {   
            alert("很抱歉，您不能给本文投票！");   
            return;   
        }   
        if( ashu_token != 1 ) {   
            alert("您的鼠标点得也太快了吧？！");   
            return false;   
        }   
        ashu_token = 0;   
        //获取投票a标签中的rel值   
        var full_info = $(this).attr( 'rel' );   
        var arr_param = full_info.split( '_' ); //以字符"_"分割   
        //发起ajax   
        $.ajax({   
            url:ajax_url, //ajax地址   
            type:'POST',   
            //请求的参数包括action   rating  postid三项   
            data:'action=vote_post&rating=' + arr_param[ 0 ] + '&postid=' + arr_param[ 1 ],   
            //返回数据   
            success:function(results){   
                if(results=='n'){   
                    alert('评价失败');   
                    ashu_token = 1;   
  
                }   
                if (results=='y'){   
                    //如果成功，给前台数据加1   
                    var upd_vd = 'vup' + arr_param[ 1 ];   
                    $('#'+upd_vd).text(parseInt($("#"+upd_vd).text())+1);   
                    ashu_token = 1;   
                       
                }   
                if (results=='h'){   
                    ashu_token = 1;   
                    alert('已经发表过评价了');   
                }   
                if (results=='e'){   
                    ashu_token = 1;   
                    alert('评价失败');   
                }   
            }   
        });   
    });   
       
    $('.vote_down a').click(function(){   
        if( !ashu_isCookieEnable() ) {   
            alert("很抱歉，您不能给本文投票！");   
            return;   
        }   
        if(ashu_token != 1) {   
            alert("您的鼠标点得也太快了吧？！");   
            return false;   
        }   
        ashu_token = 0;   
  
        var full_info = $(this).attr( 'rel' );   
        var arr_param = full_info.split( '_' );   
        $.ajax({   
            url:ajax_url,   
            type:'POST',   
            data:'action=vote_post&rating=' + arr_param[ 0 ] + '&postid=' + arr_param[ 1 ],   
            success:function(results){   
                if(results=='n'){   
                    alert('评价失败');   
                    ashu_token = 1;   
                }   
                if (results=='y'){   
                    var upd_vd = 'vdown' + arr_param[ 1 ];   
                    $("#"+upd_vd).text(parseInt($("#"+upd_vd).text())+1);   
                    ashu_token = 1;   
                }   
                if (results=='h'){   
                    ashu_token = 1;   
                    alert('已经发表过评价了');   
                }   
                if (results=='e'){   
                    ashu_token = 1;   
                    alert('发生未知错误');   
                }   
            }   
        });   
    });   
});  