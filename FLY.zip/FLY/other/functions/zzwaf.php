<?php
//防止CC攻击
session_start(); //开启session
$timestamp = time();
$ll_nowtime = $timestamp ;
//判断session是否存在 如果存在从session取值，如果不存在进行初始化赋值
if ($_SESSION){
$ll_lasttime = $_SESSION['ll_lasttime'];
$ll_times = $_SESSION['ll_times'] + 1;
$_SESSION['ll_times'] = $ll_times;
}else{
$ll_lasttime = $ll_nowtime;
$ll_times = 1;
$_SESSION['ll_times'] = $ll_times;
$_SESSION['ll_lasttime'] = $ll_lasttime;
}
//现在时间-开始登录时间 来进行判断 如果登录频繁 跳转 否则对session进行赋值
if(($ll_nowtime - $ll_lasttime) < 3){
if ($ll_times>=5){
header("location:https://img.6star.ltd");//可以换成其他链接，比如站内的404错误显示页面(千万不要用动态页面)
exit;
}
}else{
$ll_times = 0;
$_SESSION['ll_lasttime'] = $ll_nowtime;
$_SESSION['ll_times'] = $ll_times;
}
//防止恶意url攻击
if (strlen($_SERVER['REQUEST_URI']) > 255 ||
	strpos($_SERVER['REQUEST_URI'], "eval(") ||
	strpos($_SERVER['REQUEST_URI'], "base64")) {
		@header("HTTP/1.1 414 Request-URI Too Long");
		@header("Status: 414 Request-URI Too Long");
		@header("Connection: Close");
		@exit;
}
