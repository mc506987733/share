<?php
//后台登陆数学验证码
function myplugin_add_login_fields() {
//获取两个随机数, 范围0~9
$num1=rand(0,9);
$num2=rand(0,9);
//最终网页中的具体内容
    echo "<p><label for='math' class='small'>验证码</label><br /> $num1 + $num2 = ?<input type='text' name='sum' class='input' value='' size='25' tabindex='4'>"
."<input type='hidden' name='num1' value='$num1'>"
."<input type='hidden' name='num2' value='$num2'></p>";
}
add_action('login_form','myplugin_add_login_fields');
function login_val() {
$sum=$_POST['sum'];//用户提交的计算结果
switch($sum){
//得到正确的计算结果则直接跳出
case $_POST['num1']+$_POST['num2']:break;
//未填写结果时的错误讯息
  case null:wp_die('提示:您还没有填写验证码呢！');break;
//计算错误时的错误讯息
default:wp_die('提示: 是不是又眼花啦？你验证码写错了！');
}
}
add_action('login_form_login','login_val');
//HTTP_USER_AGENT防攻击防采集
$ua = $_SERVER['HTTP_USER_AGENT'];
$now_ua = array('FeedDemon ','ZmEu','Indy Library','oBot','jaunty'); //将恶意USER_AGENT存入数组
if(!$ua) { //禁止空USER_AGENT，dedecms等主流采集程序都是空USER_AGENT，部分sql注入工具也是空USER_AGENT
header("Content-type: text/html; charset=utf-8");
wp_die('请勿采集本站，因为采集的站长木JJ！');
}else{
    foreach($now_ua as $value )
    if(eregi($value,$ua)) {
    header("Content-type: text/html; charset=utf-8");
    wp_die('请勿采集本站，因为采集的站长木JJ！');
    }
}