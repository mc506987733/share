<?php
/*
Template Name: 月友链-简洁版
*/

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php bloginfo('name'); ?>丨我的邻居</title>
<meta name="description" content="<?php bloginfo('url');?>">
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/page/link/uz-link.css" type="text/css" media="screen" />
</head>
<body class="ikmoe-body-background">
<div class="ikmoe-body">
<div class="ikmoe-head">
<ul id="ikmoe-nav">
<li><a href="">我的小伙伴们</a></li>
<li><a href="index.php">博客</a></li><!--默认跳转自己首页-->
<li><a href="http://ikmoe.com/70.html">申请友链</a></li>
Ctrl+F5搜索
</ul>
</div></div>
<!-- 顶部导航结束 -->

<div class="ikmoe-layout">
<?php $bookmarks=get_bookmarks();
  if ( !empty($bookmarks) ){
    echo '<ul class="ikmoe-link">';
    foreach ($bookmarks as $bookmark) {
      echo '<li><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" >'.'<div class="ikmoe-tx">'.get_avatar($bookmark->link_notes,128) . '<span class="ikmoe-text">'. $bookmark->link_name .'</span></a></li>';
    }
    echo '</ul>';
  }
?>
</div>



<!--你的统计JS代码↓↓↓↓↓↓↓-->

<!--如不需要，请无视↑↑↑↑↑↑-->



<!-- 月友链-白，月宅酱版权所有，该注释请勿删除 -->
<div class="ikmoe-footer"><a href="<?php bloginfo('template_url'); ?>" rel="nofollow">ThemeKing - FLY</a></div>

<!-- 请勿删除:版本号4.0 更新时间2017-10-8 -->
</body>
</html>