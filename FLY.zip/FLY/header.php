<!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="UTF-8">
	<meta name="generator" content="WordPress">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-title" content="ThemeKing">
    <link rel="dns-prefetch" href="//coding.net">
  <?php echo xg_wp_seo(); ?>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  	<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/board.css" type="text/css" media="all">
	<script src="//coding.net/u/mc666666/p/FLY1.2js/git/raw/master/jquery.min.js" type="text/javascript"></script>
    <script src="//coding.net/u/mc666666/p/FLY1.2js/git/raw/master/jquery.pjax.js" type="text/javascript"></script>	
    <script src="//coding.net/u/mc666666/p/FLY1.2js/git/raw/master/bootstrap.min.js" type="text/javascript"></script>
	<script src="//coding.net/u/mc666666/p/FLY1.2js/git/raw/master/jquery.lazyload.js" type="text/javascript"></script>
	<script src="//coding.net/u/mc666666/p/FLY1.2js/git/raw/master/tinymce.min.js" type="text/javascript"></script>
    <script type="text/javascript">
var pjaxtheme = '<?php bloginfo('url'); ?>/wp-content/themes/FLY/';
var blog_url = '<?php bloginfo('url'); ?>';
var pjax_id = '#WP-FLY';
var ThemeVersion = 1.2;
</script>
<style>body{background: url('https://img.6star.ltd/bg.png') top center fixed;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;}.bg-fixed{width:100%;height:100%;position:fixed;top:0;left:0;z-index:-998;background:url('https://img.6star.ltd/bg-fixed.png') repeat}.sidebar.fixed{position:fixed;left:50%;bottom:0;margin-left:230px;}.sidebar.pins{position:absolute;left:50%;margin-left:230px;right:386px}.navbar-default .navbar-nav>.active>a, .navbar-default .navbar-nav>.active>a:focus, .navbar-default .navbar-nav>.active>a:hover, .navbar-default .navbar-nav>.dropdown>a:focus,.navbar-default .navbar-nav>.dropdown>a:hover,.navbar-default .navbar-nav>li>a:hover,.navbar-default .navbar-nav>.open>a,.navbar-default .navbar-nav>.open>a:focus,.navbar-default .navbar-nav>.open>a:hover{color: #45B6F7;background-color: transparent}.btn-info{background-color:#45B6F7;border-color:#45B6F7}.btn-info:hover{background-color:#45B6F7;border-color:#45B6F7}#post-box .post-title,#post-box .post-title{border-left: 5px solid #45B6F7}.panel_cms li a:hover,.posts-default-title h2 a:hover{color:#45B6F7}.pagination ul>.active>span{background:#45B6F7;color:#fff}.related-posts>li .related-posts-panel:hover{border-color:#45B6F7;box-shadow:0 0 2px #45B6F7;-moz-box-shadow:0 0 2px #45B6F7}.context img:hover{border-color:#45B6F7;box-shadow:0 0 2px #45B6F7;-moz-box-shadow:0 0 2px #45B6F7}.context a{border-bottom:1px solid #45B6F7}.grid-weibo-show .u-btn-submit{border:1px solid #45B6F7;background:#45B6F7}.link-li>a:hover,.sidebar-posts-list>li .side-title-r>a:hover,.sidebar-posts-list>li .side-title>a:hover,.sidebar-posts-list>li>a:hover,.author a:hover,.pagination>li>a,.pagination>li>span,.page-navi .current,.page-navi .pages,.page-navi a,.comments-list li .right-box>.comment-meta .edit-link a,.comments-list li .right-box>.comment-meta .reply a,.comments-list li .right-box>.waiting,.tw li:hover .tw-content,.page-tw a,ul.readers-list a:hover em,ul.readers-list a:hover strong,.posts-gallery-content h2 a:hover{color:#45B6F7}.focusmo a:hover h4{background-color:#45B6F7;opacity:.8}.backtop:hover{background:#45B6F7;border:1px solid #45B6F7;color:#fff}.comments-list-nav span,.tw li:hover .atitle:after{background:#45B6F7}.page-navi .current,.page-navi a:hover{background:#45B6F7;border-color:#45B6F7;color:#FFF}.page-tw span,.page-tw a:focus,.page-tw a:hover,ul.readers-list img:hover{background-color:#45B6F7}::-webkit-scrollbar-thumb{background-color:#45B6F7}.logtop dl p .spbut:hover{border:1px solid #45B6F7;background-color:#45B6F7}
</style>
</head>
<body class="nav-fixed">
<nav id="header" class="navbar navbar-default navbar-fixed-top">
	<div class="container">
		<div class="navbar-header"<?php global $ashu_option ?>>
			<a href="<?php bloginfo('url'); ?>" class="navbar-brand logo"><img src="<?php echo $ashu_option['ashu']['_ashu_logo']; ?>" alt="ThemeKing"></a>

		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			<span class="sr-only"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
	    </button>
		</div>
	 <?php wp_nav_menu(
								array(	
                                    	'container'       => 'div',
	                                    'container_class' => 'collapse navbar-collapse navbar-right',
                                  	    'container_id'    => 'bs-example-navbar-collapse-1',
										'menu_class' =>'nav navbar-nav nav-top', 
                                        'category_before' => '<li>',    
                                        'category_after' => '</li>',
									) 
							); 
				?>

          <!--爸爸的导航完成-->
  			<div class="fly-nav-right">
				<div class="login-nav"><a href="/wp-login.php" class="expand" data-target="#myLogin" data-toggle="modal" data-backdrop="static" target="_blank"><i class="fa fa-user-circle"></i></a></div>
				<div class="fly-search fly-search-s"><i class="fa fa-search"></i></div>
			</div>
  </div>
</nav>
<div id="FLY"><section class="container">
	<div class="content-wrap">
		<div class="content">
<!--轮播图开始-->
<!--  data-ride="carousel" 自动轮播 -->
<div id="wowslider-container1">
	<div class="ws_images"<?php global $ashu_option ?>>
		<ul>
			<li><a href="<?php bloginfo('url'); ?>" title=""><img src="<?php echo $ashu_option['ashu']['_ashu_fuck1']; ?>" title="" alt=""></a></li>
			<li><a href="<?php bloginfo('url'); ?>" title=""><img src="<?php echo $ashu_option['ashu']['_ashu_fuck2']; ?>" title="" alt=""></a></li>
			<li><a href="<?php bloginfo('url'); ?>" title=""><img src="<?php echo $ashu_option['ashu']['_ashu_fuck3']; ?>" title="" alt=""></a></li>
			</ul>
	</div>
<div class="ws_shadow"></div>
</div>
<div class="clearfloat"></div>
<!--轮播图结束-->
<!-- 公告 -->
	<article class="excerpt-minic excerpt-minic-index" data-aos="fade-up">
	    <div class="textgg"> <ul class="gglb"><i class="fa fa-bullhorn"></i>
            <div class="bulletin"> 
            	<ul>
            	            	<li><script src="//coding.net/u/mc666666/p/plphoto/git/raw/master/api.js"></script></li>
            	            	<li><script src="//coding.net/u/mc666666/p/plphoto/git/raw/master/api.js"></script></li>
            	            	<li><script src="//coding.net/u/mc666666/p/plphoto/git/raw/master/api.js"></script></li>
            					</ul>
            </div>
	    </ul></div> 
	</article>
<!-- 首页6格 -->
	<article class="row excerpt-list" data-aos="fade-up">
                <?php global $ashu_option ?>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-l">
			<i class="fa fa-picture-o"></i>
			<h4>相册图库</h4>
			<p>相册图库介绍</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text']; ?>">点击进入</a>
			</div></div>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-2">
			<i class="fa fa-music"></i>
			<h4>音乐收藏</h4>
			<p>音乐点播页面</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text1']; ?>">点击进入</a>
			</div></div>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-3">
			<i class="fa fa-list"></i>
			<h4>文章归档</h4>
			<p>所有文章都搁着</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text2']; ?>">点击进入</a>
			</div></div>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-4">
			<i class="fa fa-twitch"></i>
			<h4>站长工具</h4>
			<p>网络收集的软件</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text3']; ?>">点击进入</a>
			</div></div>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-5">
			<i class="fa fa-file-text-o"></i>
			<h4>留言互动</h4>
			<p>不要打广告哦</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text4']; ?>">点击进入</a>
			</div></div>
		<div class="col-sm-2 col-xs-4 col-list"><div class="indexebox indexebox-6">
			<i class="fa fa-link"></i>
			<h4>我的邻居</h4>
			<p>我的小伙们</p>
			<a class="btn btn-info btn-sm" href="<?php echo $ashu_option['ashu']['_ashu_text5']; ?>">点击进入</a>
			</div></div>
	</article>

<article class="focusmo" data-aos="fade-up">
            <?php query_posts('showposts=4&cat=-111'); ?> 
  <ul>
    <?php while (have_posts()) : the_post(); ?> 
    <li class="large"><a href="<?php the_permalink() ?>">
 <img class="lazy" src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/lazyload.gif" data-original="<?php echo post_thumbnail_src(); ?>" >
      <h4><?php the_title(); ?></h4>
      </a>
    </li>
               <?php endwhile;?>
    </ul>
          <?php query_posts('showposts=4&cat=-111'); ?> 
  <ul>
             <?php while (have_posts()) : the_post(); ?> 
    <li> 
      <a href="<?php the_permalink() ?>"><img class="lazy" src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/lazyload.gif" data-original="<?php echo post_thumbnail_src(); ?>" width="640" height="480">
        <h4><?php the_title(); ?></h4>
      </a>
  
    </li>
            <?php endwhile;?> 
  </ul>
          </article><!-- 广告位置：首页_列表_横幅_h760w80 | ID:1 -->
<article class="excerpt-list" data-aos="fade-up">
  <a href="<?php bloginfo('url'); ?>" target="_blank">
    <img class="lazy" src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/lazyload.gif" data-original="<?php echo get_template_directory_uri(); ?>/images/as.png" style="width: 100%;"></a>
          </article>

<!-- 广告结束 投放请联系站长 -->
<!-- 列表 -->