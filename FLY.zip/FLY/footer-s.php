<div class="clearfloat"></div>
<div id="mobile-footer">
<ul id="mobile-menu">
<li> <a href="<?php bloginfo('url'); ?>"> <span class="fa fa-home"></span> 首页 </a></li>
<li> <a href="<?php echo $ashu_option['ashu']['_ashu_text']; ?>"> <span class="fa fa-twitch"></span> 相册 </a></li>
<li> <a href="javascript:;" class="fly-search-s"> <span class="fa fa-search"></span> 搜索 </a></li>
<li> <a href="<?php bloginfo('url'); ?>/wp-login.php"> <span class="fa fa-info"></span> 关于 </a></li>
<li id="mobile-login"><a href="" class="expand" data-target="#myLogin" data-toggle="modal" data-backdrop="static" target="_blank"> <span class="fa fa-user"></span> 用户 </a></li>
</ul>
</div>
<footer class="footer">
  <div class="container copy-right">
    <div class="footer-tag-list">
		        <span>Copyright © 2018 <a href="<?php bloginfo('url'); ?>"><?php the_author(); ?></a>
        <a href="http://www.miibeian.gov.cn" target="_blank"><?php echo get_option( 'zh_cn_l10n_icp_num' );?></a> </span>
		<span>Powered by <a href="https://cn.wordpress.org" target="_blank">WordPress</a> · Theme by <a href="https://24bp.cn" target="_blank">Cegoo</a></span>
    </div>
  </div>
</footer>
<div class="loading"><div class="loading1"><div class="block"></div><div class="block"></div><div class="block"></div><div class="block"></div><div class="section-left"></div><div class="section-right"></div></div></div>
<div class="rollbar"><ul>
<li class="conment-btn"></li>
<li><a href="javascript:(scrollTo());"><i class="fa fa-chevron-up"></i></a><h6>去顶部<i></i></h6></li>
</ul></div>
<div class="search-forms">
	<form method="get" action="<?php bloginfo('url'); ?>">
		<div class="search-form-inner">
			<div class="search-form-box">
				 <input class="form-search" type="text" name="s" placeholder="键入搜索关键词">
				 <button type="submit" id="btn-search" class="search-go"><i class="fa fa-search"></i> </button>
				 
			</div>
			<div class="search-commend">
				<h4>大家都在搜</h4>
				<ul>
					        			<li class="search-go"><a href="https://pjax.cn/tag/笔记">薄荷我操你妈</a></li>
        			<li class="search-go"><a href="https://pjax.cn/tag/登录可见">烟雨我操你妈</a></li>
        			<li class="search-go"><a href="https://pjax.cn/tag/U盘启动">我草完薄荷草烟雨</a></li>
        			<li class="search-go"><a href="https://pjax.cn/tag/奥创纪元">操完烟雨操薄荷</a></li>

        				</ul>
			</div>
		</div>                
	</form> 
	<div class="close-search">
		<span class="close-top"></span>
		<span class="close-bottom"></span>
    </div>
</div>
<div class="bg-fixed"></div><script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.swipebox.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/sweetalert.min.js"></script>
<script>
$(function() {$("img.lazy").lazyload({effect: "fadeIn"});});
$( document ).ready(function() {$('.swipebox' ).swipebox();});
if($("#wowslider-container1").length>0){$.getScript(''+ pjaxtheme +'js/slider.js');}
</script>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/aos.css">
<script type="text/javascript">
AOS.init({
	offset: 200,
	duration: 500,
	easing: 'ease-in-sine',
	delay: 100,
	once: true,
});
</script>
<script>
$(document).ready(function(){
  $(".wintips-close").click(function(){
    $(".wintips").fadeOut();
  });
});
</script>
<div class="wintips" style="display: block;">
  <div class="wintips-thumb">
    <img  src="//coding.net/u/mc666666/p/WordPress-ThemeKing-Fly/git/raw/master/flyman.png">
</div>
  <h2>FLY主题</h2>
  <p>ThemeKing-FLY主题现正热售中...</p>
  <p><a href="https://24bp.cn/1016.html" class="btn btn-info btn-wintips">立即购买</a></p>
  <span etap="wintips_close" class="wintips-close"><i class="fa fa-times-circle-o"></i></span>
</div>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
</body>
</html>