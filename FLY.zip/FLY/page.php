<?php get_header(other);?>
<?php $posts = query_posts($query_string . 'showposts=10'); ?>
								<?php while ( have_posts() ) : the_post(); 
									include( get_template_directory().'/excerpt.php' );endwhile; ?>

<!-- 分页start -->
<div class="pagination">
  <ul>
    <p class="active">
<?php par_pagenavi(9); ?>
</p>
 </ul>
</div>
<?php wp_reset_query(); ?>
<?php get_footer(cms);?>
					</div>
	</div>

<?php get_sidebar(); ?>
</section>
<?php get_footer();?>