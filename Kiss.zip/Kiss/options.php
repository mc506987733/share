<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
	'bg' => array(
		'type' => 'image',
		'name' => '默认头图',
		'description' => '背景图也是它',
		'values' => array(
            TEMPLATE_URL . 'images/post.jpg',
        ),
    ),
	'lx' => array(
        'type' => 'radio',
        'name' => '头部类型',
        'description' => '',
        'values' => array('xh' => '虚化','jc' => '锯齿'),
        'default' => 'jc'
    ),
	'tx' => array(
		'type' => 'image',
		'name' => '头像',
		'values' => array(
            TEMPLATE_URL . 'images/tx.jpg',
        ),
    ),
	'name' =>array(
		'type' => 'text',
		'name' => '昵称',
		'description' => '',
		'values' => array(
			'瑾忆',
		),
	),
	'qm' => array(
		'type' => 'text',
		'name' => '个性签名',
		'description' => '建议不超过十个字',
		'default' => '突如其来的装逼让我无法呼吸',
    ),
	'qq' => array(
		'type' => 'text',
		'name' => 'QQ账号',
		'description' => '',
		'default' => '837233287',
    ),
	'webtime' => array(
		'type' => 'text',
		'name' => '建站日期',
		'description' => '格式：xxxx-xx-xx',
		'default' => '2016-07-19',
	),



);