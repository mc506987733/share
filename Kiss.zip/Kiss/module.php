<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>

<?php function img_random()
{
    $imgsrc = TEMPLATE_URL."images/random/".rand(1, 3).".png";
    return $imgsrc;
} function img_zw($content)
{
    preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $img);
    $imgsrc = !empty($img[1]) ? $img[1][0] : '';
    if ($imgsrc):return $imgsrc;
    endif;
} function img_fj($blogid)
{
    $db = MySql::getInstance();
    $sql = $db->query("SELECT * FROM ".DB_PREFIX."attachment WHERE blogid=".$blogid." AND (`filepath` LIKE '%jpg' OR `filepath` LIKE '%gif' OR `filepath` LIKE '%png') ORDER BY `aid` ASC LIMIT 1");
    $imgsrc = '';
    while ($row = $db->fetch_array($sql)) {
        $imgsrc .= BLOG_URL.substr($row['filepath'], 3, strlen($row['filepath']));
    }
    return $imgsrc;
}?>
<?php function blog_author($uid)
{
    global $CACHE;
    $user_cache = $CACHE->readCache('user');
    $author = $user_cache[$uid]['name'];
    $avatar = empty($user_cache[$uid]['photo']['src']) ? BLOG_URL.'admin/views/images/avatar.jpg' : BLOG_URL.$user_cache[$uid]['photo']['src'];
    echo '<a href="'.Url::author($uid).'" title="'.$author.'"><img src="'.$avatar.'" class="avatar avatar-30 photo" height="30" width="30">'.$author.'</a>';
}?>

<?php

//格式化內容工具
function blog_tool_purecontent($content, $strlen = null){
        $content = str_replace('繼續閱讀>>', '', strip_tags($content));
        if ($strlen) {
            $content = subString($content, 0, $strlen);
        }
        return $content;
}
?>

<?php
//blog：导航
function blog_navi(){
    global $CACHE; 
    $navi_cache = $CACHE->readCache('navi');
    ?>
            <?php
            foreach($navi_cache as $value):
            if ($value['pid'] != 0) {
                continue;
            }
            if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
            ?>
               <li><a href="<?php echo BLOG_URL; ?>admin/"><i class="iconfont czs-setting"></i>管理</a></li>
               <li><a href="<?php echo BLOG_URL; ?>admin/?action=logout"><i class="iconfont czs-airplane"></i>退出</a></li>
            <?php 
                continue;
            endif;
            $newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
            $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
            $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'active' : 'common';
            ?>
            <?php if (!empty($value['children']) || !empty($value['childnavi'])) :?>
            <li class="dropdown">
                <?php if (!empty($value['children'])):?>
                <a href="<?php echo $value['url']; ?>"<?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <ul class="dropdown-menu">
                    <?php foreach ($value['children'] as $row){
                            echo '<li><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
                <?php if (!empty($value['childnavi'])) :?>
                <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
                <ul class="dropdown-menu">
                    <?php foreach ($value['childnavi'] as $row){
                            $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                            echo '<li><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                    }?>
                </ul>
                <?php endif;?>
            </li>
            <?php else: ?>
            <li>
            <a href="<?php echo $value['url']; ?>" <?php echo $newtab;?> />
            <?php if($value['naviname']=="首页"){  ?><i class="iconfont czs-home"></i> 
             <?php }elseif($value['naviname']=="微语"){  ?><i class="iconfont czs-cup"></i>
			 <?php }elseif($value['naviname']=="留言"){  ?><i class="iconfont czs-talk"></i>  
             <?php }elseif($value['naviname']=="关于"){  ?><i class="iconfont czs-hacker"></i> 
             <?php }elseif($value['naviname']=="归档"){  ?><i class="iconfont czs-read"></i>  
             <?php }elseif($value['naviname']=="相册" || $value['naviname']=="微图册" ){  ?><i class="iconfont czs-image"></i> 
             <?php }elseif($value['naviname']=="友链"){  ?><i class="iconfont czs-link-l"></i>   
             <?php }elseif($value['naviname']=="登录"){  ?><i class="iconfont czs-lock"></i>
             <?php }else{  ?><i class="iconfont czs-doc-file"></i> 
            <?php } ?>
			 <?php echo $value['naviname']; ?>
			 </a>
            </li>
 <?php endif;?>
<?php endforeach; ?>
<?php }?>
<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<img src=\"".TEMPLATE_URL."/images/top.png\" title=\"首页置顶文章\" /> " : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<img src=\"".TEMPLATE_URL."/images/sortop.png\" title=\"分类置顶文章\" /> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])): ?>
	<span class="h-categories"><a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" rel="category tag"><?php echo $log_cache_sort[$blogid]['name']; ?></a></span>
	<?php endif;?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		$tag = '';
		foreach ($log_cache_tags[$blogid] as $value){
			$tag .= "#<a href=\"".Url::tag($value['tagurl'])."\">".$value['tagname'].'</a>';
		}
		echo '<div class="hr-short"></div><div class="post-tags">'.$tag.'</div>';
	}
}
?>


<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
	shuffle($link_cache);$link_cache = array_slice($link_cache,0,100);
	?>
<div id="link">
 <ul>
<?php foreach($link_cache as $value): ?>
 <li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
<?php endforeach; ?>
 </ul>
</div>
<!-- #link -->
<?php }?>
<?php
//最近访客
function guest($num){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$name = $user_cache[1]['name'];
	$DB = MySql :: getInstance();
	$sql = "SELECT count(*) AS comment_nums,poster,mail,url FROM ".DB_PREFIX."comment where date >0 and poster !='". $name ."' and  poster !='' and hide ='n' group by poster order by comment_nums DESC limit 0,$num";
	$log_content = $content[1];
	if(strpos($log_content, '[READERWALL-WEEK]') > -1) {
		$cur_time_span = strtotime('last Year',strtotime('Sunday'));
	}
	$result = $DB -> query( $sql );
	while($row = $DB -> fetch_array($result)){
		$img = "<li title=\"".$row[ 'poster' ]."(吐槽了".$row[ 'comment_nums' ]."次)\"><a href=\"" . $row[ 'url' ] . "\" target=\"_blank\" rel=\"nofollow\"><img class=\lazy\" src=\"".eflyGravatar($row['mail'])."\"></a><div class=\"active-bg\"><div class=\"active-degree\" style=\"width:".$row[ 'comment_nums' ]."px;\"></div></div></li>";
		if( $row[ 'url' ] ){
		$tmp = "<li title=\"".$row[ 'poster' ]."(哔哔了".$row[ 'comment_nums' ]."次)\"><a href=\"" . $row[ 'url' ] . "\" target=\"_blank\" rel=\"nofollow\"><img class=\"lazy\" src=\"".eflyGravatar($row['mail'])."\"></a><div class=\"active-bg\"><div class=\"active-degree\" style=\"width:".$row[ 'comment_nums' ]."px;\"></div></div></li>";
		}else{
			$tmp = $img;
		}
		$output .= $tmp;
	}
	$output = ''. $output .'';
	return $output ;
}
?>
<?php  
//文章内容功能
function article_index($content) {  
            global $CACHE;  
            $tag_cache = $CACHE->readCache('tags');  
            $matches = array();  
            $ul_li = '';  
            $r = "/<h3>([^<]+)<\/h3>/im";  
    if(preg_match_all($r,$content,$matches)) {  
           foreach($matches[1] as $num => $title) {  
           $content = str_replace($matches[0][$num], '<h2 id="title-'.$num.'">'.$title.'</h2>', $content);  
           $ul_li .= '<li><a href="#title-'.$num.'" title="'.$title.'">'.$title."</a></li>\n";  
             }  
 $content = "\n<div id=\"article-index\"> 
 <b>[文章目录]</b> 
 <ul id=\"index-ul\">\n" . $ul_li . "</ul> 
 </div>\n" . $content;  
 }  
 foreach($tag_cache as $value){  
                $tag_url = Url::tag($value['tagurl']);  
                $keyword = $value['tagname'];  
                $cleankeyword = stripslashes($keyword);  
                $url = "<a href=\"{$tag_url}\" title=\"浏览关于“{$cleankeyword}”的文章\" target=\"_blank\" >{$cleankeyword}</a>";  
                $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s';  
                $content = preg_replace($regEx,$url,$content);          
}  
 
return $content;  
}  
?>  

<?php
//blog-tool:获取qq头像
function eflyGravatar($email) {
	$hash = md5(strtolower($email));
	$avatar = 'https://secure.gravatar.com/avatar/' . $hash . '?s=100&d=monsterid';
	if(empty($email)){
		$eflyGravatar = TEMPLATE_URL.'images/avatar.jpg';
	}
	else if(strpos($email,'@qq.com')){
		$qq = str_replace("@qq.com","",$email);
		if(is_numeric($qq) && strlen($qq) > 4 && strlen($qq) < 13){
			$eflyGravatar = 'https://q2.qlogo.cn/headimg_dl?dst_uin='.$qq.'&spec=100';
		}
		else{
			$eflyGravatar = $avatar;
		}
	}
	else{
		$eflyGravatar = $avatar;
	}
	return $eflyGravatar;
}
?>
<?php
//comment：输出评论人等级
function echo_levels($comment_author_email,$comment_author_url){
	$DB = MySql::getInstance();
	global $CACHE;
	$user_cache = $CACHE->readCache('user'); 
	$adminEmail = '"'.$user_cache[1]['mail'].'"';
	if($comment_author_email==$adminEmail){
		echo '<cite class="svip" style="background-color:#F7A8A8;">博主</cite>';
	}
	$sql = "SELECT cid as author_count,mail FROM ".DB_PREFIX."comment WHERE mail != '' and mail = $comment_author_email and hide ='n'";
	$res = $DB->query($sql);
	$author_count = mysql_num_rows($res);
	if($author_count>=0 && $author_count<5 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#FFEB3B;">Lv.1</cite>';
	else if($author_count>=5 && $author_count<10 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#33CCFF;">Lv.2</cite>';
	else if($author_count>=10 && $author_count<20 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#6600FF;">Lv.3</cite>';
	else if($author_count>=20 && $author_count<30 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#9966CC;">Lv.4</cite>';
	else if($author_count>=30 &&$author_count<40 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#66FF99;">Lv.5</cite>';
	else if($author_count>=40 && $author_coun<50 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#66FF66;">Lv.6</cite>';
	else if($author_count>=50 && $author_coun<60 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#00CCCC;">Lv.7</cite>';
	else if($author_count>=60 && $author_coun<70 && $comment_author_email!=$adminEmail)
		echo '<cite class="vip" style="background-color:#FF33CC;">Lv.8</cite>';
}
?>
<?php
//blog：评论列表
function blog_comments($comments,$params){
    extract($comments);
    if($commentStacks): ?>

	<?php endif; ?>
<ol class="commentlist" id="comment_list">
	<?php
	$isGravatar = Option::get('isgravatar');
	$comnum = count($comments);  
   foreach($comments as $value){  
   if($value['pid'] != 0){$comnum--;}}  
   $page = isset($params[5])?intval($params[5]):1;  
   $i= $comnum - ($page - 1)*Option::get('comment_pnum'); 
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	<li class="comment even thread-even depth-<?php echo $comment['cid']; ?> parent plt" id="comment-<?php echo $comment['cid']; ?>">
	<div id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body">
		<div class="comment-author vcard">
			<img src="<?php echo eflyGravatar($comment['mail']); ?>" class="avatar">
			<cite class="fn"><?php echo $comment['poster']; ?></cite>
			<span class="commentmetadata"><?php echo $comment['date']; ?></span>
			<?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?>
			<a rel="nofollow" id="reply" class="comment-reply-link no-ajax" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">@回复</a>
		    
			<span class="floor"><?php if ($i == 1){ echo "沙发";}elseif ($i == 2){echo "板凳";}elseif ($i == 3){ echo "地板";}else{ echo "#".$i; }?></span>
		</div>
		<p><?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',$comment['content']); ?></p>

	</div>
	<?php blog_comments_children($comments, $comment['children'],$i,0); ?>
	</li>
	<?php $i--;endforeach;?>
    <div id="pagenavi">
	    <?php echo $commentPageUrl;?>
    </div>
</ol>
<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children,$i,$x){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$x=$x+1; 
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	$bicomment = preg_replace("#\@瑾忆:#",'<span class="vip" style="background-color: #FFC107;">@博主:</span>',$comment['content']);
	?>
	<ul class="children">
		<li class="comment byuser bypostauthor even depth-<?php echo $comment['cid']; ?> parent" id="comment-<?php echo $comment['cid']; ?>">
		<div id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body">
			<div class="comment-author vcard">
				<img src="<?php echo eflyGravatar($comment['mail']); ?>" class="avatar">
				<cite class="fn"><?php echo $comment['poster']; ?></cite>
				<span class="commentmetadata"><?php echo $comment['date']; ?></span>
				<?php echo echo_levels("\"".strip_tags($comment['mail'])."\"","\"".$comment['url']."\"");?>
				<a rel="nofollow" id="reply" class="comment-reply-link no-ajax" href="#comment-<?php echo $comment['cid']; ?>" onclick="commentReply(<?php echo $comment['cid']; ?>,this)">@回复</a>
			    
				<span class="floor"><?php echo '#'.$i.'-'.$x; ?></span>
			</div>

			<p><?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',$bicomment); ?></p>
			
		</div>
		<?php blog_comments_children($comments, $comment['children'],$i,$x); ?>
		</li>
	</ul>
	<?php endforeach; ?>
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
<div id="comment-place">
<div class="wantcom" style="display: block;"><a> 点我发言 (*╹▽╹*) </a></div>
 <div id="comment-post" class="comment-respond">
 <div class="form-body">

	<p class="errotext"><span class="noreport">取消评论</span><span class="reply"><a rel="nofollow" id="cancel-reply" href="javascript:void(0);" onclick="cancelReply()"> 取消回复</a></span></p>
	<form action="<?php echo BLOG_URL; ?>index.php?action=addcom" method="post" id="commentform" class="comment-form">
<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
<?php if(ROLE == ROLE_VISITOR): ?>
    <img src="<?php if(ROLE == ROLE_VISITOR){ echo TEMPLATE_URL.'/images/avatar.jpg'; }else{ echo _g("tx"); }; ?>"  style="width: 100px;
    height: 100px;
    order-radius: 100px;
    border-radius: 500px;" class="ajaxurl">
 <div class="comment-form-info">

		<div class="form-group">
  <input id="author" name="comname" type="text" value="<?php echo $ckname; ?>" size="30" maxlength="245" aria-required="true" required="required" placeholder="昵称 (必填)">
		</div>
		<div class="form-group">
  <input id="email" name="commail" type="email" value="<?php echo $ckmail; ?>" size="30" maxlength="100" aria-describedby="email-notes" aria-required="true" required="required" placeholder="邮件地址 (必填)">
		</div>
		<div class="form-group">
  <input id="url" name="comurl" type="url" value="<?php echo $ckurl; ?>" size="30" maxlength="200" placeholder="个人主页 (选填)">
		</div>
 </div>
<?php endif; ?>
		<div class="form-group">
			<textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" aria-required="true" required="required" placeholder="既然来了就说点什么吧..."></textarea>
		</div>
<?php if(SEND_MAIL == 'Y' || REPLY_MAIL == 'Y'){ ?>
<label class="demo--label">
        <input class="demo--radio" value="y" type="checkbox" name="send">
        <span class="demo--checkbox demo--radioInput"></span>允许邮件通知
</label>
<?php } ?>
    <span class="OwO">
            <div class="OwO-logo"><span>OwO</span></div>
            <div class="OwO-body">
                <ul class="OwO-items OwO-items-biaoqing OwO-items-show" style="max-height: 100px;">
<?php for($i = 1; $i <= 39; $i++): ?>
 <a class="OwO-item" data-action="addSmily" data-smilies="smilies<?php echo $i; ?>"><img src="<?php echo TEMPLATE_URL; ?>images/face/<?php echo $i; ?>.png"></a>
<?php endfor; ?>
                </ul>
            </div>
    </span>

		<div class="form-submit">
			<input name="submit" type="submit" id="submit" class="submit" value="点我，发表评论"><input type="hidden" name="comment_post_ID" value="1" id="comment_post_ID">
			<input type="hidden" name="pid" id="comment-pid" value="0"/>
		</div>
	</form>
 </div>
 </div>
</div>

	<?php endif; ?>
<?php }?>