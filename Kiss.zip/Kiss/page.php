<?php 
/**
 * 自定义文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<style>
#header .post-bg{-webkit-filter: blur(10px);filter: blur(10px);}
#header .inner {display: none;}
@media(max-width:650px){#header {display: none;}}
</style>
<div class="echo_log">
<main>
<div class="h">
<div class="h-inner h-bg" style="background-image: url(//www.005.tv/uploads/allimg/180831/1K31044A-27.jpg);"></div>
<div class="h-content">
<h1><?php echo $log_title; ?></h1>
</div>
<div class="post-data">
  <div class="author-name"><?php blog_author($author); ?></div>
 <span class="u-time"><i class="czs-time-l"></i> <?php echo date('Y,m,d', $date);?></span>
 <span class="u-comment"><i class="czs-talk-l"></i> <?php echo $comnum; ?></span>
</div>
</div>
<section class="books">
			<article class="post single">
<?php echo preg_replace("#\[smilies(\d+)\]#i",'<img src="'.TEMPLATE_URL.'images/face/$1.png" id="smilies$1" alt="表情$1"/>',article_index($log_content)); ?>
<?php doAction('log_related', $logData); ?>
<?php doAction('echo_log', $logData); ?>

			</article>
<?php if($allow_remark == 'y'): ?>
<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
<?php blog_comments($comments,$params); ?>
<?php endif;?>
</section>
</main>
</div>
<?php
 include View::getView('footer');
?>