<?php
/*
Template Name:Kiss
Description:双栏模板，简洁优雅，这是我国庆节7天做出来的作品，我会一直维护这款主题的。
Version:1.0
Author:1梦
Author Url:http://cnm1.cn
Sidebar Amount:1
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="baidu-site-verification" content="WHTEOigWVa" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<link href="<?php echo TEMPLATE_URL; ?>caomei/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo TEMPLATE_URL; ?>js/prism.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>js/prism.js"></script>
<script type='text/javascript' src="//cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
<script type='text/javascript' src='//cdn.jsdelivr.net/npm/pjax@0.2.6/pjax.min.js?ver=0.2.6'></script>
<script src="<?php echo TEMPLATE_URL; ?>js/view-image.min.js"></script>
<!--[if lt IE 9]>
<script src="//cdn.bootcss.com/html5shiv/r29/html5.min.js"></script>
<script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<?php doAction('index_head'); ?>
<style>
#header:after{background: rgba(0,0,0,0.2) url(<?php echo TEMPLATE_URL; ?>images/bg-fixed.png) repeat!important;}
.divider_border {display: block;}

.bg {
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    display: block;
}
.banner {
    position: relative;
    height: 360px;
    transition: all ease-out .6s;
    -webkit-transition: all ease-out .6s;
    -moz-transition: all ease-out .6s;
    -o-transition: all ease-out .6s;
}
.banner:before {
    display: block;
    content: "";
    position: absolute;
    height: 100%;
    width: 100%;
    z-index: 1;
    box-shadow: inset 0 0 1px 1px rgba(0,0,0,0.1);
    /*background: rgba(79, 47, 79, 0.5)*/
}
.banner:before {
    background: linear-gradient(left , rgba(226,35,18,0.5),rgba(56,181,160,0.5) 100%);
    background: -o-linear-gradient(left , rgba(226,35,18,0.5),rgba(56,181,160,0.5) 100%);
    background: -ms-linear-gradient(left , rgba(226,35,18,0.5),rgba(56,181,160,0.5) 100%);
    background: -moz-linear-gradient(left , rgba(226,35,18,0.5),rgba(56,181,160,0.5) 100%);
    background: -webkit-linear-gradient(left , rgba(226,35,18,0.5),rgba(56,181,160,0.5) 100%);
}

.header {
    background: #fff;
    padding: 0;
    border-radius: 0;
    position: fixed;
    width: 1200px;
    z-index: 10;
}

.width{
	margin: 0 auto;
    max-width: 1200px;
    width: 100%;
    overflow: hidden;
	position: relative;
}

.backstage {
    position: relative;
    float: right;
    margin-right: 10px;
    display: block;
    padding: 10px 0;
    height: 42px;
    cursor: pointer;
}
.backstage img {
    border-radius: 50%;
}


#mo-nav {
    transform: translate(-265px, 0);
    position: fixed;
    z-index: 99;
    top: 0;
    left: 0;
    overflow-x: hidden;
    overflow-y: auto;
    width: 260px;
    height: 100%;
    background-color: #FFF;
    -webkit-transition-duration: .5s;
    transition-duration: .5s;
    transition: .5s;
    box-shadow: 1px 0 4px rgba(0,0,0,.3);
}

#mo-nav .m-avatar{width:260px;}
#mo-nav .m-avatar img{width:260px;}
#mo-nav ul{margin:10px 0;padding:0;width:260px;}
#mo-nav ul li{letter-spacing:.02em;transition-duration: 0.25s;}
#mo-nav ul li a {line-height: 16px;font-size: 15px;padding: 14px 20px 14px 65px;display: block;font-weight: 500;position: relative;color: #4C4C4C;}
#mo-nav ul li a:hover{background: #efefef;}
#mo-nav li ul{display: none;margin:0;background: #fafafa;}
#mo-nav li:hover ul{display: block;}
#mo-nav ul li a i {position: absolute;left: 25px;font-size: 15px;top: 2px;width: 25px;text-align: center;padding: 13px 0;}
.off-overlay {

    border-radius: 0;
    bottom: 0;
    display: none;
    height: 100%;
    left: 0;
    position: fixed;
    right: 0;
    top: 0;
    width: 100%;
    opacity: 0;

}
.width {    
    margin: 0 auto;
    max-width: 1200px;
    width: 100%;
    overflow: hidden;
    position: relative;}
</style>


</head>
<body>
    <div id="mo-nav" class="menu-3">
		<div class="logo">
            <img src="http://www.005.tv/uploads/allimg/180928/1H9343P3-3.jpg">
		</div>
        <div class="navi"><ul id="menu-menu-1"><?php blog_navi(); ?></ul></div>
        <div class="footer">
			<p>Powered By <a href="/" target="_blank">EMLOG</a> <br> Theme By <a href="https://biantan.org">Kiss</a></p>
		</div>
	</div>

<a href="javascript:(0);" class="header-off off-overlay" data-pjax-state="external"></a>

<div class="content">
    <header class="header">
  <div class="width">
    <div class="menu">
     <div class="menul">
         <a href="javascript:void(0);" class="header-btn" data-pjax-state="">
		    <span class="iconfont czs-menu-l"></span>
		   </a>
	</div>
	  <h1 class="logoi">1梦的博客</h1>
      <div class="backstage"><img src="http://www.005.tv/uploads/allimg/180820/42-1PR010542LR.jpg"  height="36" width="36"></div>
	</div>
  </div>

</header>

        <div class="menu-2">
				<div class="logo">
                    <img src="http://www.005.tv/uploads/allimg/180820/42-1PR010542LR.jpg">
				</div>
                    <div class="navi"><ul id="menu-menu-1"><?php blog_navi(); ?></ul></div>
                <div class="footer">
					<p>Powered By <a href="http://emlog.net" target="_blank">EMLOG</a> <br> Theme By <a href="https://biantan.org">Kiss</a></p>
				</div>
		</div>
<div class="width">
<div id="wrapper">