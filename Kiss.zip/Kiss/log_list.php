<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php doAction('index_loglist_top'); ?>
<div id="greeting">
	<div class="container">
		<span class="messages-content">Kiss主题制作完毕 交流QQ群：<a href="https://jq.qq.com/?_wv=1027&amp;k=55eW9Lj" target="_blank">151551220</a><br>
            本站完善完毕 喜欢就收藏下来哦 <a href="https://wpa.qq.com/msgrd?v=3&uin=2107228359&site=qq&menu=yes" target="_blank" rel="noopener">@1梦</a></span> 
	</div>
</div>
<main id="main">
<?php if (!empty($logs)): foreach ($logs as $value): ?>
<div class="h">
<?php if (img_fj($value['logid'])) {$imgsrc = img_fj($value['logid']);} elseif (img_zw($value['content'])) {$imgsrc = img_zw($value['content']);} else {$imgsrc = img_random();}?>
<div class="h-inner h-bg" style="background-image: url(<?php echo $imgsrc; ?>);"></div>
<div class="h-content">
<a href="<?php echo $value['log_url']; ?>"><h1><?php echo $value['log_title']; ?></h1></a>
</div>
<div class="post-data">
  <div class="author-name"><?php blog_author($value['author']); ?></div>
 <span class="u-time"><i class="czs-time-l"></i> <?php echo gmdate('Y-m-d', $value['date']); ?></span>
 <span class="u-view"><i class="czs-eye-l"></i> <?php echo $value['views'];?></span>
 <span class="u-comment"><i class="czs-talk-l"></i> <?php echo $value['comnum']; ?></span>
</div>
</div>
<?php endforeach;endif; ?>
<div id="pagenavi"><?php echo $page_url;?></div>
</main>

<?php include View::getView('footer'); ?>