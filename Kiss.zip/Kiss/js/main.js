//侧边栏导航
$(function(){
    $('.iconflat').on('click', function () {
        $('#mo-nav,.openNav').toggleClass('open');
    });
});
$(function(){
    $('#mo-nav ul li a').on('click', function () {
        $('#mo-nav,.openNav').toggleClass('open');
    });
});
		//导航
		$(document).on('click', 'a.header-btn,a.header-off,#mo-nav ul li a', function() {
			if ($('body').is('.header-show')) {
				$('body').removeClass('header-show');
			} else {
				$('body').addClass('header-show');
			}
		});
//返回顶部
$('.back2top').click(function(){$('html,body').animate({scrollTop: '0px'}, 1000);});
    $(window).scroll(function(){
        $(window).scrollTop()>10?$('.back2top').css('display','block'):$('.back2top').css('display','none');
    });
//搜索
$('.sosearch').on('click', function () {
    $('.setting_tool').toggleClass('search');
});

//重载函数
czcz();
function czcz(){
//灯箱
	jQuery(document).ready(function () {
        jQuery.viewImage({
            'target' : '.single img,#pic-wall .pici a', //需要使用ViewImage的图片
            'exclude': '#pic-wall .pici a img,.guanggao a img',    //要排除的图片
            'delay'  : 300                //延迟时间
        });
    });


//Ajax-JSON实时获取评论头像
$("input#email").blur(function(){
		 	var _email = $(this).val();
			if (_email != '') {
	    	$.getJSON('../content/templates/Kiss/ajaxurl.php?email='+_email, function(avatar){// 修改为你的Ajax路径
	    		if(avatar.pic){
					$('.ajaxurl').attr('src', avatar.pic);// 修改为你自己的头像标签
	    		}
	    	});//end
			}
			return false;
		});

//评论表单
$('.wantcom').click(
    function(){
        $('.comment-respond').css('display','block');
        $('.wantcom').css('display','none');
        $('body').css('overflow','hidden');
		$('.reply').css('display','none');
		$('.noreport').css('display','inline-block');
    }
);

$('#submit,.noreport').click(
    function(){
        $('.comment-respond').css('display','none');
        $('.wantcom').css('display','block');
        $('body').css('overflow','inherit');
		$('.reply').css('display','none');
		$('.noreport').css('display','inline-block');
    }
);



//表情
$(function owo() {
   var aluContainer = document.querySelector('.OwO-items');
    if ( !aluContainer ) return;
    $('.OwO-item').on('click',function(e){
    var myField,
        _self = e.target.dataset.smilies ? e.target : e.target.parentNode,
        tag = '[' + _self.dataset.smilies + ']';
        if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
            myField = document.getElementById('comment')
        } else {
            return false
        }
        if (document.selection) {
            myField.focus();
            sel = document.selection.createRange();
            sel.text = tag;
            myField.focus()
        } else if (myField.selectionStart || myField.selectionStart == '0') {
            var startPos = myField.selectionStart;
            var endPos = myField.selectionEnd;
            var cursorPos = endPos;
            myField.value = myField.value.substring(0, startPos) + tag + myField.value.substring(endPos, myField.value.length);
            cursorPos += tag.length;
            myField.focus();
            myField.selectionStart = cursorPos;
            myField.selectionEnd = cursorPos
        } else {
            myField.value += tag;
            myField.focus()
        }
    });
 });
$(function(){
        $('.OwO-logo').on('click', function () {
            $('.OwO').toggleClass('OwO-open');
        });
});

//ajax评论提交
$(document).ready(function(){
    $("#commentform").submit(function() {
        var a = $("#commentform").serialize();
        $("#comment").attr("disabled", "disabled");
        $(".wantcom").html('「人生在世，正在提交评论..」');
        $.post($("#commentform").attr("action"), a, function(a) {
            var c = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
            c.test(a) ? (
			    $(".wantcom").html('「人生在世，装逼失败」<br><div id="error"></div>'),
				$("#error").html(a.match(c)[1]).show().fadeOut(2500),
				$("#error").show()
			) : (
				c = $("input[name=pid]").val(),
				cancelReply(),
				$("[name=comment]").val(""),
				$("#comment_list").html($(a).find("#comment_list").html()),
				$(".wantcom").html($(a).find(".wantcom").html()),
				0 != c ? (
					a = window.opera ? "CSS1Compat" == document.compatMode ? $("html") : $("body") : $("html,body"), a.animate({
						scrollTop: $("#comment-" + c).offset().top - 200
					}, "normal", function() {
						$(".wantcom").html($(a).find(".wantcom").html())
					})
				) : (
					a = window.opera ? "CSS1Compat" == document.compatMode ? $("html") : $("body") : $("html,body"), a.animate({
					scrollTop: $("#comment_list").offset().top - 200
					}, "normal", function() {
						$(".wantcom").html($(a).find(".wantcom").html())
					})
				)
			);
            $("#comment").attr("disabled", !1)
        });
        return !1
    })

})
Prism.highlightAll();//代码高亮



};//end  czcz

//pjax参数配置
            var pjax = new Pjax({
                elements: 'a[href]:not([href^="#"])', // default is "a[href], form[action]"   a:not([href^="#"])      #main a,#mo-nav a,.echo_log a
                cacheBust: false,
                debug: false,
                selectors: [
                    'title',
                    //'#header',
                    '#wrapper'
                ]
            });

            //在Pjax请求开始后触发
            document.addEventListener('pjax:send', function () {
				//加载动画
				$('html').toggleClass('load');
            });

            //在Pjax请求完成后触发
            document.addEventListener('pjax:complete', function () {
				//加载动画
				$('html').toggleClass('load');
                //重载函数
				czcz();
				jQuery(".lazy").lazyload({ effect: "fadeIn",});
            });

            //在Pjax请求成功后触发
            document.addEventListener('pjax:success', function() {

            });

            //Pjax请求失败后触发，请求对象将作为一起传递event.options.request
            document.addEventListener('pjax:error', function() {
                bar('系统出现问题，请手动刷新一次','3000');
            });
            //搜索事件处理
            $(document).on('submit', '.form-group', function (e) {
                e.preventDefault(); // 去除搜索框默认事件
                var site = document.location.origin,
                    val = $('.search-key').val(),
                    search = site + '/?keyword=' + val;
                pjax.loadUrl(search);
            });


			
			
			
			
			
			
function commentReply(a) {
    var c = document.getElementById("comment-post");
    document.getElementById("cancel-reply").style.display = "";
    document.getElementById("comment-pid").value = a;
    document.getElementById("comment-place").appendChild(c);
	    $('.comment-respond').css('display','block');
        $('.wantcom').css('display','none');
        $('body').css('overflow','hidden');
		$('.noreport').css('display','none');
		$('.reply').css('display','inline-block');
}

function cancelReply() {
    var a = document.getElementById("comment-place"),
        b = document.getElementById("comment-post");
    document.getElementById("comment-pid").value = 0;
    document.getElementById("cancel-reply").style.display = "none";
	    $('.comment-respond').css('display','none');
        $('.wantcom').css('display','block');
        $('body').css('overflow','inherit');
		$('.reply').css('display','none');
		$('.noreport').css('display','inline-block');
    a.appendChild(b)
}