<?php 
/**
 * 微语部分
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<main id="main">
<p>暂无微语功能</p>
</main>
<!--<main id="main">

    <?php 
    foreach($tws as $val):
    $img = empty($val['img']) ? "" : '<a title="查看图片" href="'.BLOG_URL.str_replace('thum-', '', $val['img']).'" target="_blank"><img style="border: 1px solid #EFEFEF;" src="'.BLOG_URL.$val['img'].'"/></a>';
    ?>
<article>
  <div class="status_list_item icon_kyubo">
    <div class="status_user" style="background-image: url(<?php echo _g("tx");?>);">	
      <div class="status_section">	
        <h3 class="status_btn"><?php echo $val['date'];?></h3>
        <p class="section_p"><?php echo $val['t'].'<br/>'.$img;?></p>
      </div>	
    </div>
  </div>
</article>
	<?php endforeach;?>

</main>
	<div id="pagenavi"><?php echo $pageurl;?></div>-->
<?php include View::getView('footer');?>