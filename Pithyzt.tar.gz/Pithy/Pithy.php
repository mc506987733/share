<?php 
if( has_post_format( 'gallery' ) ){ //推广文章?>
<div id="content">
  <div class="post">
<article class="giligili-item post">
    <div class="post-info">
   <div class="meta">
			<span class="nickname">@<a href="<?php echo $author_url;?>" title="<?php the_author(); ?>"><?php the_author(); ?></a></span>
			<time itemprop="datePublished" datetime="<?php the_time('Y-m-d') ?>T00:03:00+08:00"> ·<?php the_time('Y年.m月.d日') ?></time>
		</div>
    <div class="post-content">
          <h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
  <p><?php echo wp_trim_words(get_the_excerpt(), 60 ); ?> <img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=240&w=500&zc=1" alt="" width="447" height="215" class="alignnone size-full wp-image-2561">          
        </p>  
    </div>
    <div class="post-about"> 

        <span class="post-view"><i class="czs-eye-l"></i> <?php post_views('',''); ?></span> 
        <span class="post-comment-num"><i class="czs-comment-l"></i> <?php  echo get_comments_number();?></span>
    </div>
    </div> 
    	<a href="<?php echo $author_url;?>">
<?php if( pithy( 'pithy_touxiang', true ) ) { ?>
	    <img src="<?php echo pithy( 'pithy_touxiang', '' ); ?>" class="m-avatar" height="64" width="64">
<?php } else { ?>
   	    <img src="<?php echo get_template_directory_uri(); ?>/images/jm.png" class="m-avatar" height="64" width="64">   
	</a>
<?php }?>
<i class="giligili giligili-certify-3"></i>
</article>
    </div>
  </div>
<?php } else if ( has_post_format( 'aside' )) { //无图 ?>
<div id="content">
  <div class="post">
<article class="giligili-item post">
    <div class="post-info">
   <div class="meta">
			<span class="nickname">@<a href="<?php echo $author_url;?>" title="<?php the_author(); ?>"><?php the_author(); ?></a></span>
			<time itemprop="datePublished" datetime="<?php the_time('Y-m-d') ?>T00:03:00+08:00"> ·<?php the_time('Y.m.d') ?></time>
		</div>
    <div class="post-content">
          <h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
        <p><?php echo wp_trim_words(get_the_excerpt(), 300 ); ?> 
            
        </p> 
    </div>
    <div class="post-about"> 

        <span class="post-view"><i class="czs-eye-l"></i> <?php post_views('',''); ?></span> 
        <span class="post-comment-num"><i class="czs-comment-l"></i> <?php  echo get_comments_number();?></span>
    </div>
    </div> 
    	<a href="<?php echo $author_url;?>">
<?php if( pithy( 'pithy_touxiang', true ) ) { ?>
	    <img src="<?php echo pithy( 'pithy_touxiang', '' ); ?>" class="m-avatar" height="64" width="64">
<?php } else { ?>
   	    <img src="<?php echo get_template_directory_uri(); ?>/images/jm.png" class="m-avatar" height="64" width="64">   
	</a>
<?php }?>
<i class="giligili giligili-certify-3"></i>
</article>
    </div>
  </div>
<?php } else{ //标准 ?>
<div id="content">
  <div class="post">
<article class="giligili-item post">
    <div class="post-info">
   <div class="meta">
			<span class="nickname">@<a href="<?php echo $author_url;?>" title="<?php the_author(); ?>"><?php the_author(); ?></a></span>
			<time itemprop="datePublished" datetime="<?php the_time('Y-m-d') ?>T00:03:00+08:00"> ·<?php the_time('Y.m.d') ?></time>
		</div>
    <div class="post-content">
          <h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
  <p><?php echo wp_trim_words(get_the_excerpt(), 60 ); ?>       
<img src="<?php echo get_template_directory_uri(); ?>/timthumb.php?src=<?php echo post_thumbnail_src(); ?>&h=240&w=500&zc=1" alt="" width="447" height="215" class="alignnone size-full wp-image-2561">     
      </p> 
    </div>
    <div class="post-about"> 

        <span class="post-view"><i class="czs-eye-l"></i> <?php post_views('',''); ?></span> 
        <span class="post-comment-num"><i class="czs-comment-l"></i> <?php  echo get_comments_number();?></span>
    </div>
    </div> 
    	<a href="<?php echo $author_url;?>">
<?php if( pithy( 'pithy_touxiang', true ) ) { ?>
	    <img src="<?php echo pithy( 'pithy_touxiang', '' ); ?>" class="m-avatar" height="64" width="64">
<?php } else { ?>
   	    <img src="<?php echo get_template_directory_uri(); ?>/images/jm.png" class="m-avatar" height="64" width="64">   
	</a>
<?php }?>
<i class="giligili giligili-certify-3"></i>
</article>
    </div>
  </div>
<?php } ?>
