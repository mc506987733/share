<?php get_header(); ?>
<body>
<header class="site-header">
            <div class="banner bgtu " style="background-image: url(//ww2.sinaimg.cn/large/005zWjpngy1fp3anglfmaj31040tk7wh.jpg)">
                <div class="big-title">
                    <div class="pf_photo" node-type="photo">
                        <p class="photo_wrap">
                          <?php if( pithy( 'pithy_touxiang', true ) ) { ?>
                            <img src="<?php echo pithy( 'pithy_touxiang', '' ); ?>" class="photo_touxiang">
<?php } else { ?>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/jm.png" class="photo_touxiang">
<?php }?>
                        </p>
                        <a href="http://verified.weibo.com/verify" class="icon_bedtouxiang">
                            <em title="大帅锅一枚,西顾博客博主。" class="W_icon icon_pf_approve" suda-uatrack="key=profile_head&amp;value=vuser_guest"></em></a>
                    </div>
                   <center> <div class="pf_username">
                        <h1 class="username"><?php echo pithy( 'pithy_name', '' ); ?></h1>
                            <span class="icon_bed"><a><i class="W_icon icon_pf_male"></i></a></span>
                            <a title="微博会员" target="_blank" href="http://vip.weibo.com/personal?from=main" action-type="ignore_list" suda-uatrack="key=profile_head&amp;value=member_guest"><em class="W_icon icon_member5"></em></a>                                                
                    </div></center>
                    <div class="big-title-h3 tips-top"><?php echo pithy( 'pithy_jieshao', '' ); ?></div>
                </div>
                <div class="contactme">
                    <div class="weixin">
                        <span class="icon">+</span>关注
                    </div>
                    <a class="qq" href="tencent://AddContact/?fromId=45&amp;fromSubId=1&amp;subcmd=all&amp;uin=<?php echo pithy('pithy_qq', ''); ?>">
                        <span class="czs-qq"></span> 私信</a>
                </div>  
            </div>
    <div class="pithydh">
 
  <div class="n" id="navigator">
      	 <?php wp_nav_menu(
								array(	
                                    	'container'       => 'div',
	                                    'container_class' => 'n-inner cleafix',
										'menu_class' =>'n-tab-links', 
                                        'category_before' => '<li>',    
                                        'category_after' => '</li>',
									) 
							); 
				?>
      </div>

  </div>
        </header>

    
 
<div id="main">
           <div id="sidebar-left" class="giligili-left">
        <div id="user-info" class="giligili-item">
		    <div class="row"><i class="czs-qq"></i>&nbsp;&nbsp;&nbsp;<a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo pithy( 'pithy_qq', '' ); ?>&amp;site=qq&amp;menu=yes"><?php echo pithy( 'pithy_name', '' ); ?></a></div>
		    <div class="row"><i class="czs-message-l"></i>&nbsp;&nbsp;&nbsp;<?php echo pithy( 'pithy_qq', '' ); ?>@qq.com</div>
		    <div class="row"><i class="czs-qzone"></i>&nbsp;&nbsp;&nbsp;<a href="https://user.qzone.qq.com/<?php echo pithy( 'pithy_qq', '' ); ?>/infocenter">QQ空间</a></div>
		    <div class="row"><i class="czs-crown-l"></i>&nbsp;&nbsp;&nbsp;<?php echo pithy( 'pithy_birthday', '' ); ?></div>
		    <div class="row">不如意事常八九。</div>
		</div>

            		<div class="giligili-item">
	<ul>
		<li><div class="row">已被视淫：<?php
$counterFile = "counter.txt";
$fp = fopen($counterFile,"a+");
$num = fgets($fp,5);
$num += 1;
print ""."$num"."次";
fclose($fp);
$fpp=fopen($counterFile,"w");
fwrite($fpp, $num);
fclose($fpp); ?>
</div></li>
		<li><div class="row">日志总数：<?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>
篇</div></li>
		<li><div class="row">标签总数：<?php echo $count_tags = wp_count_terms('post_tag'); ?>
条</div></li>
		<li><div class="row">页面总数：<?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?>
页</div></li>
     	<li><div class="row">分类总数：<?php echo $count_categories = wp_count_terms('category'); ?>
个</div></li>
		<li><div class="row">运行天数：<?php echo floor((time()-strtotime('2018-3-14'))/86400); ?>
天</div></li>
		<li><div class="row">链接总数：<?php $link = $wpdb->get_var("select count(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?></div></li>
		<li><div class="row">最后更新：<?php $last = $wpdb->get_results("select max(post_modified) AS max_m from $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y-n-j', strtotime($last[0]->max_m));echo $last; ?></div></li>

	</ul>
		</div> 
		<div class="giligili-item">
		    <header class="giligili-item-header">
		        <h3 class="giligili-item-title">我的邻居</h3>
		    </header>
<?php get_sidebar(); ?>
		</div> 
        <div class="giligili-item">
            <h3 class="giligili-item-title">评论</h3>
            <ul class="widget-visitors">
                <li class="sidcomment">
<div class="perMsg cl">
     <a href="http://cnm1.cn/post/37#183" class="avater" rel="nofollow">
    <img src="http://mc.24bp.cn/wp-content/themes/Pithy/images/jm.png" class="avatar">
    </a>
     <div class="txt">
 <div class="rows cl">
    <a href="http://cnm1.cn/post/37#183" class="name" rel="nofollow"><span>腾讯云</span>：</a>
    <br>
</div>
<div class="artHeadTit">
<a href="http://cnm1.cn/post/37#183" title="" alt="">朋友 交换链接吗</a>
</div>
</div>
</div>		
                  


              </li>
            </ul>
        </div>
    </div><div id="main-part" class="giligili-left">
    <div class="row wid">

<?php $posts = query_posts($query_string . '&orderby=date&showposts=10'); ?>
								<?php while ( have_posts() ) : the_post(); 
									include( get_template_directory().'/Pithy.php' );endwhile; ?>
					
			<div id="pagenavi"></div>
	</div>
	</div>
		</div>
 

  
  <center><?php pithy_page();?></center>
<?php get_footer(); ?>

