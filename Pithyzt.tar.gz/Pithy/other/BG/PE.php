<?php
$arrayName = array(
  '//ww2.sinaimg.cn/large/87c01ec7ly1frb8atet0wj20hs0vbac9.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7gy1frb9somjyoj214w1hn18x.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7gy1frb9snx2lkj219x1d7wm1.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7gy1frb9smle9sj20m00xcgmz.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7gy1frb9sobfmnj20x11b57jl.jpg',
  'https://ww3.sinaimg.cn/large/87c01ec7gy1frb9smv0soj215e1cp0yo.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7gy1frb9smstczj20p00zc77s.jpg',
  'https://ww2.sinaimg.cn/mw690/0060lm7Tly1fr8xwcvsdlj30j60r4jyt.jpg',
  'https://ww2.sinaimg.cn/large/87c01ec7ly1frb9soc9l4j20ku0nmjuu.jpg',
  'https://ww2.sinaimg.cn/mw690/0060lm7Tly1fr8wkrq8krj30jo0t476q.jpg',
  'https://img.6star.ltd/photo/1.jpg',
  'https://img.6star.ltd/photo/2.jpg',
  'https://img.6star.ltd/photo/3.jpg',
  'https://img.6star.ltd/photo/4.jpg',
  'https://img.6star.ltd/photo/5.jpg',
  'https://img.6star.ltd/photo/6.jpg',
  'https://img.6star.ltd/photo/7.jpg',
  'https://img.6star.ltd/photo/8.jpg',
  'https://img.6star.ltd/photo/9.jpg',
  'https://img.6star.ltd/photo/10.jpg',
  'https://img.6star.ltd/photo/11.jpg',

);
$id = count($arrayName)-1;
$ids = rand(0,$id);
//Result Generate
$result['code']='200';
$result['imgurl']=''.$arrayName[$ids].'';
 
//Type Choose
$type=$_GET['return'];
switch ($type)
{   
    
//JSON
case 'json':
header('Content-type:text/json');
echo json_encode($result, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
break;
 
//302 Redirect
case '302':
header("Location:".$result['imgurl']);
break;
    
//IMG
default:
header("Location:".$result['imgurl']);
break;
}
