<?php 
//短代码输出
function toz($atts, $content=null){
    return '<div id="sc_notice">'.$content.'</div>';
}
add_shortcode('v_notice','toz');
function toa($atts, $content=null){
    return '<div id="sc_error">'.$content.'</div>';
}
add_shortcode('v_error','toa');
function toc($atts, $content=null){
    return '<div id="sc_warn">'.$content.'</div>';
}
add_shortcode('v_warn','toc');
function tob($atts, $content=null){
    return '<div id="sc_tips">'.$content.'</div>';
}
add_shortcode('v_tips','tob');
function tod($atts, $content=null){
    return '<div id="sc_blue">'.$content.'</div>';
}
add_shortcode('v_blue','tod');
function toe($atts, $content=null){
    return '<div id="sc_black">'.$content.'</div>';
}
add_shortcode('v_black','toe');
function tof($atts, $content=null){
    return '<div id="sc_xuk">'.$content.'</div>';
}
add_shortcode('v_xuk','tof');
function tog($atts, $content=null){
    return '<div id="sc_lvb">'.$content.'</div>';
}
add_shortcode('v_lvb','tog');
function toh($atts, $content=null){
    return '<div id="sc_redb">'.$content.'</div>';
}
add_shortcode('v_redb','toh');
function toi($atts, $content=null){
    return '<div id="sc_orange">'.$content.'</div>';
}
add_shortcode('v_orange','toi');
function faf($atts, $content=null){
    return '[secret key="密码"]'.$content.'[/secret]';
}
add_shortcode('v_faf','faf');
//后台编入
add_action('after_wp_tiny_mce', 'bolo_after_wp_tiny_mce');
function bolo_after_wp_tiny_mce($mce_settings) {
?>
    <script type="text/javascript">
QTags.addButton( 'v_notice', '绿框', '<div id="sc_notice">绿色提示框</div>', "" );
QTags.addButton( 'v_error', '红框', '<div id="sc_error">红色提示框</div>', "" );
QTags.addButton( 'v_warn', '黄框', '<div id="sc_warn">黄色提示框</div>', "" );
QTags.addButton( 'v_tips', '灰框', '<div id="sc_tips">灰色提示框</div>', "" );
QTags.addButton( 'v_blue', '蓝框', '<div id="sc_blue">蓝色提示框</div>', "" );
QTags.addButton( 'v_black', '黑框', '<div id="sc_black">黑色提示框</div>', "" );
QTags.addButton( 'v_xuk', '虚线', '<div id="sc_xuk">虚线提示框</div>', "" );
QTags.addButton( 'v_lvb', '绿边', '<div id="sc_lvb">绿边提示框</div>', "" );
QTags.addButton( 'v_redb', '红边', '<div id="sc_redb">红边提示框</div>', "" );
QTags.addButton( 'v_orange', '橙边', '<div id="sc_orange">橙边提示框</div>', "" );
QTags.addButton( 'v_faf', '加密阅读', '[secret key="密码"]内容[/secret]', "" );
function bolo_QTnextpage_arg1() {
    }
    </script>
<?php
}
