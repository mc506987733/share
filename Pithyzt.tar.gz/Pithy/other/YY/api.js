var theArray=new Array();
theArray[0]="总有一天,世界将因我改变。";
theArray[1]="倘若你是个半吊子,那这爱情可真够可怜的。";
theArray[2]="这世上所有的不利状况，都是当事者能力不足导致的。";
theArray[3]="遥隔千里西方梦,仅辛一朝即可圆。";
theArray[4]="敢夺取我容身之处的人绝不轻饶。";
theArray[5]="我打算先用自己的眼睛看过之后，再决定要怎么做。";
theArray[6]="能拯救自己的,只有自己。";
theArray[7]="人生要是一直无所事事,那活来的意义是什么？";

function ranFun()
{
 return parseInt(Math.random()*8);
}
document.write(theArray[ranFun()]);