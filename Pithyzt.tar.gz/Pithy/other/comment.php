<?php
function aurelius_comment($comment, $args, $depth)
{
   $GLOBALS['comment'] = $comment; ?>
   <li class="comment even thread-even depth-120 parent plt" id="li-comment-<?php comment_ID(); ?>">
	<div id="div-comment-<?php comment_ID(); ?>" class="comment-body">
      		<div class="comment-author vcard">
                <?php global $current_user;get_currentuserinfo();echo get_avatar( $current_user->user_email, 32); ?>
                    <?php printf(__('<cite class="author_name">%s</cite>'), get_comment_author_link()); ?>  			
              <span class="commentmetadata"><?php echo get_comment_time('Y-m-d H:i'); ?></span>
			<cite class="svip" style="background-color:#F7A8A8;">
               <?php if($comment->user_id == 1) {
      echo 'Admin';
}else{
    echo '访客';
} ?>
              </cite>
<a rel="nofollow" id="reply" class="comment-reply-link no-ajax" href="#comment-<?php comment_ID(); ?>" onclick="commentReply(120,this)">@回复</a>
      </div>
		<p><?php comment_text(); ?></p>
              <div class="comment_text">
                <?php if ($comment->comment_approved == '0') : ?>
                    <em>你的评论正在审核，稍后会显示出来！</em><br />
        <?php endif; ?>

        </div>
      </div>
     </li>
<?php } ?>
