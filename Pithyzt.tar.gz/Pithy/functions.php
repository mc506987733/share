<?php
define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once dirname( __FILE__ ) . '/inc/options-framework.php';
require get_template_directory() . '/other/fenye.php';
require get_template_directory() . '/other/search.php';
require get_template_directory() . '/other/comment.php';
require get_template_directory() . '/other/jiami.php';
require get_template_directory() . '/other/shortcode.php';
require get_template_directory() . '/other/wphead.php';
require get_template_directory() . '/other/friendlyimages.php';
require get_template_directory() . '/title.php';
require get_template_directory() . '/other/plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://api.24bp.cn/theme/pithy.json',
	__FILE__,
	'ThemeKing-Pithy'
);
include_once(TEMPLATEPATH .'/widget/links.php');  
// Loads options.php from child or parent theme
$optionsfile = locate_template( 'options.php' );
load_template( $optionsfile );
date_default_timezone_set('PRC');
define('THEME_URI', get_stylesheet_directory_uri());


// 屏蔽WordPress默认小工具
add_action( 'widgets_init', 'my_unregister_widgets' );   
function my_unregister_widgets() {   
 
    unregister_widget( 'WP_Widget_Archives' );   
    unregister_widget( 'WP_Widget_Calendar' );   
    unregister_widget( 'WP_Widget_Categories' );   
    unregister_widget( 'WP_Widget_Links' );   
    unregister_widget( 'WP_Widget_Meta' );   
    unregister_widget( 'WP_Widget_Pages' );   
    unregister_widget( 'WP_Widget_Recent_Comments' );   
    unregister_widget( 'WP_Widget_Recent_Posts' );   
    unregister_widget( 'WP_Widget_RSS' );   
    unregister_widget( 'WP_Widget_Search' );   
    unregister_widget( 'WP_Widget_Tag_Cloud' );   
    unregister_widget( 'WP_Nav_Menu_Widget' );   
    
}
/**
 * 禁用：移除 WordPress 4.2 中前台自动加载的 emoji 脚本
 * Disable the emoji's
 */
function disable_emojis() {
 remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
 remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
 remove_action( 'wp_print_styles', 'print_emoji_styles' );
 remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
 remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
 remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
 remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
 add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
}
add_action( 'init', 'disable_emojis' );
 
/**
 * Filter function used to remove the tinymce emoji plugin.
 * 
 * @param    array  $plugins  
 * @return   array             Difference betwen the two arrays
 */
function disable_emojis_tinymce( $plugins ) {
 if ( is_array( $plugins ) ) {
 return array_diff( $plugins, array( 'wpemoji' ) );
 } else {
 return array();
 }
}

//访问计数
function record_visitors(){
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if($post_ID) 
        {
          $post_views = (int)get_post_meta($post_ID, 'views', true);
          if(!update_post_meta($post_ID, 'views', ($post_views+1))) 
          {
            add_post_meta($post_ID, 'views', 1, true);
          }
        }
    }
}
add_action('wp_head', 'record_visitors');  

function post_views($before = '(点击 ', $after = ' 次)', $echo = 1)
{
    global $post;
    $post_ID = $post->ID;
    $views = (int)get_post_meta($post_ID, 'views', true);
    if ($echo) echo $before, number_format($views), $after;
    else return $views;
};

//友情链接
add_filter('pre_option_link_manager_enabled','__return_true');
//控制摘要长度
function excerpt_length($length) {
    return 120;
}
add_filter('excerpt_length', 'excerpt_length');

function nice_exp($more){
    return '...';
}
add_filter('excerpt_more', 'nice_exp');
//摘要
function customTitle($limit) {
    $title = get_the_title($post->ID);
    if(strlen($title) > $limit) {
        $title = substr($title, 0, $limit) . '..';
    }
    echo $title;
}

function get_thumbnail() {  
    global $post;
    $html = '';
    for ($i=0; $i < 3; $i++) { 

            $image ='<img class="thumbnails lazy" data-original="'.constant("THUMB_SMALL_DEFAULT").'" alt="'. get_the_title().'" />';   


        $html .= '<li>
                    <div class="image-item">
                        <a class="simg" href="'.get_permalink(get_the_ID()).'">
                            '.$image.'
                        </a>
                    </div>
                </li>';
    }

    return $html;
}

if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');
function post_thumbnail_src(){
    global $post;
    if( $values = get_post_custom_values("thumb") ) {   //输出自定义域图片地址
        $values = get_post_custom_values("thumb");
        $post_thumbnail_src = $values [0];
    } elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];   //获取该图片 src
        }elseif( ('post_thumbnail') ){
            $post_thumbnail_src = ('post_thumbnail');
        }else{  
            //如果日志中没有图片，则显示随机图片
            //$random = mt_rand(1, 5);
            //$post_thumbnail_src = get_template_directory_uri().'/img/random/'.$random.'.jpg';
            //如果日志中没有图片，则显示默认图片
            $post_thumbnail_src = get_template_directory_uri().'/images/fuck.gif';
        }
    }
    return $post_thumbnail_src;
} 

function get_post_thumbnail_url($post_id){
    $post_id = ( null === $post_id ) ? get_the_ID() : $post_id;
    $post=get_post($post_id);
    if( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post_id),'full');
        $post_thumbnail_src = $thumbnail_src [0];
    } else {
        $post_thumbnail_src = '';
        ob_start();
        ob_end_clean();
        $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
        if(!empty($matches[1][0])){
            $post_thumbnail_src = $matches[1][0];   //获取该图片 src
        }else{  
            $post_thumbnail_src = '';
        }
    }
    return $post_thumbnail_src;
}
//匹配度优化
if(is_search()){
add_filter('posts_orderby_request', 'search_orderby_filter');
}
function search_orderby_filter($orderby = ''){
    global $wpdb;
    $keyword = $wpdb->prepare($_REQUEST['s']);
    return "((CASE WHEN {$wpdb->posts}.post_title LIKE '%{$keyword}%' THEN 2 ELSE 0 END) + (CASE WHEN {$wpdb->posts}.post_content LIKE '%{$keyword}%' THEN 1 ELSE 0 END)) DESC,
{$wpdb->posts}.post_modified DESC, {$wpdb->posts}.ID ASC";
}
//彻底关闭 pingback
add_filter('xmlrpc_methods',function($methods){
	$methods['pingback.ping'] = '__return_false';
	$methods['pingback.extensions.getPingbacks'] = '__return_false';
	return $methods;
});
//禁用 pingbacks, enclosures, trackbacks
remove_action( 'do_pings', 'do_all_pings', 10 );
//去掉 _encloseme 和 do_ping 操作。
remove_action( 'publish_post','_publish_post_hook',5 );
//sidebar
if( function_exists('register_sidebar') ) {  
    register_sidebar(array(  
    'name' => '侧边栏',  
    'before_widget' => '',  
    'after_widget' => '',  
    'before_title' => '<h3>',  
    'after_title' => '</h3>'  
            ));  
}  
//自定义菜单
if(function_exists('register_nav_menus')){
    register_nav_menus( array(
        'header-menu' => __( '全站导航设置' )
    ) );
}
//发文
add_theme_support('post-formats', array('gallery', 'aside'));
function rename_post_formats($_var_28)
{
	if ($_var_28 == '相册') {
		return '单图模板';
	}
	if ($_var_28 == '日志') {
		return '无图模版';
	}
	return $_var_28;
}
add_filter('esc_html', 'rename_post_formats');
//PUSH
add_action( 'wp_footer', 'bdPushData', 999);
 if(!function_exists('baidu_check_record')){
  function baidu_check_record($url,$post_id){
    $baidu_record  = get_post_meta($post_id,'baidu_record',true);
    if( $baidu_record != 1){
        $url='http://www.baidu.com/s?wd='.$url;
        $curl=curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        $rs=curl_exec($curl);
        curl_close($curl);
        if( BD_PUSH == 'yes' && !preg_match_all('/提交网址/u',$rs) && preg_match_all('/百度为您找到相关结果/u',$rs)){
            update_post_meta($post_id, 'baidu_record', 1) || add_post_meta($post_id, 'baidu_record', 1, true);
            return 1;
        } else {
            return 0;
        }
    } else {
       return 1;
    }
  }
}
 
if(!function_exists('XGpush')){
  function XGpush() {
    global $wpdb;
    $post_id = ( null === $post_id ) ? get_the_ID() : $post_id;
    $currentUrl = home_url(add_query_arg(array()));
    //这里修改了下：给get_permalink指定了文章ID
    if(baidu_check_record(get_permalink($post_id), $post_id) == 0 && $currentUrl == get_permalink($post_id)) {
        echo "<script>(function(){
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
            } else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(bp, s);
            })();
            (function(){
                var src = (document.location.protocol == 'http:') ? 'http://js.passport.qihucdn.com/11.0.1.js?af9e600e6a4ba6d33cd7f1b088210cf7':'https://jspassport.ssl.qhimg.com/11.0.1.js?af9e600e6a4ba6d33cd7f1b088210cf7';
                document.write('<script src=\"' + src + '\" id=\"sozz\"><\/script>');
            })();</script>";
   }
 }
}
//外链转内链
add_filter('the_content','web589_the_content_nofollow',999);
function web589_the_content_nofollow($content){
 global $wpdb;
 $bd = get_template_directory_uri();
 preg_match_all('/href="(http.*?)"/',$content,$matches);
 if($matches){
 foreach($matches[1] as $val){
 if( strpos($val,home_url())===false ) 
 $content=str_replace("href=\"$val\"", "rel=\"nofollow\" href=\"$bd/go.php?url=" .base64_encode($val). "\"",$content);
 }
 }
 return $content;
}

