<style>#marisa {padding: 240px 0 0 0;background: url(//ask.qcloudimg.com/draft/1364553/5z9jwqj9wy.png) no-repeat center -5px;}</style>        
<?php
if ( !comments_open() ) :
// If registration required and not logged in.
elseif ( get_option('comment_registration') && !is_user_logged_in() ) :
?>
<p>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</p>
<?php else  : ?>
    <div id="marisa">
<div class="article">
			    <div class="c-r">
			        <div id="comment-place">
 <div id="comment-post" class="comment-respond">
	<div id="reply-title" class="content-subhead">发表评论 <small><a rel="nofollow" id="cancel-reply" href="javascript:void(0);" onClick="Javascript:document.forms['commentform'].submit()" style="display:none;">取消回复</a></small></div>
	<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform" class="comment-form">
<input type="hidden" name="gid" value="5">
<div class="fbpl">
 <div class="comment-form-info" style="width: 100%;overflow: hidden;">
           <?php if ( !is_user_logged_in() ) : ?>
            <label for="name"></label>
            <input class="comment-form-author" placeholder="昵称" type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="23" tabindex="1" />
            <label for="email"></label>
            <input class="comment-form--email" placeholder="邮箱" type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="23" tabindex="2" />
            <label for="email"></label>
            <input class="comment-form-url" placeholder="网站" type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="23" tabindex="3" />
        <?php else : ?>
           <p class="clearfix">您已登录:<a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="退出登录">退出 &raquo;</a></p>
        <?php endif; ?>
 </div>
		<p class="comment-form-comment">
			<textarea id="comment" name="comment" class="OwO-textarea" cols="45" rows="8" maxlength="65525" aria-required="true" required="required" placeholder="既然来了就说点什么吧..."></textarea>
			</p><div title="OwO" class="OwO">
            <div class="OwO-logo"><span>OωO表情</span></div>
            <div class="OwO-body" style="width: 100%">
                <ul class="OwO-items OwO-items-emoticon OwO-items-show" style="max-height: 197px;">
                    <li class="OwO-item" title="Author: DIYgod" data-owo="OωO">OωO</li>
                    <li class="OwO-item" title="Hi" data-owo="|´・ω・)ノ">|´・ω・)ノ</li>
                    <li class="OwO-item" title="开心" data-owo="ヾ(≧∇≦*)ゝ">ヾ(≧∇≦*)ゝ</li>
                    <li class="OwO-item" title="星星眼" data-owo="(☆ω☆)">(☆ω☆)</li>
                    <li class="OwO-item" title="掀桌" data-owo="（╯‵□′）╯︵┴─┴">（╯‵□′）╯︵┴─┴</li>
                    <li class="OwO-item" title="流口水" data-owo="￣﹃￣">￣﹃￣</li>
                    <li class="OwO-item" title="捂脸" data-owo="(*/ω＼*)">(*/ω＼*)</li>
                    <li class="OwO-item" title="给跪" data-owo="∠( ᐛ 」∠)＿">∠( ᐛ 」∠)＿</li>
                    <li class="OwO-item" title="Hi" data-owo="(๑•̀ㅁ•́ฅ)">(๑•̀ㅁ•́ฅ)</li>
                    <li class="OwO-item" title="斜眼" data-owo="→_→">→_→</li>
                    <li class="OwO-item" title="加油" data-owo="୧(๑•̀⌄•́๑)૭">୧(๑•̀⌄•́๑)૭</li>
                    <li class="OwO-item" title="有木有WiFi" data-owo="٩(ˊᗜˋ*)و">٩(ˊᗜˋ*)و</li>
                    <li class="OwO-item" title="前方高能预警" data-owo="(ノ°ο°)ノ">(ノ°ο°)ノ</li>
                    <li class="OwO-item" title="我从未见过如此厚颜无耻之人" data-owo="(´இ皿இ｀)">(´இ皿இ｀)</li>
                    <li class="OwO-item" title="吓死宝宝惹" data-owo="⌇●﹏●⌇">⌇●﹏●⌇</li>
                    <li class="OwO-item" title="已阅留爪" data-owo="(ฅ´ω`ฅ)">(ฅ´ω`ฅ)</li>
                    <li class="OwO-item" title="去吧大师球" data-owo="(╯°A°)╯︵○○○">(╯°A°)╯︵○○○</li>
                    <li class="OwO-item" title="太萌惹" data-owo="φ(￣∇￣o)">φ(￣∇￣o)</li>
                    <li class="OwO-item" title="咦咦咦" data-owo="ヾ(´･ ･｀｡)ノ&quot;">ヾ(´･ ･｀｡)ノ"</li>
                    <li class="OwO-item" title="气呼呼" data-owo="( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃">( ง ᵒ̌皿ᵒ̌)ง⁼³₌₃</li>
                    <li class="OwO-item" title="我受到了惊吓" data-owo="(ó﹏ò｡)">(ó﹏ò｡)</li>
                    <li class="OwO-item" title="什么鬼" data-owo="Σ(っ °Д °;)っ">Σ(っ °Д °;)っ</li>
                    <li class="OwO-item" title="摸摸头" data-owo="( ,,´･ω･)ﾉ&quot;(´っω･｀｡)">( ,,´･ω･)ﾉ"(´っω･｀｡)</li>
                    <li class="OwO-item" title="无奈" data-owo="╮(╯▽╰)╭ ">╮(╯▽╰)╭ </li>
                    <li class="OwO-item" title="脸红" data-owo="o(*////▽////*)q ">o(*////▽////*)q </li>
                    <li class="OwO-item" title="" data-owo="＞﹏＜">＞﹏＜</li>
                    <li class="OwO-item" title="" data-owo="( ๑´•ω•) &quot;(ㆆᴗㆆ)">( ๑´•ω•) "(ㆆᴗㆆ)</li>
                    <li class="OwO-item" title="" data-owo="(｡•ˇ‸ˇ•｡)">(｡•ˇ‸ˇ•｡)</li>
                    <li class="OwO-item" title="" data-owo="(๑•̀ω•́๑)">(๑•̀ω•́๑)</li>
                    <li class="OwO-item" title="" data-owo="(๑•́ ₃ •̀๑)">(๑•́ ₃ •̀๑)</li>
                    <li class="OwO-item" title="" data-owo="(灬°ω°灬)">(灬°ω°灬)</li>
                    <li class="OwO-item" title="" data-owo="(*^ω^*)">(*^ω^*)</li>
                    <li class="OwO-item" title="" data-owo="✧*。٩(ˊωˋ*)و✧*。">✧*。٩(ˊωˋ*)و✧*。</li>
                    <li class="OwO-item" title="" data-owo="(￣y▽￣)~*捂嘴偷笑">(￣y▽￣)~*捂嘴偷笑</li>
                    <li class="OwO-item" title="" data-owo="(o`•ω•)ノ(ノД`)">(o`•ω•)ノ(ノД`)</li>
                    <li class="OwO-item" title="" data-owo="(⌒▽⌒)">(⌒▽⌒)</li>
                    <li class="OwO-item" title="" data-owo="（￣▽￣）">（￣▽￣）</li>
                    <li class="OwO-item" title="" data-owo="(=・ω・=)">(=・ω・=)</li>
                    <li class="OwO-item" title="" data-owo="(｀・ω・´)">(｀・ω・´)</li>
                    <li class="OwO-item" title="" data-owo="(〜￣△￣)〜">(〜￣△￣)〜</li>
                    <li class="OwO-item" title="" data-owo="(･∀･)">(･∀･)</li>
                    <li class="OwO-item" title="" data-owo="(°∀°)ﾉ">(°∀°)ﾉ</li>
                    <li class="OwO-item" title="" data-owo="(￣3￣)">(￣3￣)</li>
                    <li class="OwO-item" title="" data-owo="╮(￣▽￣)╭">╮(￣▽￣)╭</li>
                    <li class="OwO-item" title="" data-owo="( ´_ゝ｀)">( ´_ゝ｀)</li>
                    <li class="OwO-item" title="" data-owo="←_←">←_←</li>
                    <li class="OwO-item" title="" data-owo="→_→">→_→</li>
                    <li class="OwO-item" title="" data-owo="(<_<)">(&lt;_&lt;)</li>
                    <li class="OwO-item" title="" data-owo="(>_>)">(&gt;_&gt;)</li>
                    <li class="OwO-item" title="" data-owo="(;¬_¬)">(;¬_¬)</li>
                    <li class="OwO-item" title="" data-owo="(&quot;▔□▔)">("▔□▔)</li>
                    <li class="OwO-item" title="" data-owo="(ﾟДﾟ≡ﾟдﾟ)!?">(ﾟДﾟ≡ﾟдﾟ)!?</li>
                    <li class="OwO-item" title="" data-owo="Σ(ﾟдﾟ;)">Σ(ﾟдﾟ;)</li>
                    <li class="OwO-item" title="" data-owo="Σ( ￣□￣||)">Σ( ￣□￣||)</li>
                    <li class="OwO-item" title="" data-owo="(´；ω；`)">(´；ω；`)</li>
                    <li class="OwO-item" title="" data-owo="（/TДT)/">（/TДT)/</li>
                    <li class="OwO-item" title="" data-owo="(^・ω・^ )">(^・ω・^ )</li>
                    <li class="OwO-item" title="" data-owo="(｡･ω･｡)">(｡･ω･｡)</li>
                    <li class="OwO-item" title="" data-owo="(●￣(ｴ)￣●)">(●￣(ｴ)￣●)</li>
                    <li class="OwO-item" title="" data-owo="ε=ε=(ノ≧∇≦)ノ">ε=ε=(ノ≧∇≦)ノ</li>
                    <li class="OwO-item" title="" data-owo="(´･_･`)">(´･_･`)</li>
                    <li class="OwO-item" title="" data-owo="(-_-#)">(-_-#)</li>
                    <li class="OwO-item" title="" data-owo="（￣へ￣）">（￣へ￣）</li>
                    <li class="OwO-item" title="" data-owo="(￣ε(#￣) Σ">(￣ε(#￣) Σ</li>
                    <li class="OwO-item" title="" data-owo="ヽ(`Д´)ﾉ">ヽ(`Д´)ﾉ</li>
                    <li class="OwO-item" title="" data-owo="(╯°口°)╯(┴—┴">(╯°口°)╯(┴—┴</li>
                    <li class="OwO-item" title="" data-owo="（#-_-)┯━┯">（#-_-)┯━┯</li>
                    <li class="OwO-item" title="" data-owo="_(:3」∠)_">_(:3」∠)_</li>
                    <li class="OwO-item" title="" data-owo="_(•̀ω•́ 」∠)_">_(•̀ω•́ 」∠)_</li>
                    <li class="OwO-item" title="" data-owo="─=≡Σ((( つ•̀ω•́)つ">─=≡Σ((( つ•̀ω•́)つ</li>
                    <li class="OwO-item" title="" data-owo="(ಥ_ಥ)">(ಥ_ಥ)</li>
                    <li class="OwO-item" title="" data-owo="(๑•̀ㅂ•́)و✧">(๑•̀ㅂ•́)و✧</li>
                    <li class="OwO-item" title="" data-owo="(๑╹∀╹๑)">(๑╹∀╹๑)</li>
                    <li class="OwO-item" title="" data-owo="눈_눈">눈_눈</li>
                    <li class="OwO-item" title="" data-owo="ᕦ(ò_óˇ)ᕤ">ᕦ(ò_óˇ)ᕤ</li>
                    <li class="OwO-item" title="" data-owo="(๑•ั็ω•็ั๑)">(๑•ั็ω•็ั๑)</li>
                    <li class="OwO-item" title="" data-owo="( *・ω・)✄╰ひ╯">( *・ω・)✄╰ひ╯</li>
                    <li class="OwO-item" title="" data-owo="~(￣▽￣)C❀(捏菊花)">~(￣▽￣)C❀(捏菊花)</li>
                    <li class="OwO-item" title="" data-owo="(((┏(;￣▽￣)┛装完逼就跑">(((┏(;￣▽￣)┛装完逼就跑</li>
                </ul>
                <ul class="OwO-items OwO-items-image" style="max-height: 197px;">
                    <li class="OwO-item" title="暗地观察" data-owo="@(暗地观察)"><img src="http://2002.cat/OwO/alu/暗地观察.png" alt="暗地观察" class="OwO-img"></li>
                    <li class="OwO-item" title="便便" data-owo="@(便便)"><img src="http://2002.cat/OwO/alu/便便.png" alt="便便" class="OwO-img"></li>
                    <li class="OwO-item" title="不出所料" data-owo="@(不出所料)"><img src="http://2002.cat/OwO/alu/不出所料.png" alt="不出所料" class="OwO-img"></li>
                    <li class="OwO-item" title="不高兴" data-owo="@(不高兴)"><img src="http://2002.cat/OwO/alu/不高兴.png" alt="不高兴" class="OwO-img"></li>
                    <li class="OwO-item" title="不说话" data-owo="@(不说话)"><img src="http://2002.cat/OwO/alu/不说话.png" alt="不说话" class="OwO-img"></li>
                    <li class="OwO-item" title="抽烟" data-owo="@(抽烟)"><img src="http://2002.cat/OwO/alu/抽烟.png" alt="抽烟" class="OwO-img"></li>
                    <li class="OwO-item" title="呲牙" data-owo="@(呲牙)"><img src="http://2002.cat/OwO/alu/呲牙.png" alt="呲牙" class="OwO-img"></li>
                    <li class="OwO-item" title="大囧" data-owo="@(大囧)"><img src="http://2002.cat/OwO/alu/大囧.png" alt="大囧" class="OwO-img"></li>
                    <li class="OwO-item" title="得意" data-owo="@(得意)"><img src="http://2002.cat/OwO/alu/得意.png" alt="得意" class="OwO-img"></li>
                    <li class="OwO-item" title="愤怒" data-owo="@(愤怒)"><img src="http://2002.cat/OwO/alu/愤怒.png" alt="愤怒" class="OwO-img"></li>
                    <li class="OwO-item" title="尴尬" data-owo="@(尴尬)"><img src="http://2002.cat/OwO/alu/尴尬.png" alt="尴尬" class="OwO-img"></li>
                    <li class="OwO-item" title="高兴" data-owo="@(高兴)"><img src="http://2002.cat/OwO/alu/高兴.png" alt="高兴" class="OwO-img"></li>
                    <li class="OwO-item" title="鼓掌" data-owo="@(鼓掌)"><img src="http://2002.cat/OwO/alu/鼓掌.png" alt="鼓掌" class="OwO-img"></li>
                    <li class="OwO-item" title="观察" data-owo="@(观察)"><img src="http://2002.cat/OwO/alu/观察.png" alt="观察" class="OwO-img"></li>
                    <li class="OwO-item" title="害羞" data-owo="@(害羞)"><img src="http://2002.cat/OwO/alu/害羞.png" alt="害羞" class="OwO-img"></li>
                    <li class="OwO-item" title="汗" data-owo="@(汗)"><img src="http://2002.cat/OwO/alu/汗.png" alt="汗" class="OwO-img"></li>
                    <li class="OwO-item" title="黑线" data-owo="@(黑线)"><img src="http://2002.cat/OwO/alu/黑线.png" alt="黑线" class="OwO-img"></li>
                    <li class="OwO-item" title="欢呼" data-owo="@(欢呼)"><img src="http://2002.cat/OwO/alu/欢呼.png" alt="欢呼" class="OwO-img"></li>
                    <li class="OwO-item" title="击掌" data-owo="@(击掌)"><img src="http://2002.cat/OwO/alu/击掌.png" alt="击掌" class="OwO-img"></li>
                    <li class="OwO-item" title="惊喜" data-owo="@(惊喜)"><img src="http://2002.cat/OwO/alu/惊喜.png" alt="惊喜" class="OwO-img"></li>
                    <li class="OwO-item" title="看不见" data-owo="@(看不见)"><img src="http://2002.cat/OwO/alu/看不见.png" alt="看不见" class="OwO-img"></li>
                    <li class="OwO-item" title="看热闹" data-owo="@(看热闹)"><img src="http://2002.cat/OwO/alu/看热闹.png" alt="看热闹" class="OwO-img"></li>
                    <li class="OwO-item" title="抠鼻" data-owo="@(抠鼻)"><img src="http://2002.cat/OwO/alu/抠鼻.png" alt="抠鼻" class="OwO-img"></li>
                    <li class="OwO-item" title="口水" data-owo="@(口水)"><img src="http://2002.cat/OwO/alu/口水.png" alt="口水" class="OwO-img"></li>
                    <li class="OwO-item" title="哭泣" data-owo="@(哭泣)"><img src="http://2002.cat/OwO/alu/哭泣.png" alt="哭泣" class="OwO-img"></li>
                    <li class="OwO-item" title="狂汗" data-owo="@(狂汗)"><img src="http://2002.cat/OwO/alu/狂汗.png" alt="狂汗" class="OwO-img"></li>
                    <li class="OwO-item" title="蜡烛" data-owo="@(蜡烛)"><img src="http://2002.cat/OwO/alu/蜡烛.png" alt="蜡烛" class="OwO-img"></li>
                    <li class="OwO-item" title="脸红" data-owo="@(脸红)"><img src="http://2002.cat/OwO/alu/脸红.png" alt="脸红" class="OwO-img"></li>
                    <li class="OwO-item" title="内伤" data-owo="@(内伤)"><img src="http://2002.cat/OwO/alu/内伤.png" alt="内伤" class="OwO-img"></li>
                    <li class="OwO-item" title="喷水" data-owo="@(喷水)"><img src="http://2002.cat/OwO/alu/喷水.png" alt="喷水" class="OwO-img"></li>
                    <li class="OwO-item" title="喷血" data-owo="@(喷血)"><img src="http://2002.cat/OwO/alu/喷血.png" alt="喷血" class="OwO-img"></li>
                    <li class="OwO-item" title="期待" data-owo="@(期待)"><img src="http://2002.cat/OwO/alu/期待.png" alt="期待" class="OwO-img"></li>
                    <li class="OwO-item" title="亲亲" data-owo="@(亲亲)"><img src="http://2002.cat/OwO/alu/亲亲.png" alt="亲亲" class="OwO-img"></li>
                    <li class="OwO-item" title="傻笑" data-owo="@(傻笑)"><img src="http://2002.cat/OwO/alu/傻笑.png" alt="傻笑" class="OwO-img"></li>
                    <li class="OwO-item" title="扇耳光" data-owo="@(扇耳光)"><img src="http://2002.cat/OwO/alu/扇耳光.png" alt="扇耳光" class="OwO-img"></li>
                    <li class="OwO-item" title="深思" data-owo="@(深思)"><img src="http://2002.cat/OwO/alu/深思.png" alt="深思" class="OwO-img"></li>
                    <li class="OwO-item" title="锁眉" data-owo="@(锁眉)"><img src="http://2002.cat/OwO/alu/锁眉.png" alt="锁眉" class="OwO-img"></li>
                    <li class="OwO-item" title="投降" data-owo="@(投降)"><img src="http://2002.cat/OwO/alu/投降.png" alt="投降" class="OwO-img"></li>
                    <li class="OwO-item" title="吐" data-owo="@(吐)"><img src="http://2002.cat/OwO/alu/吐.png" alt="吐" class="OwO-img"></li>
                    <li class="OwO-item" title="吐舌" data-owo="@(吐舌)"><img src="http://2002.cat/OwO/alu/吐舌.png" alt="吐舌" class="OwO-img"></li>
                    <li class="OwO-item" title="吐血倒地" data-owo="@(吐血倒地)"><img src="http://2002.cat/OwO/alu/吐血倒地.png" alt="吐血倒地" class="OwO-img"></li>
                    <li class="OwO-item" title="无奈" data-owo="@(无奈)"><img src="http://2002.cat/OwO/alu/无奈.png" alt="无奈" class="OwO-img"></li>
                    <li class="OwO-item" title="无所谓" data-owo="@(无所谓)"><img src="http://2002.cat/OwO/alu/无所谓.png" alt="无所谓" class="OwO-img"></li>
                    <li class="OwO-item" title="无语" data-owo="@(无语)"><img src="http://2002.cat/OwO/alu/无语.png" alt="无语" class="OwO-img"></li>
                    <li class="OwO-item" title="喜极而泣" data-owo="@(喜极而泣)"><img src="http://2002.cat/OwO/alu/喜极而泣.png" alt="喜极而泣" class="OwO-img"></li>
                    <li class="OwO-item" title="献花" data-owo="@(献花)"><img src="http://2002.cat/OwO/alu/献花.png" alt="献花" class="OwO-img"></li>
                    <li class="OwO-item" title="献黄瓜" data-owo="@(献黄瓜)"><img src="http://2002.cat/OwO/alu/献黄瓜.png" alt="献黄瓜" class="OwO-img"></li>
                    <li class="OwO-item" title="想一想" data-owo="@(想一想)"><img src="/OwO/alu/想一想.png" alt="想一想" class="OwO-img"></li>
                    <li class="OwO-item" title="小怒" data-owo="@(小怒)"><img src="http://2002.cat/OwO/alu/小怒.png" alt="小怒" class="OwO-img"></li>
                    <li class="OwO-item" title="小眼睛" data-owo="@(小眼睛)"><img src=http://2002.cat"/OwO/alu/小眼睛.png" alt="小眼睛" class="OwO-img"></li>
                    <li class="OwO-item" title="邪恶" data-owo="@(邪恶)"><img src="http://2002.cat/OwO/alu/邪恶.png" alt="邪恶" class="OwO-img"></li>
                    <li class="OwO-item" title="咽气" data-owo="@(咽气)"><img src="http://2002.cat/OwO/alu/咽气.png" alt="咽气" class="OwO-img"></li>
                    <li class="OwO-item" title="阴暗" data-owo="@(阴暗)"><img src="http://2002.cat/OwO/alu/阴暗.png" alt="阴暗" class="OwO-img"></li>
                    <li class="OwO-item" title="赞一个" data-owo="@(赞一个)"><img src="http://2002.cat/OwO/alu/赞一个.png" alt="赞一个" class="OwO-img"></li>
                    <li class="OwO-item" title="长草" data-owo="@(长草)"><img src="http://2002.cat/OwO/alu/长草.png" alt="长草" class="OwO-img"></li>
                    <li class="OwO-item" title="中刀" data-owo="@(中刀)"><img src="http://2002.cat/OwO/alu/中刀.png" alt="中刀" class="OwO-img"></li>
                    <li class="OwO-item" title="中枪" data-owo="@(中枪)"><img src="http://2002.cat/OwO/alu/中枪.png" alt="中枪" class="OwO-img"></li>
                    <li class="OwO-item" title="中指" data-owo="@(中指)"><img src="http://2002.cat/OwO/alu/中指.png" alt="中指" class="OwO-img"></li>
                    <li class="OwO-item" title="肿包" data-owo="@(肿包)"><img src="http://2002.cat/OwO/alu/肿包.png" alt="肿包" class="OwO-img"></li>
                    <li class="OwO-item" title="皱眉" data-owo="@(皱眉)"><img src="http://2002.cat/OwO/alu/皱眉.png" alt="皱眉" class="OwO-img"></li>
                    <li class="OwO-item" title="装大款" data-owo="@(装大款)"><img src="http://2002.cat/OwO/alu/装大款.png" alt="装大款" class="OwO-img"></li>
                    <li class="OwO-item" title="坐等" data-owo="@(坐等)"><img src="http://2002.cat/OwO/alu/坐等.png" alt="坐等" class="OwO-img"></li>
                </ul>
                <ul class="OwO-items OwO-items-image" style="max-height: 197px;">
                    <li class="OwO-item" title="啊" data-owo="@[啊]"><img src="http://2002.cat/OwO/paopao/啊.png" alt="啊" class="OwO-img"></li>
                    <li class="OwO-item" title="爱心" data-owo="@[爱心]"><img src="http://2002.cat/OwO/paopao/爱心.png" alt="爱心" class="OwO-img"></li>
                    <li class="OwO-item" title="鄙视" data-owo="@[鄙视]"><img src="http://2002.cat/OwO/paopao/鄙视.png" alt="鄙视" class="OwO-img"></li>
                    <li class="OwO-item" title="便便" data-owo="@[便便]"><img src="http://2002.cat/OwO/paopao/便便.png" alt="便便" class="OwO-img"></li>
                    <li class="OwO-item" title="不高兴" data-owo="@[不高兴]"><img src="http://2002.cat/OwO/paopao/不高兴.png" alt="不高兴" class="OwO-img"></li>
                    <li class="OwO-item" title="彩虹" data-owo="@[彩虹]"><img src="http://2002.cat/OwO/paopao/彩虹.png" alt="彩虹" class="OwO-img"></li>
                    <li class="OwO-item" title="茶杯" data-owo="@[茶杯]"><img src="http://2002.cat/OwO/paopao/茶杯.png" alt="茶杯" class="OwO-img"></li>
                    <li class="OwO-item" title="吃瓜" data-owo="@[吃瓜]"><img src="http://2002.cat/OwO/paopao/吃瓜.png" alt="吃瓜" class="OwO-img"></li>
                    <li class="OwO-item" title="吃翔" data-owo="@[吃翔]"><img src="http://2002.cat/OwO/paopao/吃翔.png" alt="吃翔" class="OwO-img"></li>
                    <li class="OwO-item" title="大拇指" data-owo="@[大拇指]"><img src="http://2002.cat/OwO/paopao/大拇指.png" alt="大拇指" class="OwO-img"></li>
                    <li class="OwO-item" title="蛋糕" data-owo="@[蛋糕]"><img src="http://2002.cat/OwO/paopao/蛋糕.png" alt="蛋糕" class="OwO-img"></li>
                    <li class="OwO-item" title="嘚瑟" data-owo="@[嘚瑟]"><img src="http://2002.cat/OwO/paopao/嘚瑟.png" alt="嘚瑟" class="OwO-img"></li>
                    <li class="OwO-item" title="灯泡" data-owo="@[灯泡]"><img src="http://2002.cat/OwO/paopao/灯泡.png" alt="灯泡" class="OwO-img"></li>
                    <li class="OwO-item" title="乖" data-owo="@[乖]"><img src="http://2002.cat/OwO/paopao/乖.png" alt="乖" class="OwO-img"></li>
                    <li class="OwO-item" title="哈哈" data-owo="@[哈哈]"><img src="http://2002.cat/OwO/paopao/哈哈.png" alt="哈哈" class="OwO-img"></li>
                    <li class="OwO-item" title="汗" data-owo="@[汗]"><img src="http://2002.cat/OwO/paopao/汗.png" alt="汗" class="OwO-img"></li>
                    <li class="OwO-item" title="呵呵" data-owo="@[呵呵]"><img src="http://2002.cat/OwO/paopao/呵呵.png" alt="呵呵" class="OwO-img"></li>
                    <li class="OwO-item" title="黑线" data-owo="@[黑线]"><img src="http://2002.cat/OwO/paopao/黑线.png" alt="黑线" class="OwO-img"></li>
                    <li class="OwO-item" title="红领巾" data-owo="@[红领巾]"><img src="http://2002.cat/OwO/paopao/红领巾.png" alt="红领巾" class="OwO-img"></li>
                    <li class="OwO-item" title="呼" data-owo="@[呼]"><img src="http://2002.cat/OwO/paopao/呼.png" alt="呼" class="OwO-img"></li>
                    <li class="OwO-item" title="花心" data-owo="@[花心]"><img src="http://2002.cat/OwO/paopao/花心.png" alt="花心" class="OwO-img"></li>
                    <li class="OwO-item" title="滑稽" data-owo="@[滑稽]"><img src="http://2002.cat/OwO/paopao/滑稽.png" alt="滑稽" class="OwO-img"></li>
                    <li class="OwO-item" title="惊恐" data-owo="@[惊恐]"><img src="http://2002.cat/OwO/paopao/惊恐.png" alt="惊恐" class="OwO-img"></li>
                    <li class="OwO-item" title="惊哭" data-owo="@[惊哭]"><img src="http://2002.cat/OwO/paopao/惊哭.png" alt="惊哭" class="OwO-img"></li>
                    <li class="OwO-item" title="惊讶" data-owo="@[惊讶]"><img src="http://2002.cat/OwO/paopao/惊讶.png" alt="惊讶" class="OwO-img"></li>
                    <li class="OwO-item" title="开心" data-owo="@[开心]"><img src="http://2002.cat/OwO/paopao/开心.png" alt="开心" class="OwO-img"></li>
                    <li class="OwO-item" title="酷" data-owo="@[酷]"><img src="http://2002.cat/OwO/paopao/酷.png" alt="酷" class="OwO-img"></li>
                    <li class="OwO-item" title="狂汗" data-owo="@[狂汗]"><img src="http://2002.cat/OwO/paopao/狂汗.png" alt="狂汗" class="OwO-img"></li>
                    <li class="OwO-item" title="蜡烛" data-owo="@[蜡烛]"><img src="http://2002.cat/OwO/paopao/蜡烛.png" alt="蜡烛" class="OwO-img"></li>
                    <li class="OwO-item" title="懒得理" data-owo="@[懒得理]"><img src="http://2002.cat/OwO/paopao/懒得理.png" alt="懒得理" class="OwO-img"></li>
                    <li class="OwO-item" title="泪" data-owo="@[泪]"><img src="http://2002.cat/OwO/paopao/泪.png" alt="泪" class="OwO-img"></li>
                    <li class="OwO-item" title="冷" data-owo="@[冷]"><img src="http://2002.cat/OwO/paopao/冷.png" alt="冷" class="OwO-img"></li>
                    <li class="OwO-item" title="礼物" data-owo="@[礼物]"><img src="http://2002.cat/OwO/paopao/礼物.png" alt="礼物" class="OwO-img"></li>
                    <li class="OwO-item" title="玫瑰" data-owo="@[玫瑰]"><img src="http://2002.cat/OwO/paopao/玫瑰.png" alt="玫瑰" class="OwO-img"></li>
                    <li class="OwO-item" title="勉强" data-owo="@[勉强]"><img src="http://2002.cat/OwO/paopao/勉强.png" alt="勉强" class="OwO-img"></li>
                    <li class="OwO-item" title="你懂的" data-owo="@[你懂的]"><img src="http://2002.cat/OwO/paopao/你懂的.png" alt="你懂的" class="OwO-img"></li>
                    <li class="OwO-item" title="怒" data-owo="@[怒]"><img src="http://2002.cat/OwO/paopao/怒.png" alt="怒" class="OwO-img"></li>
                    <li class="OwO-item" title="喷" data-owo="@[喷]"><img src="http://2002.cat/OwO/paopao/喷.png" alt="喷" class="OwO-img"></li>
                    <li class="OwO-item" title="钱" data-owo="@[钱]"><img src="http://2002.cat/OwO/paopao/钱.png" alt="钱" class="OwO-img"></li>
                    <li class="OwO-item" title="钱币" data-owo="@[钱币]"><img src="/OwO/paopao/钱币.png" alt="钱币" class="OwO-img"></li>
                    <li class="OwO-item" title="弱" data-owo="@[弱]"><img src="http://2002.cat/OwO/paopao/弱.png" alt="弱" class="OwO-img"></li>
                    <li class="OwO-item" title="三道杠" data-owo="@[三道杠]"><img src="http://2002.cat/OwO/paopao/三道杠.png" alt="三道杠" class="OwO-img"></li>
                    <li class="OwO-item" title="沙发" data-owo="@[沙发]"><img src="http://2002.cat/OwO/paopao/沙发.png" alt="沙发" class="OwO-img"></li>
                    <li class="OwO-item" title="生气" data-owo="@[生气]"><img src="http://2002.cat/OwO/paopao/生气.png" alt="生气" class="OwO-img"></li>
                    <li class="OwO-item" title="胜利" data-owo="@[胜利]"><img src="http://2002.cat/OwO/paopao/胜利.png" alt="胜利" class="OwO-img"></li>
                    <li class="OwO-item" title="手纸" data-owo="@[手纸]"><img src="http://2002.cat/OwO/paopao/手纸.png" alt="手纸" class="OwO-img"></li>
                    <li class="OwO-item" title="睡觉" data-owo="@[睡觉]"><img src="http://2002.cat/OwO/paopao/睡觉.png" alt="睡觉" class="OwO-img"></li>
                    <li class="OwO-item" title="酸爽" data-owo="@[酸爽]"><img src="http://2002.cat/OwO/paopao/酸爽.png" alt="酸爽" class="OwO-img"></li>
                    <li class="OwO-item" title="太开心" data-owo="@[太开心]"><img src="http://2002.cat/OwO/paopao/太开心.png" alt="太开心" class="OwO-img"></li>
                    <li class="OwO-item" title="太阳" data-owo="@[太阳]"><img src="http://2002.cat/OwO/paopao/太阳.png" alt="太阳" class="OwO-img"></li>
                    <li class="OwO-item" title="吐" data-owo="@[吐]"><img src="http://2002.cat/OwO/paopao/吐.png" alt="吐" class="OwO-img"></li>
                    <li class="OwO-item" title="吐舌" data-owo="@[吐舌]"><img src="http://2002.cat/OwO/paopao/吐舌.png" alt="吐舌" class="OwO-img"></li>
                    <li class="OwO-item" title="挖鼻" data-owo="@[挖鼻]"><img src="http://2002.cat/OwO/paopao/挖鼻.png" alt="挖鼻" class="OwO-img"></li>
                    <li class="OwO-item" title="委屈" data-owo="@[委屈]"><img src="http://2002.cat/OwO/paopao/委屈.png" alt="委屈" class="OwO-img"></li>
                    <li class="OwO-item" title="捂嘴笑" data-owo="@[捂嘴笑]"><img src="http://2002.cat/OwO/paopao/捂嘴笑.png" alt="捂嘴笑" class="OwO-img"></li>
                    <li class="OwO-item" title="犀利" data-owo="@[犀利]"><img src="http://2002.cat/OwO/paopao/犀利.png" alt="犀利" class="OwO-img"></li>
                    <li class="OwO-item" title="香蕉" data-owo="@[香蕉]"><img src="http://2002.cat/OwO/paopao/香蕉.png" alt="香蕉" class="OwO-img"></li>
                    <li class="OwO-item" title="小乖" data-owo="@[小乖]"><img src="http://2002.cat/OwO/paopao/小乖.png" alt="小乖" class="OwO-img"></li>
                    <li class="OwO-item" title="小红脸" data-owo="@[小红脸]"><img src="http://2002.cat/OwO/paopao/小红脸.png" alt="小红脸" class="OwO-img"></li>
                    <li class="OwO-item" title="笑尿" data-owo="@[笑尿]"><img src="http://2002.cat/OwO/paopao/笑尿.png" alt="笑尿" class="OwO-img"></li>
                    <li class="OwO-item" title="笑眼" data-owo="@[笑眼]"><img src="http://2002.cat/OwO/paopao/笑眼.png" alt="笑眼" class="OwO-img"></li>
                    <li class="OwO-item" title="心碎" data-owo="@[心碎]"><img src="http://2002.cat/OwO/paopao/心碎.png" alt="心碎" class="OwO-img"></li>
                    <li class="OwO-item" title="星星月亮" data-owo="@[星星月亮]"><img src="http://2002.cat/OwO/paopao/星星月亮.png" alt="星星月亮" class="OwO-img"></li>
                    <li class="OwO-item" title="呀咩爹" data-owo="@[呀咩爹]"><img src="http://2002.cat/OwO/paopao/呀咩爹.png" alt="呀咩爹" class="OwO-img"></li>
                    <li class="OwO-item" title="药丸" data-owo="@[药丸]"><img src="http://2002.cat/OwO/paopao/药丸.png" alt="药丸" class="OwO-img"></li>
                    <li class="OwO-item" title="咦" data-owo="@[咦]"><img src="http://2002.cat/OwO/paopao/咦.png" alt="咦" class="OwO-img"></li>
                    <li class="OwO-item" title="疑问" data-owo="@[疑问]"><img src="http://2002.cat/OwO/paopao/疑问.png" alt="疑问" class="OwO-img"></li>
                    <li class="OwO-item" title="阴险" data-owo="@[阴险]"><img src="http://2002.cat/OwO/paopao/阴险.png" alt="阴险" class="OwO-img"></li>
                    <li class="OwO-item" title="音乐" data-owo="@[音乐]"><img src="http://2002.cat/OwO/paopao/音乐.png" alt="音乐" class="OwO-img"></li>
                    <li class="OwO-item" title="真棒" data-owo="@[真棒]"><img src="http://2002.cat/OwO/paopao/真棒.png" alt="真棒" class="OwO-img"></li>
                    <li class="OwO-item" title="nico" data-owo="@[nico]"><img src="http://2002.cat/OwO/paopao/nico.png" alt="nico" class="OwO-img"></li>
                    <li class="OwO-item" title="OK" data-owo="@[OK]"><img src="http://2002.cat/OwO/paopao/OK.png" alt="OK" class="OwO-img"></li>
                    <li class="OwO-item" title="what" data-owo="@[what]"><img src="http://2002.cat/OwO/paopao/what.png" alt="what" class="OwO-img"></li>
                    <li class="OwO-item" title="doge" data-owo="@[doge]"><img src="http://2002.cat/OwO/doge.png" alt="doge" class="OwO-img"></li>
                    <li class="OwO-item" title="原谅她" data-owo="@[原谅她]"><img src="http://2002.cat/OwO/原谅她.png" alt="原谅她" class="OwO-img"></li>
                </ul>
                <ul class="OwO-items OwO-items-image" style="max-height: 197px;">
                    <li class="OwO-item" title="02" data-owo="@[02]"><img src="http://2002.cat/OwO/qita/1.gif" alt="02" class="OwO-img"></li>
                    <li class="OwO-item" title="鬼畜姬" data-owo="@[鬼畜姬]"><img src="http://2002.cat/OwO/qita/2.gif" alt="鬼畜姬" class="OwO-img"></li>
                    <li class="OwO-item" title="流口水" data-owo="@[流口水]"><img src="http://2002.cat/OwO/qita/3.gif" alt="流口水" class="OwO-img"></li>
                    <li class="OwO-item" title="茶婊" data-owo="@[茶婊]"><img src="http://2002.cat/OwO/qita/4.jpg" alt="茶婊" class="OwO-img"></li>
                    <li class="OwO-item" title="茶婊2" data-owo="@[茶婊2]"><img src="http://2002.cat/OwO/qita/8.jpg" alt="茶婊" class="OwO-img"></li>
                    <li class="OwO-item" title="疑问姬" data-owo="@[疑问姬]"><img src="http://2002.cat/OwO/qita/5.jpg" alt="疑问姬" class="OwO-img"></li>
                    <li class="OwO-item" title="召唤富婆" data-owo="@[召唤富婆]"><img src="http://2002.cat/OwO/qita/6.jpg" alt="召唤富婆" class="OwO-img"></li>
                    <li class="OwO-item" title="给大佬敬礼" data-owo="@[给大佬敬礼]"><img src="http://2002.cat/OwO/qita/7.jpg" alt="给大佬敬礼" class="OwO-img"></li>
                    <li class="OwO-item" title="吃饭姬" data-owo="@[吃饭姬]"><img src="http://2002.cat/OwO/qita/9.gif" alt="吃饭姬" class="OwO-img"></li>
                    <li class="OwO-item" title="拜托你很弱" data-owo="@[拜托你很弱]"><img src="/OwO/qita/10.jpg" alt="拜托你很弱" class="OwO-img"></li>
                    <li class="OwO-item" title="淫笑" data-owo="@[淫笑]"><img src="http://2002.cat/OwO/qita/11.jpg" alt="淫笑" class="OwO-img"></li>
                    <li class="OwO-item" title="藐视" data-owo="@[藐视]"><img src="http://2002.cat/OwO/qita/12.jpg" alt="藐视" class="OwO-img"></li>
                    <li class="OwO-item" title="嫌弃" data-owo="@[嫌弃]"><img src="http://2002.cat/OwO/qita/13.jpg" alt="嫌弃" class="OwO-img"></li>
                    <li class="OwO-item" title="一边傻去" data-owo="@[一边傻去]"><img src="http://2002.cat/OwO/qita/14.jpg" alt="一边傻去" class="OwO-img"></li>
                    <li class="OwO-item" title="目瞪口呆" data-owo="@[目瞪口呆]"><img src="http://2002.cat/OwO/qita/15.jpg" alt="目瞪口呆" class="OwO-img"></li>
                    <li class="OwO-item" title="委屈巴巴" data-owo="@[委屈巴巴]"><img src="http://2002.cat/OwO/qita/16.jpg" alt="委屈巴巴" class="OwO-img"></li>
                </ul>
                <div class="OwO-bar">
                    <ul class="OwO-packages">
                        <li class="OwO-package-active"><span>颜文字</span></li>
                        <li><span>阿鲁</span></li>
                        <li><span>泡泡</span></li>
                        <li><span>二次元</span></li>
                    </ul>
                </div>
            </div>
            </div>
<script>var OwO_demo = new OwO({
	logo: 'OωO表情',
	container: document.getElementsByClassName('OwO')[0],
	target: document.getElementsByClassName('OwO-textarea')[0],
	api: 'http://2002.cat/OwO/OwO.min.json',
	position: 'down',
	width: '100%',
	maxHeight: '250px'
});</script>
		<p></p>
        
		<p class="form-submit">
			<style type="text/css">/* jQuery Ajax 提交、刷新 评论*/#JA_commenLoading{font-size:12px;margin-bottom:5px}#JA_commenError{font-size:12px;margin-top:5px;color:red}</style><div id="JA_commenLoading" style="display:none;">Loading……</div><div id="JA_commenError"></div><input name="submit" type="submit" id="submit" class="submit" value="发表评论"><input type="hidden" name="comment_post_ID" value="1" id="comment_post_ID">
			<input type="hidden" name="pid" id="comment-pid" value="0" size="22" tabindex="1">
			<input type="hidden" name="comment_parent" id="comment_parent" value="0">
		</p>

	
 </div>
      <?php comment_id_fields(); ?>
    <?php do_action('comment_form', $post->ID); ?>
   </form><?php endif; ?>
</div>
				        
	<ol class="commentlist" id="comment_list">
      <?php
   if (!empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {
       // if there's a password
       // and it doesn't match the cookie
   ?>
 <li class="comment even thread-even depth-120 parent plt" id="comment-120">
	<div id="div-comment-120" class="comment-body">
		<div class="comment-author vcard">
			<img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo pithy( 'pithy_qq', '' ); ?>&amp;spec=100" class="avatar">
			<cite class="fn"><a href="<?php bloginfo('url'); ?>" target="_blank"><?php echo pithy( 'pithy_name', '' ); ?></a></cite>
			<span class="commentmetadata">温馨提示</span>
			<cite class="svip" style="background-color:#F7A8A8;">Admin</cite>
		</div>
		<p><a href="#addcomment">请输入密码再查看评论内容.</a></p>

	</div>
		</li>
   <?php
       } else if ( !comments_open() ) {
   ?>
 <li class="comment even thread-even depth-120 parent plt" id="comment-120">
	<div id="div-comment-120" class="comment-body">
		<div class="comment-author vcard">
			<img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo pithy( 'pithy_qq', '' ); ?>&amp;spec=100" class="avatar">
			<cite class="fn"><a href="<?php bloginfo('url'); ?>" target="_blank"><?php echo pithy( 'pithy_name', '' ); ?></a></cite>
			<span class="commentmetadata">温馨提示</span>
			<cite class="svip" style="background-color:#F7A8A8;">Admin</cite>
		</div>
		<p><a href="#addcomment">评论功能已经关闭!</a></p>

	</div>
		</li>
   <?php
       } else if ( !have_comments() ) {
   ?>
<li class="comment even thread-even depth-120 parent plt" id="comment-120">
	<div id="div-comment-120" class="comment-body">
		<div class="comment-author vcard">
			<img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo pithy( 'pithy_qq', '' ); ?>&amp;spec=100" class="avatar">
			<cite class="fn"><a href="<?php bloginfo('url'); ?>" target="_blank"><?php echo pithy( 'pithy_name', '' ); ?></a></cite>
			<span class="commentmetadata">温馨提示</span>
			<cite class="svip" style="background-color:#F7A8A8;">Admin</cite>
		</div>
<p><a href="#addcomment">还没有任何评论，你来说两句吧</a></p>

	</div>
		</li>
   <?php
       } else {
           wp_list_comments('type=comment&callback=aurelius_comment');
       }
   ?>
	    <div id="pagenavi">
	        </div>
</ol>
                </div>
         	</div>
        </div>
</div>
