
<ul class="widget-visitors">
<?php if(is_dynamic_sidebar()) dynamic_sidebar('left_sidebar');?>
<li class="widget-visitor">
<a href="https://24bp.cn" target="_blank" title="一梦博客 Pithy作者 ">
<div class="title">
<img class="photo" src="http://q2.qlogo.cn/headimg_dl?dst_uin=53964220&spec=100" height="40" width="40">
<p>西顾博客</p>
</div>
</a>
</li>
<li class="widget-visitor">
<a href="https://cnm1.cn" target="_blank" title="西顾博客 Pithy作者">
<div class="title">
<img class="photo" src="http://q2.qlogo.cn/headimg_dl?dst_uin=2107228359&spec=100" height="40" width="40">
<p>一梦博客</p>
</div>
</a>
</li>
		   </ul>