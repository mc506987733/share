  <div class="footer">
		<p>Powered By <a href="<?php bloginfo('url'); ?>" target="_blank">WordPress</a> · Theme By <a href="/">Cegoo</a>&emsp;<a href="<?php bloginfo('url'); ?>/sitemap.php">Sitemap enter</a></p>
		<div class="setting_tool iconfont">
    <a class="back2top" style="display: none;"><i class="iconfont czs-angle-up-l"></i></a>
    <a class="sosearch"><i class="iconfont czs-search-l"></i></a>
	<a class="qq" href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo pithy('pithy_qq', ''); ?>&site=qq&menu=yes"><i class="iconfont czs-qq"></i></a>
    <div class="s">
        <form method="get" name="keyform" action="<?php bloginfo('url'); ?>" role="search">
            <input class="search-key" name="s" autocomplete="off" placeholder="你要搜索什么呀！" type="text" value="" required="required">
        </form>
    </div>
    </div>
<?php if ( wp_is_mobile() ){
    echo '<div class="bg" style="background-image:url(https://api.24bp.cn/API/PC.php);"></div>';
}else{
    echo '<div class="bg" style="background-image:url(https://api.24bp.cn/API/PE.php);"></div>';
} ?><div class="bg-fixed"></div>
		<!-- <div class="top-bottom-comment"></div> -->
		<script type="text/javascript">
            /* <![CDATA[ */var ajaxcomment = {"order":"asc","formpostion":"bottom"};/* ]]> */
        </script>
		<script type="text/javascript" src="//cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
		<script type="text/javascript" src="//cdn.bootcss.com/prettify/r298/prettify.js"></script><!-- pre-js -->
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/SmoothScroll.js"></script><!-- 平滑滑动 -->
		<script src="<?php echo get_template_directory_uri(); ?>/js/JA_AjaxCommentForEmlog.js#comment_list&msg=提交中...请稍等" type="text/javascript"></script>
		<script>var ajaxhome='<?php bloginfo('url'); ?>';plpl();</script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/pjax.js"></script>


	</div>


	</body>
</html>
