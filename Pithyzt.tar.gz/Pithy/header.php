<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo pithy_title_seo(); ?>
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-title" content="Pithy">
    <link rel="dns-prefetch" href="//cdn.bootcss.com">
<?php if( pithy( 'pithy_ico', true ) ) { ?>
    <link rel="shortcut icon" href="<?php echo pithy( 'pithy_ico', '' ); ?>" type="image/x-icon" >
<?php } else { ?>
    <link rel="Shortcut Icon" href="<?php bloginfo('template_url');?>/images/ico.png" type="image/x-icon" />
<?php }?>
    <script src="<?php echo get_template_directory_uri(); ?>/js/common_tpl.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/style.css">
	<link href="<?php echo get_template_directory_uri(); ?>/css/style_1.css" rel="stylesheet" type="text/css">

	<!--<div class="bg-fixed"></div>-->
</head>