//定义所需变量
var ajaxcontent = 'main'; // 为Ajax加载部分的id，一般的主题主体都是content
var ajaxsearch_class = 'search'; // 搜索表单的class，同样，一般都是类似于searchform这种的
var ajaxignore_string = new String('/admin, #comment-, uploadfile'); 
var ajaxignore = ajaxignore_string.split(', ');// 字符分割
var ajaxloading_code = 'pjax_loading'; // 加载动画
var ajaxloading_error_code = 'error'; // 加载失败动画
var ajaxreloadDocumentReady = false; //重新加载
var ajaxtrack_analytics = false
var ajaxscroll_top = true // 定位返回锚点
var ajaxisLoad = false; // ajax加载开关
var ajaxstarted = false; // ajax开始确认
var ajaxsearchPath = null; // 搜索路径


// 初始化载入
$(document).ready(function() {    
    ajaxloadPageInit(""); 
});
// 函数：搜索提交
function submitSearch(param){
    if (!ajaxisLoad){
        ajaxloadPage(ajaxsearchPath, 0, param);
    }
}
// 函数：过滤链接
function ajaxcheck_ignore(url) {
    for (var i in ajaxignore) {
        if (url.indexOf(ajaxignore[i]) >= 0) {
            return false;
        }
    }
    return true;
}
// 函数：需要重新加载的js，比如灯箱、代码高亮等
function ajaxreload_code() 
{
    plpl(); //ajax评论
    prettyPrint();  //pre
    $(document).ready(function(){
        $(".top-logo-img").click(function(){    //手机菜单
            $(".menu_phone ul").toggleClass("menu_phone_action");
        });
    });
var OwO_demo = new OwO({
	logo: 'OωO表情',
	container: document.getElementsByClassName('OwO')[0],
	target: document.getElementsByClassName('OwO-textarea')[0],
	api: '/OwO/OwO.min.json',
	position: 'down',
	width: '100%',
	maxHeight: '250px'
});
}
// 函数：导航菜单高亮切换
function ajaxclick_code(thiss) {
    $('.menu li').each(function() { // 设置成你的菜单列表li
        $(this).removeClass('current-menu-item');
    });
    $(thiss).parents('li').addClass('menu-action');
}
// 核心函数：ajax加载
function ajaxloadPage(url, push, getData){
    var osTop = document.documentElement.scrollTop || document.body.scrollTop;
    if (!ajaxisLoad){
        if (ajaxscroll_top == true && osTop > 0) { // 返回顶部
            $('html,body').animate({scrollTop: 0}, 500); // 返回位置和速度
        }
        ajaxisLoad = true; // 开启
        ajaxstarted = true; // 开始
        nohttp = url.replace("http://","").replace("https://",""); // 去除https或http
        firstsla = nohttp.indexOf("/"); // 是否存在 / 符号
        pathpos = url.indexOf(nohttp); // 是否存在完整链接
        path = url.substring(pathpos + firstsla); // 切割提取字符串
        
        if (push != 1) {
            if (typeof window.history.pushState == "function") { // 浏览器地址变更
                var stateObj = { foo: 1000 + Math.random()*1001 };
                history.pushState(stateObj, "ajax page loaded...", path);
            } else {
            }
        }
        if (!$('#' + ajaxcontent)) {
        }
        //$('#' + ajaxcontent).append(ajaxloading_code); // 加载动画
        $('.' + ajaxloading_code).css("display","block");
        $('#' + ajaxcontent).fadeTo("slow", 0,function() { // 淡出效果
            $('#' + ajaxcontent).fadeIn("slow", function() { // 淡入效果
                $.ajax({
                    type: "GET",
                    url: url,
                    data: getData,
                    cache: false,//设为false时,ajax分页链接会出现错误
                    dataType: "html",
                    success: function(data) { // 加载成功后
                        ajaxisLoad = false; // 关闭ajax
                        
                        datax = data.split('<title>');
                        titlesx = data.split('</title>');                        
                        if (datax.length == 2 || titlesx.length == 2) {  // 浏览器标题变更
                            data = data.split('<title>')[1];
                            titles = data.split('</title>')[0];
                            $(document).attr('title', ($("<div/>").html(titles).text()));
                        } else {
                            
                        }
                        
                        if (ajaxtrack_analytics == true) {
                            if(typeof _gaq != "undefined") {
                                if (typeof getData == "undefined") {
                                    getData = "";
                                } else {
                                    getData = "?" + getData;
                                }
                                _gaq.push(['_trackPageview', path + getData]);
                            }
                        }
                        
                        data = data.split('id="' + ajaxcontent + '"')[1];
                        data = data.substring(data.indexOf('>') + 1);
                        var depth = 1;
                        var output = '';
                        
                        while(depth > 0) {
                            temp = data.split('</div>')[0];
                            i = 0;
                            pos = temp.indexOf("<div");
                            while (pos != -1) {
                                i++;
                                pos = temp.indexOf("<div", pos + 1);
                            }
                            depth=depth+i-1;
                            output=output+data.split('</div>')[0] + '</div>'; //分割字符串
                            data = data.substring(data.indexOf('</div>') + 6);
                        }
                        document.getElementById(ajaxcontent).innerHTML = output;
                        $('#' + ajaxcontent).css("position", "absolute");
                        $('#' + ajaxcontent).css("left", "20000px");
                        $('#' + ajaxcontent).show();
                        ajaxloadPageInit("#" + ajaxcontent + " ");
                        
                        if (ajaxreloadDocumentReady == true) {
                            $(document).trigger("ready");
                        }
                        try {
                            ajaxreload_code();
                        } catch(err) {
                        }
                        $('#' + ajaxcontent).hide();
                        $('#' + ajaxcontent).css("position", "");
                        $('#' + ajaxcontent).css("left", "");
                        $('.' + ajaxloading_code).css("display","none");
                        $('#' + ajaxcontent).fadeTo("slow", 1, function() {});
                    },
                    error: function(jqXHR, textStatus, errorThrown) { // 加载错误时提示
                        ajaxisLoad = false;
                        document.title = "Error loading requested page!";
                        document.getElementById(ajaxcontent).innerHTML = ajaxloading_error_code;
                    }
                });
            });
        });
    }
}
// 后退时页面效果，用popstate
window.onpopstate = function(event) {
    if (ajaxcheck_ignore(document.location.toString()) == true) {
        ajaxloadPage(document.location.toString(),1);
    }
};
//函数: ajax加载
function ajaxloadPageInit(scope){
    $(scope + "a").click(function(event){ // 点击事件绑定a标签
        if (this.href.indexOf(ajaxhome) >= 0 && ajaxcheck_ignore(this.href) == true){
            event.preventDefault();
            this.blur();
            var caption = this.title || this.name || "";
            var group = this.rel || false;
            try {
                ajaxclick_code(this);
            } catch(err) {
            }
            ajaxloadPage(this.href); // 核心函数
        }
    });
    
    $('.' + ajaxsearch_class).each(function(index) { // 搜索ajax
        if ($(this).attr("action")) {
            ajaxsearchPath = $(this).attr("action");;  //$(".text-input").value(); $(this).attr("action");
            $(this).submit(function() {
                submitSearch($(this).serialize());
                ajaxsearchPath = $(".text-input").value();
                return false;
            });
        }
    });
    
    if ($('.' + ajaxsearch_class).attr("action")) {} else {
    }
}









//返回顶部
$('.back2top').click(function(){$('html,body').animate({scrollTop: '0px'}, 1000);});
    $(window).scroll(function(){
        $(window).scrollTop()>10?$('.back2top').css('display','block'):$('.back2top').css('display','none');
    });
//搜索
$('.sosearch').on('click', function () {
    $('.setting_tool').toggleClass('search');
});
// 侧边栏
      	$(document).on('click', '#mobile-menu, .mobile-shade.show, .mobile-menu-container a', function() {
      		$('#mobile-header, #header, #main, #foot, .mobile-shade').toggleClass('show');
		});

"use strict";function _classCallCheck(a,b){if(!(a instanceof b))throw new TypeError("Cannot call a class as a function")}var _createClass=function(){function a(a,b){var c,d;for(c=0;c<b.length;c++)d=b[c],d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}return function(b,c,d){return c&&a(b.prototype,c),d&&a(b,d),b}}();!function(){var a=function(){function a(b){var d,e,f,c=this;_classCallCheck(this,a),d={logo:"OwO表情",container:document.getElementsByClassName("OwO")[0],target:document.getElementsByTagName("textarea")[0],position:"down",width:"100%",maxHeight:"250px",api:"https://api.anotherhome.net/OwO/OwO.json"};for(e in d)d.hasOwnProperty(e)&&!b.hasOwnProperty(e)&&(b[e]=d[e]);this.container=b.container,this.target=b.target,"up"===b.position&&this.container.classList.add("OwO-up"),f=new XMLHttpRequest,f.onreadystatechange=function(){4===f.readyState&&(f.status>=200&&f.status<300||304===f.status?(c.odata=JSON.parse(f.responseText),c.init(b)):console.log("OwO data request was unsuccessful: "+f.status))},f.open("get",b.api,!0),f.send(null)}return _createClass(a,[{key:"init",value:function(a){var c,d,e,f,g,h,i,b=this;for(this.area=a.target,this.packages=Object.keys(this.odata),c='\n            <div class="OwO-logo"><span>'+a.logo+'</span></div>\n            <div class="OwO-body" style="width: '+a.width+'">',d=0;d<this.packages.length;d++)if(0==d){for(c+='\n                <ul class="OwO-items OwO-items-'+this.odata[this.packages[d]].type+'" style="max-height: '+(parseInt(a.maxHeight)-53+"px")+';">',e=this.odata[this.packages[d]].container,f=0;f<e.length;f++)c+='\n                    <li class="OwO-item" title="'+e[f].text+"\" data-OwO='"+e[f].icon+"'>"+e[f].icon+"</li>";c+="\n                </ul>"}else if(1==d){for(c+='\n                <ul class="OwO-items OwO-items-'+this.odata[this.packages[d]].type+'" style="max-height: '+(parseInt(a.maxHeight)-53+"px")+';">',e=this.odata[this.packages[d]].container,f=0;f<e.length;f++)c+='\n                    <li class="OwO-item" title="'+e[f].text+'" data-OwO="@('+e[f].text+')">'+e[f].icon+"</li>";c+="\n                </ul>"}else{for(c+='\n                <ul class="OwO-items OwO-items-'+this.odata[this.packages[d]].type+'" style="max-height: '+(parseInt(a.maxHeight)-53+"px")+';">',e=this.odata[this.packages[d]].container,f=0;f<e.length;f++)c+='\n                    <li class="OwO-item" title="'+e[f].text+'" data-OwO="@['+e[f].text+']">'+e[f].icon+"</li>";c+="\n                </ul>"}for(c+='\n                <div class="OwO-bar">\n                    <ul class="OwO-packages">',g=0;g<this.packages.length;g++)c+="\n                        <li><span>"+this.packages[g]+"</span></li>";for(c+="\n                    </ul>\n                </div>\n            </div>\n            ",this.container.innerHTML=c,this.logo=this.container.getElementsByClassName("OwO-logo")[0],this.logo.addEventListener("click",function(){b.toggle()}),this.container.getElementsByClassName("OwO-body")[0].addEventListener("click",function(a){var d,e,c=null;a.target.classList.contains("OwO-item")?c=a.target:a.target.parentNode.classList.contains("OwO-item")&&(c=a.target.parentNode),c&&(d=b.area.selectionEnd,e=b.area.value,b.area.value=e.slice(0,d)+c.getAttribute("data-OwO")+e.slice(d),b.area.focus(),b.toggle())}),this.packagesEle=this.container.getElementsByClassName("OwO-packages")[0],h=function(a){!function(c){b.packagesEle.children[a].addEventListener("click",function(){b.tab(c)})}(a)},i=0;i<this.packagesEle.children.length;i++)h(i);this.tab(0)}},{key:"toggle",value:function(){this.container.classList.contains("OwO-open")?this.container.classList.remove("OwO-open"):this.container.classList.add("OwO-open")}},{key:"tab",value:function(a){var c,b=this.container.getElementsByClassName("OwO-items-show")[0];b&&b.classList.remove("OwO-items-show"),this.container.getElementsByClassName("OwO-items")[a].classList.add("OwO-items-show"),c=this.container.getElementsByClassName("OwO-package-active")[0],c&&c.classList.remove("OwO-package-active"),this.packagesEle.getElementsByTagName("li")[a].classList.add("OwO-package-active")}}]),a}();"undefined"!=typeof module&&"undefined"!=typeof module.exports?module.exports=a:window.OwO=a}();
//# sourceMappingURL=OwO.min.js.map
