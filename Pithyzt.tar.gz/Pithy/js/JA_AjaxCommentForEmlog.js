/* jQuery Ajax 提交、刷新 评论   本插件由 简爱 http://www.gouji.org/ 提取完善、移植 至 EMLOG */
plpl();
function plpl(){
// JS 仿 PHP 获取 GET 数据
var $_GET=(function(){
  var js=document.scripts;
  var url=js[js.length-1].src;
  var u=url.split("?");
  if(typeof(u[1])=="string"){
    u=u[1].split("&");
    var get={};
    for(var i in u){
      var j=u[i].split("=");
      get[j[0]]=decodeURIComponent(j[1]);
    }
    return get;
  }
  else{
    return {};
  }
})();


$(function(){
  JA_comment_($_GET['list'], $_GET['form'], $_GET['css'], $_GET['msg']);
});


function JA_comment_(JA_commentList, JA_commentForm, JA_commentCss, JA_comment) {
    if (!JA_commentList) var JA_commentList = "#comment_list";
    if (!JA_commentForm) var JA_commentForm = "#commentform";
    var JA_commentFormSubmit = $(JA_commentForm).find("input[type=submit]");
    var JA_commentFormT = $(JA_commentForm + ' textarea');
    var JA_commentForm = $(JA_commentForm);
    JA_commentForm.submit(function () {
        var q = JA_commentForm.serialize();
        JA_commentFormT.attr("disabled", true);
        JA_commentFormSubmit.attr("disabled", true);
        $("#JA_commenError").text('');
        $("#JA_commenLoading").show();
        $.post(JA_commentForm.attr("action"), q, function (d) {
            var reg = /<div class=\"main\">[\r\n]*<p>(.*?)<\/p>/i;
            if (reg.test(d)) {
                $("#JA_commenError").html(d.match(reg)[1]);
                $("#JA_commenLoading").hide()
            } else {
                var p = $("input[name=pid]").val();
                cancelReply();
                $("[name=comment]").val("");
                $("#JA_commenError").text('');
                u = JA_commentList.split(",");
                for (var i in u) {
                    $(u[i]).html($(d).find(u[i]).html())
                };
                var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                if (p != 0) {
                    var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                    body.animate({
                        scrollTop: $("#comment-" + p).offset().top - 20
                    }, "normal", function () {
                        $("#JA_commenLoading").hide()
                    })
                } else {
                    var body = (window.opera) ? (document.compatMode == "CSS1Compat" ? $('html') : $('body')) : $('html,body');
                    body.animate({
                        scrollTop: $(JA_commentList).offset().top - 20
                    }, "normal", function () {
                        $("#JA_commenLoading").hide()
                    })
                }
            };
            JA_commentFormT.attr("disabled", false);
            JA_commentFormSubmit.attr("disabled", false)
        });
        return false
    });
    JA_commentForm.keypress(function (e) {
        if (e.ctrlKey && e.which == 13 || e.which == 10) {
            JA_commentForm.submit()
        } else if (e.shiftKey && e.which == 13 || e.which == 10) {
            JA_commentForm.submit()
        }
    });
    msg = ' jQuery Ajax 提交、刷新 评论';
    JA_comment = JA_comment ? JA_comment : 'Loading……';
    if (JA_commentCss) {
        css = '<link type="text/css" rel="stylesheet" href="' + JA_commentCss + '" /><!--' + msg + '-->'
    } else {
        css = '<style type="text/css">/*' + msg + '*/#JA_commenLoading{font-size:12px;margin-bottom:5px}#JA_commenError{font-size:12px;margin-top:5px;color:red}</style>'
    };
    JA_commentFormSubmit.before(css + '<div id="JA_commenLoading" style="display:none;">' + JA_comment + '</div><div id="JA_commenError"></div>')
}
};//end  plpl